(function(root, factory){root.livestyle = factory("./livestyle/");}(this, function (LIVESTYLE_URL) {
/**
 * almond 0.2.5 Copyright (c) 2011-2012, The Dojo Foundation All Rights Reserved.
 * Available via the MIT or new BSD license.
 * see: http://github.com/jrburke/almond for details
 */
//Going sloppy to avoid 'use strict' string cost, but strict practices should
//be followed.
/*jslint sloppy: true */
/*global setTimeout: false */

var requirejs, require, define;
(function (undef) {
    var main, req, makeMap, handlers,
        defined = {},
        waiting = {},
        config = {},
        defining = {},
        hasOwn = Object.prototype.hasOwnProperty,
        aps = [].slice;

    function hasProp(obj, prop) {
        return hasOwn.call(obj, prop);
    }

    /**
     * Given a relative module name, like ./something, normalize it to
     * a real name that can be mapped to a path.
     * @param {String} name the relative name
     * @param {String} baseName a real name that the name arg is relative
     * to.
     * @returns {String} normalized name
     */
    function normalize(name, baseName) {
        var nameParts, nameSegment, mapValue, foundMap,
            foundI, foundStarMap, starI, i, j, part,
            baseParts = baseName && baseName.split("/"),
            map = config.map,
            starMap = (map && map['*']) || {};

        //Adjust any relative paths.
        if (name && name.charAt(0) === ".") {
            //If have a base name, try to normalize against it,
            //otherwise, assume it is a top-level require that will
            //be relative to baseUrl in the end.
            if (baseName) {
                //Convert baseName to array, and lop off the last part,
                //so that . matches that "directory" and not name of the baseName's
                //module. For instance, baseName of "one/two/three", maps to
                //"one/two/three.js", but we want the directory, "one/two" for
                //this normalization.
                baseParts = baseParts.slice(0, baseParts.length - 1);

                name = baseParts.concat(name.split("/"));

                //start trimDots
                for (i = 0; i < name.length; i += 1) {
                    part = name[i];
                    if (part === ".") {
                        name.splice(i, 1);
                        i -= 1;
                    } else if (part === "..") {
                        if (i === 1 && (name[2] === '..' || name[0] === '..')) {
                            //End of the line. Keep at least one non-dot
                            //path segment at the front so it can be mapped
                            //correctly to disk. Otherwise, there is likely
                            //no path mapping for a path starting with '..'.
                            //This can still fail, but catches the most reasonable
                            //uses of ..
                            break;
                        } else if (i > 0) {
                            name.splice(i - 1, 2);
                            i -= 2;
                        }
                    }
                }
                //end trimDots

                name = name.join("/");
            } else if (name.indexOf('./') === 0) {
                // No baseName, so this is ID is resolved relative
                // to baseUrl, pull off the leading dot.
                name = name.substring(2);
            }
        }

        //Apply map config if available.
        if ((baseParts || starMap) && map) {
            nameParts = name.split('/');

            for (i = nameParts.length; i > 0; i -= 1) {
                nameSegment = nameParts.slice(0, i).join("/");

                if (baseParts) {
                    //Find the longest baseName segment match in the config.
                    //So, do joins on the biggest to smallest lengths of baseParts.
                    for (j = baseParts.length; j > 0; j -= 1) {
                        mapValue = map[baseParts.slice(0, j).join('/')];

                        //baseName segment has  config, find if it has one for
                        //this name.
                        if (mapValue) {
                            mapValue = mapValue[nameSegment];
                            if (mapValue) {
                                //Match, update name to the new value.
                                foundMap = mapValue;
                                foundI = i;
                                break;
                            }
                        }
                    }
                }

                if (foundMap) {
                    break;
                }

                //Check for a star map match, but just hold on to it,
                //if there is a shorter segment match later in a matching
                //config, then favor over this star map.
                if (!foundStarMap && starMap && starMap[nameSegment]) {
                    foundStarMap = starMap[nameSegment];
                    starI = i;
                }
            }

            if (!foundMap && foundStarMap) {
                foundMap = foundStarMap;
                foundI = starI;
            }

            if (foundMap) {
                nameParts.splice(0, foundI, foundMap);
                name = nameParts.join('/');
            }
        }

        return name;
    }

    function makeRequire(relName, forceSync) {
        return function () {
            //A version of a require function that passes a moduleName
            //value for items that may need to
            //look up paths relative to the moduleName
            return req.apply(undef, aps.call(arguments, 0).concat([relName, forceSync]));
        };
    }

    function makeNormalize(relName) {
        return function (name) {
            return normalize(name, relName);
        };
    }

    function makeLoad(depName) {
        return function (value) {
            defined[depName] = value;
        };
    }

    function callDep(name) {
        if (hasProp(waiting, name)) {
            var args = waiting[name];
            delete waiting[name];
            defining[name] = true;
            main.apply(undef, args);
        }

        if (!hasProp(defined, name) && !hasProp(defining, name)) {
            throw new Error('No ' + name);
        }
        return defined[name];
    }

    //Turns a plugin!resource to [plugin, resource]
    //with the plugin being undefined if the name
    //did not have a plugin prefix.
    function splitPrefix(name) {
        var prefix,
            index = name ? name.indexOf('!') : -1;
        if (index > -1) {
            prefix = name.substring(0, index);
            name = name.substring(index + 1, name.length);
        }
        return [prefix, name];
    }

    /**
     * Makes a name map, normalizing the name, and using a plugin
     * for normalization if necessary. Grabs a ref to plugin
     * too, as an optimization.
     */
    makeMap = function (name, relName) {
        var plugin,
            parts = splitPrefix(name),
            prefix = parts[0];

        name = parts[1];

        if (prefix) {
            prefix = normalize(prefix, relName);
            plugin = callDep(prefix);
        }

        //Normalize according
        if (prefix) {
            if (plugin && plugin.normalize) {
                name = plugin.normalize(name, makeNormalize(relName));
            } else {
                name = normalize(name, relName);
            }
        } else {
            name = normalize(name, relName);
            parts = splitPrefix(name);
            prefix = parts[0];
            name = parts[1];
            if (prefix) {
                plugin = callDep(prefix);
            }
        }

        //Using ridiculous property names for space reasons
        return {
            f: prefix ? prefix + '!' + name : name, //fullName
            n: name,
            pr: prefix,
            p: plugin
        };
    };

    function makeConfig(name) {
        return function () {
            return (config && config.config && config.config[name]) || {};
        };
    }

    handlers = {
        require: function (name) {
            return makeRequire(name);
        },
        exports: function (name) {
            var e = defined[name];
            if (typeof e !== 'undefined') {
                return e;
            } else {
                return (defined[name] = {});
            }
        },
        module: function (name) {
            return {
                id: name,
                uri: '',
                exports: defined[name],
                config: makeConfig(name)
            };
        }
    };

    main = function (name, deps, callback, relName) {
        var cjsModule, depName, ret, map, i,
            args = [],
            usingExports;

        //Use name if no relName
        relName = relName || name;

        //Call the callback to define the module, if necessary.
        if (typeof callback === 'function') {

            //Pull out the defined dependencies and pass the ordered
            //values to the callback.
            //Default to [require, exports, module] if no deps
            deps = !deps.length && callback.length ? ['require', 'exports', 'module'] : deps;
            for (i = 0; i < deps.length; i += 1) {
                map = makeMap(deps[i], relName);
                depName = map.f;

                //Fast path CommonJS standard dependencies.
                if (depName === "require") {
                    args[i] = handlers.require(name);
                } else if (depName === "exports") {
                    //CommonJS module spec 1.1
                    args[i] = handlers.exports(name);
                    usingExports = true;
                } else if (depName === "module") {
                    //CommonJS module spec 1.1
                    cjsModule = args[i] = handlers.module(name);
                } else if (hasProp(defined, depName) ||
                           hasProp(waiting, depName) ||
                           hasProp(defining, depName)) {
                    args[i] = callDep(depName);
                } else if (map.p) {
                    map.p.load(map.n, makeRequire(relName, true), makeLoad(depName), {});
                    args[i] = defined[depName];
                } else {
                    throw new Error(name + ' missing ' + depName);
                }
            }

            ret = callback.apply(defined[name], args);

            if (name) {
                //If setting exports via "module" is in play,
                //favor that over return value and exports. After that,
                //favor a non-undefined return value over exports use.
                if (cjsModule && cjsModule.exports !== undef &&
                        cjsModule.exports !== defined[name]) {
                    defined[name] = cjsModule.exports;
                } else if (ret !== undef || !usingExports) {
                    //Use the return value from the function.
                    defined[name] = ret;
                }
            }
        } else if (name) {
            //May just be an object definition for the module. Only
            //worry about defining if have a module name.
            defined[name] = callback;
        }
    };

    requirejs = require = req = function (deps, callback, relName, forceSync, alt) {
        if (typeof deps === "string") {
            if (handlers[deps]) {
                //callback in this case is really relName
                return handlers[deps](callback);
            }
            //Just return the module wanted. In this scenario, the
            //deps arg is the module name, and second arg (if passed)
            //is just the relName.
            //Normalize module name, if it contains . or ..
            return callDep(makeMap(deps, callback).f);
        } else if (!deps.splice) {
            //deps is a config object, not an array.
            config = deps;
            if (callback.splice) {
                //callback is an array, which means it is a dependency list.
                //Adjust args if there are dependencies
                deps = callback;
                callback = relName;
                relName = null;
            } else {
                deps = undef;
            }
        }

        //Support require(['a'])
        callback = callback || function () {};

        //If relName is a function, it is an errback handler,
        //so remove it.
        if (typeof relName === 'function') {
            relName = forceSync;
            forceSync = alt;
        }

        //Simulate async callback;
        if (forceSync) {
            main(undef, deps, callback, relName);
        } else {
            //Using a non-zero value because of concern for what old browsers
            //do, and latest browsers "upgrade" to 4 if lower value is used:
            //http://www.whatwg.org/specs/web-apps/current-work/multipage/timers.html#dom-windowtimers-settimeout:
            //If want a value immediately, use require('id') instead -- something
            //that works in almond on the global level, but not guaranteed and
            //unlikely to work in other AMD implementations.
            setTimeout(function () {
                main(undef, deps, callback, relName);
            }, 4);
        }

        return req;
    };

    /**
     * Just drops the config on the floor, but returns req in case
     * the config return value is used.
     */
    req.config = function (cfg) {
        config = cfg;
        if (config.deps) {
            req(config.deps, config.callback);
        }
        return req;
    };

    define = function (name, deps, callback) {

        //This module may not have dependencies
        if (!deps.splice) {
            //deps is not an array, so probably means
            //an object literal or factory function for
            //the value. Adjust args.
            callback = deps;
            deps = [];
        }

        if (!hasProp(defined, name) && !hasProp(waiting, name)) {
            waiting[name] = [name, deps, callback];
        }
    };

    define.amd = {
        jQuery: true
    };
}());

define("backend/almond", function(){});

/**
 * @license
 * Lo-Dash 1.2.1 (Custom Build) <http://lodash.com/>
 * Build: `lodash modern -o ./dist/lodash.js`
 * Copyright 2012-2013 The Dojo Foundation <http://dojofoundation.org/>
 * Based on Underscore.js 1.4.4 <http://underscorejs.org/>
 * Copyright 2009-2013 Jeremy Ashkenas, DocumentCloud Inc.
 * Available under MIT license <http://lodash.com/license>
 */
;(function(window) {

  /** Used as a safe reference for `undefined` in pre ES5 environments */
  var undefined;

  /** Detect free variable `exports` */
  var freeExports = typeof exports == 'object' && exports;

  /** Detect free variable `module` */
  var freeModule = typeof module == 'object' && module && module.exports == freeExports && module;

  /** Detect free variable `global`, from Node.js or Browserified code, and use it as `window` */
  var freeGlobal = typeof global == 'object' && global;
  if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal) {
    window = freeGlobal;
  }

  /** Used to generate unique IDs */
  var idCounter = 0;

  /** Used internally to indicate various things */
  var indicatorObject = {};

  /** Used to prefix keys to avoid issues with `__proto__` and properties on `Object.prototype` */
  var keyPrefix = +new Date + '';

  /** Used as the size when optimizations are enabled for large arrays */
  var largeArraySize = 200;

  /** Used to match empty string literals in compiled template source */
  var reEmptyStringLeading = /\b__p \+= '';/g,
      reEmptyStringMiddle = /\b(__p \+=) '' \+/g,
      reEmptyStringTrailing = /(__e\(.*?\)|\b__t\)) \+\n'';/g;

  /** Used to match HTML entities */
  var reEscapedHtml = /&(?:amp|lt|gt|quot|#39);/g;

  /**
   * Used to match ES6 template delimiters
   * http://people.mozilla.org/~jorendorff/es6-draft.html#sec-7.8.6
   */
  var reEsTemplate = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g;

  /** Used to match regexp flags from their coerced string values */
  var reFlags = /\w*$/;

  /** Used to match "interpolate" template delimiters */
  var reInterpolate = /<%=([\s\S]+?)%>/g;

  /** Used to detect and test whitespace */
  var whitespace = (
    // whitespace
    ' \t\x0B\f\xA0\ufeff' +

    // line terminators
    '\n\r\u2028\u2029' +

    // unicode category "Zs" space separators
    '\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000'
  );

  /** Used to match leading whitespace and zeros to be removed */
  var reLeadingSpacesAndZeros = RegExp('^[' + whitespace + ']*0+(?=.$)');

  /** Used to ensure capturing order of template delimiters */
  var reNoMatch = /($^)/;

  /** Used to match HTML characters */
  var reUnescapedHtml = /[&<>"']/g;

  /** Used to match unescaped characters in compiled string literals */
  var reUnescapedString = /['\n\r\t\u2028\u2029\\]/g;

  /** Used to assign default `context` object properties */
  var contextProps = [
    'Array', 'Boolean', 'Date', 'Function', 'Math', 'Number', 'Object', 'RegExp',
    'String', '_', 'attachEvent', 'clearTimeout', 'isFinite', 'isNaN', 'parseInt',
    'setImmediate', 'setTimeout'
  ];

  /** Used to make template sourceURLs easier to identify */
  var templateCounter = 0;

  /** `Object#toString` result shortcuts */
  var argsClass = '[object Arguments]',
      arrayClass = '[object Array]',
      boolClass = '[object Boolean]',
      dateClass = '[object Date]',
      funcClass = '[object Function]',
      numberClass = '[object Number]',
      objectClass = '[object Object]',
      regexpClass = '[object RegExp]',
      stringClass = '[object String]';

  /** Used to identify object classifications that `_.clone` supports */
  var cloneableClasses = {};
  cloneableClasses[funcClass] = false;
  cloneableClasses[argsClass] = cloneableClasses[arrayClass] =
  cloneableClasses[boolClass] = cloneableClasses[dateClass] =
  cloneableClasses[numberClass] = cloneableClasses[objectClass] =
  cloneableClasses[regexpClass] = cloneableClasses[stringClass] = true;

  /** Used to determine if values are of the language type Object */
  var objectTypes = {
    'boolean': false,
    'function': true,
    'object': true,
    'number': false,
    'string': false,
    'undefined': false
  };

  /** Used to escape characters for inclusion in compiled string literals */
  var stringEscapes = {
    '\\': '\\',
    "'": "'",
    '\n': 'n',
    '\r': 'r',
    '\t': 't',
    '\u2028': 'u2028',
    '\u2029': 'u2029'
  };

  /*--------------------------------------------------------------------------*/

  /**
   * Create a new `lodash` function using the given `context` object.
   *
   * @static
   * @memberOf _
   * @category Utilities
   * @param {Object} [context=window] The context object.
   * @returns {Function} Returns the `lodash` function.
   */
  function runInContext(context) {
    // Avoid issues with some ES3 environments that attempt to use values, named
    // after built-in constructors like `Object`, for the creation of literals.
    // ES5 clears this up by stating that literals must use built-in constructors.
    // See http://es5.github.com/#x11.1.5.
    context = context ? _.defaults(window.Object(), context, _.pick(window, contextProps)) : window;

    /** Native constructor references */
    var Array = context.Array,
        Boolean = context.Boolean,
        Date = context.Date,
        Function = context.Function,
        Math = context.Math,
        Number = context.Number,
        Object = context.Object,
        RegExp = context.RegExp,
        String = context.String,
        TypeError = context.TypeError;

    /** Used for `Array` and `Object` method references */
    var arrayRef = Array(),
        objectRef = Object();

    /** Used to restore the original `_` reference in `noConflict` */
    var oldDash = context._;

    /** Used to detect if a method is native */
    var reNative = RegExp('^' +
      String(objectRef.valueOf)
        .replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
        .replace(/valueOf|for [^\]]+/g, '.+?') + '$'
    );

    /** Native method shortcuts */
    var ceil = Math.ceil,
        clearTimeout = context.clearTimeout,
        concat = arrayRef.concat,
        floor = Math.floor,
        getPrototypeOf = reNative.test(getPrototypeOf = Object.getPrototypeOf) && getPrototypeOf,
        hasOwnProperty = objectRef.hasOwnProperty,
        push = arrayRef.push,
        setImmediate = context.setImmediate,
        setTimeout = context.setTimeout,
        toString = objectRef.toString;

    /* Native method shortcuts for methods with the same name as other `lodash` methods */
    var nativeBind = reNative.test(nativeBind = toString.bind) && nativeBind,
        nativeIsArray = reNative.test(nativeIsArray = Array.isArray) && nativeIsArray,
        nativeIsFinite = context.isFinite,
        nativeIsNaN = context.isNaN,
        nativeKeys = reNative.test(nativeKeys = Object.keys) && nativeKeys,
        nativeMax = Math.max,
        nativeMin = Math.min,
        nativeParseInt = context.parseInt,
        nativeRandom = Math.random,
        nativeSlice = arrayRef.slice;

    /** Detect various environments */
    var isIeOpera = reNative.test(context.attachEvent),
        isV8 = nativeBind && !/\n|true/.test(nativeBind + isIeOpera);

    /** Used to lookup a built-in constructor by [[Class]] */
    var ctorByClass = {};
    ctorByClass[arrayClass] = Array;
    ctorByClass[boolClass] = Boolean;
    ctorByClass[dateClass] = Date;
    ctorByClass[objectClass] = Object;
    ctorByClass[numberClass] = Number;
    ctorByClass[regexpClass] = RegExp;
    ctorByClass[stringClass] = String;

    /*--------------------------------------------------------------------------*/

    /**
     * Creates a `lodash` object, which wraps the given `value`, to enable method
     * chaining.
     *
     * In addition to Lo-Dash methods, wrappers also have the following `Array` methods:
     * `concat`, `join`, `pop`, `push`, `reverse`, `shift`, `slice`, `sort`, `splice`,
     * and `unshift`
     *
     * Chaining is supported in custom builds as long as the `value` method is
     * implicitly or explicitly included in the build.
     *
     * The chainable wrapper functions are:
     * `after`, `assign`, `bind`, `bindAll`, `bindKey`, `chain`, `compact`,
     * `compose`, `concat`, `countBy`, `createCallback`, `debounce`, `defaults`,
     * `defer`, `delay`, `difference`, `filter`, `flatten`, `forEach`, `forIn`,
     * `forOwn`, `functions`, `groupBy`, `initial`, `intersection`, `invert`,
     * `invoke`, `keys`, `map`, `max`, `memoize`, `merge`, `min`, `object`, `omit`,
     * `once`, `pairs`, `partial`, `partialRight`, `pick`, `pluck`, `push`, `range`,
     * `reject`, `rest`, `reverse`, `shuffle`, `slice`, `sort`, `sortBy`, `splice`,
     * `tap`, `throttle`, `times`, `toArray`, `union`, `uniq`, `unshift`, `unzip`,
     * `values`, `where`, `without`, `wrap`, and `zip`
     *
     * The non-chainable wrapper functions are:
     * `clone`, `cloneDeep`, `contains`, `escape`, `every`, `find`, `has`,
     * `identity`, `indexOf`, `isArguments`, `isArray`, `isBoolean`, `isDate`,
     * `isElement`, `isEmpty`, `isEqual`, `isFinite`, `isFunction`, `isNaN`,
     * `isNull`, `isNumber`, `isObject`, `isPlainObject`, `isRegExp`, `isString`,
     * `isUndefined`, `join`, `lastIndexOf`, `mixin`, `noConflict`, `parseInt`,
     * `pop`, `random`, `reduce`, `reduceRight`, `result`, `shift`, `size`, `some`,
     * `sortedIndex`, `runInContext`, `template`, `unescape`, `uniqueId`, and `value`
     *
     * The wrapper functions `first` and `last` return wrapped values when `n` is
     * passed, otherwise they return unwrapped values.
     *
     * @name _
     * @constructor
     * @category Chaining
     * @param {Mixed} value The value to wrap in a `lodash` instance.
     * @returns {Object} Returns a `lodash` instance.
     * @example
     *
     * var wrapped = _([1, 2, 3]);
     *
     * // returns an unwrapped value
     * wrapped.reduce(function(sum, num) {
     *   return sum + num;
     * });
     * // => 6
     *
     * // returns a wrapped value
     * var squares = wrapped.map(function(num) {
     *   return num * num;
     * });
     *
     * _.isArray(squares);
     * // => false
     *
     * _.isArray(squares.value());
     * // => true
     */
    function lodash(value) {
      // don't wrap if already wrapped, even if wrapped by a different `lodash` constructor
      return (value && typeof value == 'object' && !isArray(value) && hasOwnProperty.call(value, '__wrapped__'))
       ? value
       : new lodashWrapper(value);
    }

    /**
     * An object used to flag environments features.
     *
     * @static
     * @memberOf _
     * @type Object
     */
    var support = lodash.support = {};

    /**
     * Detect if `Function#bind` exists and is inferred to be fast (all but V8).
     *
     * @memberOf _.support
     * @type Boolean
     */
    support.fastBind = nativeBind && !isV8;

    /**
     * By default, the template delimiters used by Lo-Dash are similar to those in
     * embedded Ruby (ERB). Change the following template settings to use alternative
     * delimiters.
     *
     * @static
     * @memberOf _
     * @type Object
     */
    lodash.templateSettings = {

      /**
       * Used to detect `data` property values to be HTML-escaped.
       *
       * @memberOf _.templateSettings
       * @type RegExp
       */
      'escape': /<%-([\s\S]+?)%>/g,

      /**
       * Used to detect code to be evaluated.
       *
       * @memberOf _.templateSettings
       * @type RegExp
       */
      'evaluate': /<%([\s\S]+?)%>/g,

      /**
       * Used to detect `data` property values to inject.
       *
       * @memberOf _.templateSettings
       * @type RegExp
       */
      'interpolate': reInterpolate,

      /**
       * Used to reference the data object in the template text.
       *
       * @memberOf _.templateSettings
       * @type String
       */
      'variable': '',

      /**
       * Used to import variables into the compiled template.
       *
       * @memberOf _.templateSettings
       * @type Object
       */
      'imports': {

        /**
         * A reference to the `lodash` function.
         *
         * @memberOf _.templateSettings.imports
         * @type Function
         */
        '_': lodash
      }
    };

    /*--------------------------------------------------------------------------*/

    /**
     * Creates a function optimized to search large arrays for a given `value`,
     * starting at `fromIndex`, using strict equality for comparisons, i.e. `===`.
     *
     * @private
     * @param {Array} array The array to search.
     * @param {Mixed} value The value to search for.
     * @returns {Boolean} Returns `true`, if `value` is found, else `false`.
     */
    function cachedContains(array) {
      var length = array.length,
          isLarge = length >= largeArraySize;

      if (isLarge) {
        var cache = {},
            index = -1;

        while (++index < length) {
          var key = keyPrefix + array[index];
          (cache[key] || (cache[key] = [])).push(array[index]);
        }
      }
      return function(value) {
        if (isLarge) {
          var key = keyPrefix + value;
          return  cache[key] && indexOf(cache[key], value) > -1;
        }
        return indexOf(array, value) > -1;
      }
    }

    /**
     * Used by `_.max` and `_.min` as the default `callback` when a given
     * `collection` is a string value.
     *
     * @private
     * @param {String} value The character to inspect.
     * @returns {Number} Returns the code unit of given character.
     */
    function charAtCallback(value) {
      return value.charCodeAt(0);
    }

    /**
     * Used by `sortBy` to compare transformed `collection` values, stable sorting
     * them in ascending order.
     *
     * @private
     * @param {Object} a The object to compare to `b`.
     * @param {Object} b The object to compare to `a`.
     * @returns {Number} Returns the sort order indicator of `1` or `-1`.
     */
    function compareAscending(a, b) {
      var ai = a.index,
          bi = b.index;

      a = a.criteria;
      b = b.criteria;

      // ensure a stable sort in V8 and other engines
      // http://code.google.com/p/v8/issues/detail?id=90
      if (a !== b) {
        if (a > b || typeof a == 'undefined') {
          return 1;
        }
        if (a < b || typeof b == 'undefined') {
          return -1;
        }
      }
      return ai < bi ? -1 : 1;
    }

    /**
     * Creates a function that, when called, invokes `func` with the `this` binding
     * of `thisArg` and prepends any `partialArgs` to the arguments passed to the
     * bound function.
     *
     * @private
     * @param {Function|String} func The function to bind or the method name.
     * @param {Mixed} [thisArg] The `this` binding of `func`.
     * @param {Array} partialArgs An array of arguments to be partially applied.
     * @param {Object} [idicator] Used to indicate binding by key or partially
     *  applying arguments from the right.
     * @returns {Function} Returns the new bound function.
     */
    function createBound(func, thisArg, partialArgs, indicator) {
      var isFunc = isFunction(func),
          isPartial = !partialArgs,
          key = thisArg;

      // juggle arguments
      if (isPartial) {
        var rightIndicator = indicator;
        partialArgs = thisArg;
      }
      else if (!isFunc) {
        if (!indicator) {
          throw new TypeError;
        }
        thisArg = func;
      }

      function bound() {
        // `Function#bind` spec
        // http://es5.github.com/#x15.3.4.5
        var args = arguments,
            thisBinding = isPartial ? this : thisArg;

        if (!isFunc) {
          func = thisArg[key];
        }
        if (partialArgs.length) {
          args = args.length
            ? (args = nativeSlice.call(args), rightIndicator ? args.concat(partialArgs) : partialArgs.concat(args))
            : partialArgs;
        }
        if (this instanceof bound) {
          // ensure `new bound` is an instance of `func`
          noop.prototype = func.prototype;
          thisBinding = new noop;
          noop.prototype = null;

          // mimic the constructor's `return` behavior
          // http://es5.github.com/#x13.2.2
          var result = func.apply(thisBinding, args);
          return isObject(result) ? result : thisBinding;
        }
        return func.apply(thisBinding, args);
      }
      return bound;
    }

    /**
     * Used by `template` to escape characters for inclusion in compiled
     * string literals.
     *
     * @private
     * @param {String} match The matched character to escape.
     * @returns {String} Returns the escaped character.
     */
    function escapeStringChar(match) {
      return '\\' + stringEscapes[match];
    }

    /**
     * Used by `escape` to convert characters to HTML entities.
     *
     * @private
     * @param {String} match The matched character to escape.
     * @returns {String} Returns the escaped character.
     */
    function escapeHtmlChar(match) {
      return htmlEscapes[match];
    }

    /**
     * A fast path for creating `lodash` wrapper objects.
     *
     * @private
     * @param {Mixed} value The value to wrap in a `lodash` instance.
     * @returns {Object} Returns a `lodash` instance.
     */
    function lodashWrapper(value) {
      this.__wrapped__ = value;
    }
    // ensure `new lodashWrapper` is an instance of `lodash`
    lodashWrapper.prototype = lodash.prototype;

    /**
     * A no-operation function.
     *
     * @private
     */
    function noop() {
      // no operation performed
    }

    /**
     * A fallback implementation of `isPlainObject` which checks if a given `value`
     * is an object created by the `Object` constructor, assuming objects created
     * by the `Object` constructor have no inherited enumerable properties and that
     * there are no `Object.prototype` extensions.
     *
     * @private
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if `value` is a plain object, else `false`.
     */
    function shimIsPlainObject(value) {
      // avoid non-objects and false positives for `arguments` objects
      var result = false;
      if (!(value && toString.call(value) == objectClass)) {
        return result;
      }
      // check that the constructor is `Object` (i.e. `Object instanceof Object`)
      var ctor = value.constructor;

      if (isFunction(ctor) ? ctor instanceof ctor : true) {
        // In most environments an object's own properties are iterated before
        // its inherited properties. If the last iterated property is an object's
        // own property then there are no inherited enumerable properties.
        forIn(value, function(value, key) {
          result = key;
        });
        return result === false || hasOwnProperty.call(value, result);
      }
      return result;
    }

    /**
     * Slices the `collection` from the `start` index up to, but not including,
     * the `end` index.
     *
     * Note: This function is used, instead of `Array#slice`, to support node lists
     * in IE < 9 and to ensure dense arrays are returned.
     *
     * @private
     * @param {Array|Object|String} collection The collection to slice.
     * @param {Number} start The start index.
     * @param {Number} end The end index.
     * @returns {Array} Returns the new array.
     */
    function slice(array, start, end) {
      start || (start = 0);
      if (typeof end == 'undefined') {
        end = array ? array.length : 0;
      }
      var index = -1,
          length = end - start || 0,
          result = Array(length < 0 ? 0 : length);

      while (++index < length) {
        result[index] = array[start + index];
      }
      return result;
    }

    /**
     * Used by `unescape` to convert HTML entities to characters.
     *
     * @private
     * @param {String} match The matched character to unescape.
     * @returns {String} Returns the unescaped character.
     */
    function unescapeHtmlChar(match) {
      return htmlUnescapes[match];
    }

    /*--------------------------------------------------------------------------*/

    /**
     * Checks if `value` is an `arguments` object.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is an `arguments` object, else `false`.
     * @example
     *
     * (function() { return _.isArguments(arguments); })(1, 2, 3);
     * // => true
     *
     * _.isArguments([1, 2, 3]);
     * // => false
     */
    function isArguments(value) {
      return toString.call(value) == argsClass;
    }

    /**
     * Checks if `value` is an array.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is an array, else `false`.
     * @example
     *
     * (function() { return _.isArray(arguments); })();
     * // => false
     *
     * _.isArray([1, 2, 3]);
     * // => true
     */
    var isArray = nativeIsArray;

    /**
     * A fallback implementation of `Object.keys` which produces an array of the
     * given object's own enumerable property names.
     *
     * @private
     * @type Function
     * @param {Object} object The object to inspect.
     * @returns {Array} Returns a new array of property names.
     */
    var shimKeys = function (object) {
      var index, iterable = object, result = [];
      if (!iterable) return result;
      if (!(objectTypes[typeof object])) return result;

        for (index in iterable) {
          if (hasOwnProperty.call(iterable, index)) {    
          result.push(index);    
          }
        }    
      return result
    };

    /**
     * Creates an array composed of the own enumerable property names of `object`.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The object to inspect.
     * @returns {Array} Returns a new array of property names.
     * @example
     *
     * _.keys({ 'one': 1, 'two': 2, 'three': 3 });
     * // => ['one', 'two', 'three'] (order is not guaranteed)
     */
    var keys = !nativeKeys ? shimKeys : function(object) {
      if (!isObject(object)) {
        return [];
      }
      return nativeKeys(object);
    };

    /**
     * Used to convert characters to HTML entities:
     *
     * Though the `>` character is escaped for symmetry, characters like `>` and `/`
     * don't require escaping in HTML and have no special meaning unless they're part
     * of a tag or an unquoted attribute value.
     * http://mathiasbynens.be/notes/ambiguous-ampersands (under "semi-related fun fact")
     */
    var htmlEscapes = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    };

    /** Used to convert HTML entities to characters */
    var htmlUnescapes = invert(htmlEscapes);

    /*--------------------------------------------------------------------------*/

    /**
     * Assigns own enumerable properties of source object(s) to the destination
     * object. Subsequent sources will overwrite property assignments of previous
     * sources. If a `callback` function is passed, it will be executed to produce
     * the assigned values. The `callback` is bound to `thisArg` and invoked with
     * two arguments; (objectValue, sourceValue).
     *
     * @static
     * @memberOf _
     * @type Function
     * @alias extend
     * @category Objects
     * @param {Object} object The destination object.
     * @param {Object} [source1, source2, ...] The source objects.
     * @param {Function} [callback] The function to customize assigning values.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Object} Returns the destination object.
     * @example
     *
     * _.assign({ 'name': 'moe' }, { 'age': 40 });
     * // => { 'name': 'moe', 'age': 40 }
     *
     * var defaults = _.partialRight(_.assign, function(a, b) {
     *   return typeof a == 'undefined' ? b : a;
     * });
     *
     * var food = { 'name': 'apple' };
     * defaults(food, { 'name': 'banana', 'type': 'fruit' });
     * // => { 'name': 'apple', 'type': 'fruit' }
     */
    var assign = function (object, source, guard) {
      var index, iterable = object, result = iterable;
      if (!iterable) return result;
      var args = arguments,
          argsIndex = 0,
          argsLength = typeof guard == 'number' ? 2 : args.length;
      if (argsLength > 3 && typeof args[argsLength - 2] == 'function') {
        var callback = lodash.createCallback(args[--argsLength - 1], args[argsLength--], 2);
      } else if (argsLength > 2 && typeof args[argsLength - 1] == 'function') {
        callback = args[--argsLength];
      }
      while (++argsIndex < argsLength) {
        iterable = args[argsIndex];
        if (iterable && objectTypes[typeof iterable]) {;
      var length = iterable.length; index = -1;
      if (isArray(iterable)) {
        while (++index < length) {
          result[index] = callback ? callback(result[index], iterable[index]) : iterable[index]
        }
      }
      else {    
        var ownIndex = -1,
            ownProps = objectTypes[typeof iterable] ? keys(iterable) : [],
            length = ownProps.length;

        while (++ownIndex < length) {
          index = ownProps[ownIndex];
          result[index] = callback ? callback(result[index], iterable[index]) : iterable[index]
        }    
      }
        }
      };
      return result
    };

    /**
     * Creates a clone of `value`. If `deep` is `true`, nested objects will also
     * be cloned, otherwise they will be assigned by reference. If a `callback`
     * function is passed, it will be executed to produce the cloned values. If
     * `callback` returns `undefined`, cloning will be handled by the method instead.
     * The `callback` is bound to `thisArg` and invoked with one argument; (value).
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to clone.
     * @param {Boolean} [deep=false] A flag to indicate a deep clone.
     * @param {Function} [callback] The function to customize cloning values.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @param- {Array} [stackA=[]] Tracks traversed source objects.
     * @param- {Array} [stackB=[]] Associates clones with source counterparts.
     * @returns {Mixed} Returns the cloned `value`.
     * @example
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * var shallow = _.clone(stooges);
     * shallow[0] === stooges[0];
     * // => true
     *
     * var deep = _.clone(stooges, true);
     * deep[0] === stooges[0];
     * // => false
     *
     * _.mixin({
     *   'clone': _.partialRight(_.clone, function(value) {
     *     return _.isElement(value) ? value.cloneNode(false) : undefined;
     *   })
     * });
     *
     * var clone = _.clone(document.body);
     * clone.childNodes.length;
     * // => 0
     */
    function clone(value, deep, callback, thisArg, stackA, stackB) {
      var result = value;

      // allows working with "Collections" methods without using their `callback`
      // argument, `index|key`, for this method's `callback`
      if (typeof deep == 'function') {
        thisArg = callback;
        callback = deep;
        deep = false;
      }
      if (typeof callback == 'function') {
        callback = (typeof thisArg == 'undefined')
          ? callback
          : lodash.createCallback(callback, thisArg, 1);

        result = callback(result);
        if (typeof result != 'undefined') {
          return result;
        }
        result = value;
      }
      // inspect [[Class]]
      var isObj = isObject(result);
      if (isObj) {
        var className = toString.call(result);
        if (!cloneableClasses[className]) {
          return result;
        }
        var isArr = isArray(result);
      }
      // shallow clone
      if (!isObj || !deep) {
        return isObj
          ? (isArr ? slice(result) : assign({}, result))
          : result;
      }
      var ctor = ctorByClass[className];
      switch (className) {
        case boolClass:
        case dateClass:
          return new ctor(+result);

        case numberClass:
        case stringClass:
          return new ctor(result);

        case regexpClass:
          return ctor(result.source, reFlags.exec(result));
      }
      // check for circular references and return corresponding clone
      stackA || (stackA = []);
      stackB || (stackB = []);

      var length = stackA.length;
      while (length--) {
        if (stackA[length] == value) {
          return stackB[length];
        }
      }
      // init cloned object
      result = isArr ? ctor(result.length) : {};

      // add array properties assigned by `RegExp#exec`
      if (isArr) {
        if (hasOwnProperty.call(value, 'index')) {
          result.index = value.index;
        }
        if (hasOwnProperty.call(value, 'input')) {
          result.input = value.input;
        }
      }
      // add the source value to the stack of traversed objects
      // and associate it with its clone
      stackA.push(value);
      stackB.push(result);

      // recursively populate clone (susceptible to call stack limits)
      (isArr ? forEach : forOwn)(value, function(objValue, key) {
        result[key] = clone(objValue, deep, callback, undefined, stackA, stackB);
      });

      return result;
    }

    /**
     * Creates a deep clone of `value`. If a `callback` function is passed,
     * it will be executed to produce the cloned values. If `callback` returns
     * `undefined`, cloning will be handled by the method instead. The `callback`
     * is bound to `thisArg` and invoked with one argument; (value).
     *
     * Note: This function is loosely based on the structured clone algorithm. Functions
     * and DOM nodes are **not** cloned. The enumerable properties of `arguments` objects and
     * objects created by constructors other than `Object` are cloned to plain `Object` objects.
     * See http://www.w3.org/TR/html5/infrastructure.html#internal-structured-cloning-algorithm.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to deep clone.
     * @param {Function} [callback] The function to customize cloning values.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the deep cloned `value`.
     * @example
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * var deep = _.cloneDeep(stooges);
     * deep[0] === stooges[0];
     * // => false
     *
     * var view = {
     *   'label': 'docs',
     *   'node': element
     * };
     *
     * var clone = _.cloneDeep(view, function(value) {
     *   return _.isElement(value) ? value.cloneNode(true) : undefined;
     * });
     *
     * clone.node == view.node;
     * // => false
     */
    function cloneDeep(value, callback, thisArg) {
      return clone(value, true, callback, thisArg);
    }

    /**
     * Assigns own enumerable properties of source object(s) to the destination
     * object for all destination properties that resolve to `undefined`. Once a
     * property is set, additional defaults of the same property will be ignored.
     *
     * @static
     * @memberOf _
     * @type Function
     * @category Objects
     * @param {Object} object The destination object.
     * @param {Object} [source1, source2, ...] The source objects.
     * @param- {Object} [guard] Allows working with `_.reduce` without using its
     *  callback's `key` and `object` arguments as sources.
     * @returns {Object} Returns the destination object.
     * @example
     *
     * var food = { 'name': 'apple' };
     * _.defaults(food, { 'name': 'banana', 'type': 'fruit' });
     * // => { 'name': 'apple', 'type': 'fruit' }
     */
    var defaults = function (object, source, guard) {
      var index, iterable = object, result = iterable;
      if (!iterable) return result;
      var args = arguments,
          argsIndex = 0,
          argsLength = typeof guard == 'number' ? 2 : args.length;
      while (++argsIndex < argsLength) {
        iterable = args[argsIndex];
        if (iterable && objectTypes[typeof iterable]) {;
      var length = iterable.length; index = -1;
      if (isArray(iterable)) {
        while (++index < length) {
          if (typeof result[index] == 'undefined') result[index] = iterable[index]
        }
      }
      else {    
        var ownIndex = -1,
            ownProps = objectTypes[typeof iterable] ? keys(iterable) : [],
            length = ownProps.length;

        while (++ownIndex < length) {
          index = ownProps[ownIndex];
          if (typeof result[index] == 'undefined') result[index] = iterable[index]
        }    
      }
        }
      };
      return result
    };

    /**
     * This method is similar to `_.find`, except that it returns the key of the
     * element that passes the callback check, instead of the element itself.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The object to search.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the key of the found element, else `undefined`.
     * @example
     *
     * _.findKey({ 'a': 1, 'b': 2, 'c': 3, 'd': 4 }, function(num) {
     *   return num % 2 == 0;
     * });
     * // => 'b'
     */
    function findKey(object, callback, thisArg) {
      var result;
      callback = lodash.createCallback(callback, thisArg);
      forOwn(object, function(value, key, object) {
        if (callback(value, key, object)) {
          result = key;
          return false;
        }
      });
      return result;
    }

    /**
     * Iterates over `object`'s own and inherited enumerable properties, executing
     * the `callback` for each property. The `callback` is bound to `thisArg` and
     * invoked with three arguments; (value, key, object). Callbacks may exit iteration
     * early by explicitly returning `false`.
     *
     * @static
     * @memberOf _
     * @type Function
     * @category Objects
     * @param {Object} object The object to iterate over.
     * @param {Function} [callback=identity] The function called per iteration.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Object} Returns `object`.
     * @example
     *
     * function Dog(name) {
     *   this.name = name;
     * }
     *
     * Dog.prototype.bark = function() {
     *   alert('Woof, woof!');
     * };
     *
     * _.forIn(new Dog('Dagny'), function(value, key) {
     *   alert(key);
     * });
     * // => alerts 'name' and 'bark' (order is not guaranteed)
     */
    var forIn = function (collection, callback, thisArg) {
      var index, iterable = collection, result = iterable;
      if (!iterable) return result;
      if (!objectTypes[typeof iterable]) return result;
      callback = callback && typeof thisArg == 'undefined' ? callback : lodash.createCallback(callback, thisArg);

        for (index in iterable) {
          if (callback(iterable[index], index, collection) === false) return result;    
        }    
      return result
    };

    /**
     * Iterates over an object's own enumerable properties, executing the `callback`
     * for each property. The `callback` is bound to `thisArg` and invoked with three
     * arguments; (value, key, object). Callbacks may exit iteration early by explicitly
     * returning `false`.
     *
     * @static
     * @memberOf _
     * @type Function
     * @category Objects
     * @param {Object} object The object to iterate over.
     * @param {Function} [callback=identity] The function called per iteration.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Object} Returns `object`.
     * @example
     *
     * _.forOwn({ '0': 'zero', '1': 'one', 'length': 2 }, function(num, key) {
     *   alert(key);
     * });
     * // => alerts '0', '1', and 'length' (order is not guaranteed)
     */
    var forOwn = function (collection, callback, thisArg) {
      var index, iterable = collection, result = iterable;
      if (!iterable) return result;
      if (!objectTypes[typeof iterable]) return result;
      callback = callback && typeof thisArg == 'undefined' ? callback : lodash.createCallback(callback, thisArg);

        var ownIndex = -1,
            ownProps = objectTypes[typeof iterable] ? keys(iterable) : [],
            length = ownProps.length;

        while (++ownIndex < length) {
          index = ownProps[ownIndex];
          if (callback(iterable[index], index, collection) === false) return result
        }    
      return result
    };

    /**
     * Creates a sorted array of all enumerable properties, own and inherited,
     * of `object` that have function values.
     *
     * @static
     * @memberOf _
     * @alias methods
     * @category Objects
     * @param {Object} object The object to inspect.
     * @returns {Array} Returns a new array of property names that have function values.
     * @example
     *
     * _.functions(_);
     * // => ['all', 'any', 'bind', 'bindAll', 'clone', 'compact', 'compose', ...]
     */
    function functions(object) {
      var result = [];
      forIn(object, function(value, key) {
        if (isFunction(value)) {
          result.push(key);
        }
      });
      return result.sort();
    }

    /**
     * Checks if the specified object `property` exists and is a direct property,
     * instead of an inherited property.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The object to check.
     * @param {String} property The property to check for.
     * @returns {Boolean} Returns `true` if key is a direct property, else `false`.
     * @example
     *
     * _.has({ 'a': 1, 'b': 2, 'c': 3 }, 'b');
     * // => true
     */
    function has(object, property) {
      return object ? hasOwnProperty.call(object, property) : false;
    }

    /**
     * Creates an object composed of the inverted keys and values of the given `object`.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The object to invert.
     * @returns {Object} Returns the created inverted object.
     * @example
     *
     *  _.invert({ 'first': 'moe', 'second': 'larry' });
     * // => { 'moe': 'first', 'larry': 'second' }
     */
    function invert(object) {
      var index = -1,
          props = keys(object),
          length = props.length,
          result = {};

      while (++index < length) {
        var key = props[index];
        result[object[key]] = key;
      }
      return result;
    }

    /**
     * Checks if `value` is a boolean value.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is a boolean value, else `false`.
     * @example
     *
     * _.isBoolean(null);
     * // => false
     */
    function isBoolean(value) {
      return value === true || value === false || toString.call(value) == boolClass;
    }

    /**
     * Checks if `value` is a date.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is a date, else `false`.
     * @example
     *
     * _.isDate(new Date);
     * // => true
     */
    function isDate(value) {
      return value ? (typeof value == 'object' && toString.call(value) == dateClass) : false;
    }

    /**
     * Checks if `value` is a DOM element.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is a DOM element, else `false`.
     * @example
     *
     * _.isElement(document.body);
     * // => true
     */
    function isElement(value) {
      return value ? value.nodeType === 1 : false;
    }

    /**
     * Checks if `value` is empty. Arrays, strings, or `arguments` objects with a
     * length of `0` and objects with no own enumerable properties are considered
     * "empty".
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Array|Object|String} value The value to inspect.
     * @returns {Boolean} Returns `true`, if the `value` is empty, else `false`.
     * @example
     *
     * _.isEmpty([1, 2, 3]);
     * // => false
     *
     * _.isEmpty({});
     * // => true
     *
     * _.isEmpty('');
     * // => true
     */
    function isEmpty(value) {
      var result = true;
      if (!value) {
        return result;
      }
      var className = toString.call(value),
          length = value.length;

      if ((className == arrayClass || className == stringClass || className == argsClass ) ||
          (className == objectClass && typeof length == 'number' && isFunction(value.splice))) {
        return !length;
      }
      forOwn(value, function() {
        return (result = false);
      });
      return result;
    }

    /**
     * Performs a deep comparison between two values to determine if they are
     * equivalent to each other. If `callback` is passed, it will be executed to
     * compare values. If `callback` returns `undefined`, comparisons will be handled
     * by the method instead. The `callback` is bound to `thisArg` and invoked with
     * two arguments; (a, b).
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} a The value to compare.
     * @param {Mixed} b The other value to compare.
     * @param {Function} [callback] The function to customize comparing values.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @param- {Array} [stackA=[]] Tracks traversed `a` objects.
     * @param- {Array} [stackB=[]] Tracks traversed `b` objects.
     * @returns {Boolean} Returns `true`, if the values are equivalent, else `false`.
     * @example
     *
     * var moe = { 'name': 'moe', 'age': 40 };
     * var copy = { 'name': 'moe', 'age': 40 };
     *
     * moe == copy;
     * // => false
     *
     * _.isEqual(moe, copy);
     * // => true
     *
     * var words = ['hello', 'goodbye'];
     * var otherWords = ['hi', 'goodbye'];
     *
     * _.isEqual(words, otherWords, function(a, b) {
     *   var reGreet = /^(?:hello|hi)$/i,
     *       aGreet = _.isString(a) && reGreet.test(a),
     *       bGreet = _.isString(b) && reGreet.test(b);
     *
     *   return (aGreet || bGreet) ? (aGreet == bGreet) : undefined;
     * });
     * // => true
     */
    function isEqual(a, b, callback, thisArg, stackA, stackB) {
      // used to indicate that when comparing objects, `a` has at least the properties of `b`
      var whereIndicator = callback === indicatorObject;
      if (typeof callback == 'function' && !whereIndicator) {
        callback = lodash.createCallback(callback, thisArg, 2);
        var result = callback(a, b);
        if (typeof result != 'undefined') {
          return !!result;
        }
      }
      // exit early for identical values
      if (a === b) {
        // treat `+0` vs. `-0` as not equal
        return a !== 0 || (1 / a == 1 / b);
      }
      var type = typeof a,
          otherType = typeof b;

      // exit early for unlike primitive values
      if (a === a &&
          (!a || (type != 'function' && type != 'object')) &&
          (!b || (otherType != 'function' && otherType != 'object'))) {
        return false;
      }
      // exit early for `null` and `undefined`, avoiding ES3's Function#call behavior
      // http://es5.github.com/#x15.3.4.4
      if (a == null || b == null) {
        return a === b;
      }
      // compare [[Class]] names
      var className = toString.call(a),
          otherClass = toString.call(b);

      if (className == argsClass) {
        className = objectClass;
      }
      if (otherClass == argsClass) {
        otherClass = objectClass;
      }
      if (className != otherClass) {
        return false;
      }
      switch (className) {
        case boolClass:
        case dateClass:
          // coerce dates and booleans to numbers, dates to milliseconds and booleans
          // to `1` or `0`, treating invalid dates coerced to `NaN` as not equal
          return +a == +b;

        case numberClass:
          // treat `NaN` vs. `NaN` as equal
          return (a != +a)
            ? b != +b
            // but treat `+0` vs. `-0` as not equal
            : (a == 0 ? (1 / a == 1 / b) : a == +b);

        case regexpClass:
        case stringClass:
          // coerce regexes to strings (http://es5.github.com/#x15.10.6.4)
          // treat string primitives and their corresponding object instances as equal
          return a == String(b);
      }
      var isArr = className == arrayClass;
      if (!isArr) {
        // unwrap any `lodash` wrapped values
        if (hasOwnProperty.call(a, '__wrapped__ ') || hasOwnProperty.call(b, '__wrapped__')) {
          return isEqual(a.__wrapped__ || a, b.__wrapped__ || b, callback, thisArg, stackA, stackB);
        }
        // exit for functions and DOM nodes
        if (className != objectClass) {
          return false;
        }
        // in older versions of Opera, `arguments` objects have `Array` constructors
        var ctorA = a.constructor,
            ctorB = b.constructor;

        // non `Object` object instances with different constructors are not equal
        if (ctorA != ctorB && !(
              isFunction(ctorA) && ctorA instanceof ctorA &&
              isFunction(ctorB) && ctorB instanceof ctorB
            )) {
          return false;
        }
      }
      // assume cyclic structures are equal
      // the algorithm for detecting cyclic structures is adapted from ES 5.1
      // section 15.12.3, abstract operation `JO` (http://es5.github.com/#x15.12.3)
      stackA || (stackA = []);
      stackB || (stackB = []);

      var length = stackA.length;
      while (length--) {
        if (stackA[length] == a) {
          return stackB[length] == b;
        }
      }
      var size = 0;
      result = true;

      // add `a` and `b` to the stack of traversed objects
      stackA.push(a);
      stackB.push(b);

      // recursively compare objects and arrays (susceptible to call stack limits)
      if (isArr) {
        length = a.length;
        size = b.length;

        // compare lengths to determine if a deep comparison is necessary
        result = size == a.length;
        if (!result && !whereIndicator) {
          return result;
        }
        // deep compare the contents, ignoring non-numeric properties
        while (size--) {
          var index = length,
              value = b[size];

          if (whereIndicator) {
            while (index--) {
              if ((result = isEqual(a[index], value, callback, thisArg, stackA, stackB))) {
                break;
              }
            }
          } else if (!(result = isEqual(a[size], value, callback, thisArg, stackA, stackB))) {
            break;
          }
        }
        return result;
      }
      // deep compare objects using `forIn`, instead of `forOwn`, to avoid `Object.keys`
      // which, in this case, is more costly
      forIn(b, function(value, key, b) {
        if (hasOwnProperty.call(b, key)) {
          // count the number of properties.
          size++;
          // deep compare each property value.
          return (result = hasOwnProperty.call(a, key) && isEqual(a[key], value, callback, thisArg, stackA, stackB));
        }
      });

      if (result && !whereIndicator) {
        // ensure both objects have the same number of properties
        forIn(a, function(value, key, a) {
          if (hasOwnProperty.call(a, key)) {
            // `size` will be `-1` if `a` has more properties than `b`
            return (result = --size > -1);
          }
        });
      }
      return result;
    }

    /**
     * Checks if `value` is, or can be coerced to, a finite number.
     *
     * Note: This is not the same as native `isFinite`, which will return true for
     * booleans and empty strings. See http://es5.github.com/#x15.1.2.5.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is finite, else `false`.
     * @example
     *
     * _.isFinite(-101);
     * // => true
     *
     * _.isFinite('10');
     * // => true
     *
     * _.isFinite(true);
     * // => false
     *
     * _.isFinite('');
     * // => false
     *
     * _.isFinite(Infinity);
     * // => false
     */
    function isFinite(value) {
      return nativeIsFinite(value) && !nativeIsNaN(parseFloat(value));
    }

    /**
     * Checks if `value` is a function.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is a function, else `false`.
     * @example
     *
     * _.isFunction(_);
     * // => true
     */
    function isFunction(value) {
      return typeof value == 'function';
    }

    /**
     * Checks if `value` is the language type of Object.
     * (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is an object, else `false`.
     * @example
     *
     * _.isObject({});
     * // => true
     *
     * _.isObject([1, 2, 3]);
     * // => true
     *
     * _.isObject(1);
     * // => false
     */
    function isObject(value) {
      // check if the value is the ECMAScript language type of Object
      // http://es5.github.com/#x8
      // and avoid a V8 bug
      // http://code.google.com/p/v8/issues/detail?id=2291
      return value ? objectTypes[typeof value] : false;
    }

    /**
     * Checks if `value` is `NaN`.
     *
     * Note: This is not the same as native `isNaN`, which will return `true` for
     * `undefined` and other values. See http://es5.github.com/#x15.1.2.4.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is `NaN`, else `false`.
     * @example
     *
     * _.isNaN(NaN);
     * // => true
     *
     * _.isNaN(new Number(NaN));
     * // => true
     *
     * isNaN(undefined);
     * // => true
     *
     * _.isNaN(undefined);
     * // => false
     */
    function isNaN(value) {
      // `NaN` as a primitive is the only value that is not equal to itself
      // (perform the [[Class]] check first to avoid errors with some host objects in IE)
      return isNumber(value) && value != +value
    }

    /**
     * Checks if `value` is `null`.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is `null`, else `false`.
     * @example
     *
     * _.isNull(null);
     * // => true
     *
     * _.isNull(undefined);
     * // => false
     */
    function isNull(value) {
      return value === null;
    }

    /**
     * Checks if `value` is a number.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is a number, else `false`.
     * @example
     *
     * _.isNumber(8.4 * 5);
     * // => true
     */
    function isNumber(value) {
      return typeof value == 'number' || toString.call(value) == numberClass;
    }

    /**
     * Checks if a given `value` is an object created by the `Object` constructor.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if `value` is a plain object, else `false`.
     * @example
     *
     * function Stooge(name, age) {
     *   this.name = name;
     *   this.age = age;
     * }
     *
     * _.isPlainObject(new Stooge('moe', 40));
     * // => false
     *
     * _.isPlainObject([1, 2, 3]);
     * // => false
     *
     * _.isPlainObject({ 'name': 'moe', 'age': 40 });
     * // => true
     */
    var isPlainObject = function(value) {
      if (!(value && toString.call(value) == objectClass)) {
        return false;
      }
      var valueOf = value.valueOf,
          objProto = typeof valueOf == 'function' && (objProto = getPrototypeOf(valueOf)) && getPrototypeOf(objProto);

      return objProto
        ? (value == objProto || getPrototypeOf(value) == objProto)
        : shimIsPlainObject(value);
    };

    /**
     * Checks if `value` is a regular expression.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is a regular expression, else `false`.
     * @example
     *
     * _.isRegExp(/moe/);
     * // => true
     */
    function isRegExp(value) {
      return value ? (typeof value == 'object' && toString.call(value) == regexpClass) : false;
    }

    /**
     * Checks if `value` is a string.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is a string, else `false`.
     * @example
     *
     * _.isString('moe');
     * // => true
     */
    function isString(value) {
      return typeof value == 'string' || toString.call(value) == stringClass;
    }

    /**
     * Checks if `value` is `undefined`.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Mixed} value The value to check.
     * @returns {Boolean} Returns `true`, if the `value` is `undefined`, else `false`.
     * @example
     *
     * _.isUndefined(void 0);
     * // => true
     */
    function isUndefined(value) {
      return typeof value == 'undefined';
    }

    /**
     * Recursively merges own enumerable properties of the source object(s), that
     * don't resolve to `undefined`, into the destination object. Subsequent sources
     * will overwrite property assignments of previous sources. If a `callback` function
     * is passed, it will be executed to produce the merged values of the destination
     * and source properties. If `callback` returns `undefined`, merging will be
     * handled by the method instead. The `callback` is bound to `thisArg` and
     * invoked with two arguments; (objectValue, sourceValue).
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The destination object.
     * @param {Object} [source1, source2, ...] The source objects.
     * @param {Function} [callback] The function to customize merging properties.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @param- {Object} [deepIndicator] Indicates that `stackA` and `stackB` are
     *  arrays of traversed objects, instead of source objects.
     * @param- {Array} [stackA=[]] Tracks traversed source objects.
     * @param- {Array} [stackB=[]] Associates values with source counterparts.
     * @returns {Object} Returns the destination object.
     * @example
     *
     * var names = {
     *   'stooges': [
     *     { 'name': 'moe' },
     *     { 'name': 'larry' }
     *   ]
     * };
     *
     * var ages = {
     *   'stooges': [
     *     { 'age': 40 },
     *     { 'age': 50 }
     *   ]
     * };
     *
     * _.merge(names, ages);
     * // => { 'stooges': [{ 'name': 'moe', 'age': 40 }, { 'name': 'larry', 'age': 50 }] }
     *
     * var food = {
     *   'fruits': ['apple'],
     *   'vegetables': ['beet']
     * };
     *
     * var otherFood = {
     *   'fruits': ['banana'],
     *   'vegetables': ['carrot']
     * };
     *
     * _.merge(food, otherFood, function(a, b) {
     *   return _.isArray(a) ? a.concat(b) : undefined;
     * });
     * // => { 'fruits': ['apple', 'banana'], 'vegetables': ['beet', 'carrot] }
     */
    function merge(object, source, deepIndicator) {
      var args = arguments,
          index = 0,
          length = 2;

      if (!isObject(object)) {
        return object;
      }
      if (deepIndicator === indicatorObject) {
        var callback = args[3],
            stackA = args[4],
            stackB = args[5];
      } else {
        stackA = [];
        stackB = [];

        // allows working with `_.reduce` and `_.reduceRight` without
        // using their `callback` arguments, `index|key` and `collection`
        if (typeof deepIndicator != 'number') {
          length = args.length;
        }
        if (length > 3 && typeof args[length - 2] == 'function') {
          callback = lodash.createCallback(args[--length - 1], args[length--], 2);
        } else if (length > 2 && typeof args[length - 1] == 'function') {
          callback = args[--length];
        }
      }
      while (++index < length) {
        (isArray(args[index]) ? forEach : forOwn)(args[index], function(source, key) {
          var found,
              isArr,
              result = source,
              value = object[key];

          if (source && ((isArr = isArray(source)) || isPlainObject(source))) {
            // avoid merging previously merged cyclic sources
            var stackLength = stackA.length;
            while (stackLength--) {
              if ((found = stackA[stackLength] == source)) {
                value = stackB[stackLength];
                break;
              }
            }
            if (!found) {
              var isShallow;
              if (callback) {
                result = callback(value, source);
                if ((isShallow = typeof result != 'undefined')) {
                  value = result;
                }
              }
              if (!isShallow) {
                value = isArr
                  ? (isArray(value) ? value : [])
                  : (isPlainObject(value) ? value : {});
              }
              // add `source` and associated `value` to the stack of traversed objects
              stackA.push(source);
              stackB.push(value);

              // recursively merge objects and arrays (susceptible to call stack limits)
              if (!isShallow) {
                value = merge(value, source, indicatorObject, callback, stackA, stackB);
              }
            }
          }
          else {
            if (callback) {
              result = callback(value, source);
              if (typeof result == 'undefined') {
                result = source;
              }
            }
            if (typeof result != 'undefined') {
              value = result;
            }
          }
          object[key] = value;
        });
      }
      return object;
    }

    /**
     * Creates a shallow clone of `object` excluding the specified properties.
     * Property names may be specified as individual arguments or as arrays of
     * property names. If a `callback` function is passed, it will be executed
     * for each property in the `object`, omitting the properties `callback`
     * returns truthy for. The `callback` is bound to `thisArg` and invoked
     * with three arguments; (value, key, object).
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The source object.
     * @param {Function|String} callback|[prop1, prop2, ...] The properties to omit
     *  or the function called per iteration.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Object} Returns an object without the omitted properties.
     * @example
     *
     * _.omit({ 'name': 'moe', 'age': 40 }, 'age');
     * // => { 'name': 'moe' }
     *
     * _.omit({ 'name': 'moe', 'age': 40 }, function(value) {
     *   return typeof value == 'number';
     * });
     * // => { 'name': 'moe' }
     */
    function omit(object, callback, thisArg) {
      var isFunc = typeof callback == 'function',
          result = {};

      if (isFunc) {
        callback = lodash.createCallback(callback, thisArg);
      } else {
        var props = concat.apply(arrayRef, nativeSlice.call(arguments, 1));
      }
      forIn(object, function(value, key, object) {
        if (isFunc
              ? !callback(value, key, object)
              : indexOf(props, key) < 0
            ) {
          result[key] = value;
        }
      });
      return result;
    }

    /**
     * Creates a two dimensional array of the given object's key-value pairs,
     * i.e. `[[key1, value1], [key2, value2]]`.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The object to inspect.
     * @returns {Array} Returns new array of key-value pairs.
     * @example
     *
     * _.pairs({ 'moe': 30, 'larry': 40 });
     * // => [['moe', 30], ['larry', 40]] (order is not guaranteed)
     */
    function pairs(object) {
      var index = -1,
          props = keys(object),
          length = props.length,
          result = Array(length);

      while (++index < length) {
        var key = props[index];
        result[index] = [key, object[key]];
      }
      return result;
    }

    /**
     * Creates a shallow clone of `object` composed of the specified properties.
     * Property names may be specified as individual arguments or as arrays of property
     * names. If `callback` is passed, it will be executed for each property in the
     * `object`, picking the properties `callback` returns truthy for. The `callback`
     * is bound to `thisArg` and invoked with three arguments; (value, key, object).
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The source object.
     * @param {Array|Function|String} callback|[prop1, prop2, ...] The function called
     *  per iteration or properties to pick, either as individual arguments or arrays.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Object} Returns an object composed of the picked properties.
     * @example
     *
     * _.pick({ 'name': 'moe', '_userid': 'moe1' }, 'name');
     * // => { 'name': 'moe' }
     *
     * _.pick({ 'name': 'moe', '_userid': 'moe1' }, function(value, key) {
     *   return key.charAt(0) != '_';
     * });
     * // => { 'name': 'moe' }
     */
    function pick(object, callback, thisArg) {
      var result = {};
      if (typeof callback != 'function') {
        var index = -1,
            props = concat.apply(arrayRef, nativeSlice.call(arguments, 1)),
            length = isObject(object) ? props.length : 0;

        while (++index < length) {
          var key = props[index];
          if (key in object) {
            result[key] = object[key];
          }
        }
      } else {
        callback = lodash.createCallback(callback, thisArg);
        forIn(object, function(value, key, object) {
          if (callback(value, key, object)) {
            result[key] = value;
          }
        });
      }
      return result;
    }

    /**
     * Creates an array composed of the own enumerable property values of `object`.
     *
     * @static
     * @memberOf _
     * @category Objects
     * @param {Object} object The object to inspect.
     * @returns {Array} Returns a new array of property values.
     * @example
     *
     * _.values({ 'one': 1, 'two': 2, 'three': 3 });
     * // => [1, 2, 3] (order is not guaranteed)
     */
    function values(object) {
      var index = -1,
          props = keys(object),
          length = props.length,
          result = Array(length);

      while (++index < length) {
        result[index] = object[props[index]];
      }
      return result;
    }

    /*--------------------------------------------------------------------------*/

    /**
     * Creates an array of elements from the specified indexes, or keys, of the
     * `collection`. Indexes may be specified as individual arguments or as arrays
     * of indexes.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Array|Number|String} [index1, index2, ...] The indexes of
     *  `collection` to retrieve, either as individual arguments or arrays.
     * @returns {Array} Returns a new array of elements corresponding to the
     *  provided indexes.
     * @example
     *
     * _.at(['a', 'b', 'c', 'd', 'e'], [0, 2, 4]);
     * // => ['a', 'c', 'e']
     *
     * _.at(['moe', 'larry', 'curly'], 0, 2);
     * // => ['moe', 'curly']
     */
    function at(collection) {
      var index = -1,
          props = concat.apply(arrayRef, nativeSlice.call(arguments, 1)),
          length = props.length,
          result = Array(length);

      while(++index < length) {
        result[index] = collection[props[index]];
      }
      return result;
    }

    /**
     * Checks if a given `target` element is present in a `collection` using strict
     * equality for comparisons, i.e. `===`. If `fromIndex` is negative, it is used
     * as the offset from the end of the collection.
     *
     * @static
     * @memberOf _
     * @alias include
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Mixed} target The value to check for.
     * @param {Number} [fromIndex=0] The index to search from.
     * @returns {Boolean} Returns `true` if the `target` element is found, else `false`.
     * @example
     *
     * _.contains([1, 2, 3], 1);
     * // => true
     *
     * _.contains([1, 2, 3], 1, 2);
     * // => false
     *
     * _.contains({ 'name': 'moe', 'age': 40 }, 'moe');
     * // => true
     *
     * _.contains('curly', 'ur');
     * // => true
     */
    function contains(collection, target, fromIndex) {
      var index = -1,
          length = collection ? collection.length : 0,
          result = false;

      fromIndex = (fromIndex < 0 ? nativeMax(0, length + fromIndex) : fromIndex) || 0;
      if (typeof length == 'number') {
        result = (isString(collection)
          ? collection.indexOf(target, fromIndex)
          : indexOf(collection, target, fromIndex)
        ) > -1;
      } else {
        forOwn(collection, function(value) {
          if (++index >= fromIndex) {
            return !(result = value === target);
          }
        });
      }
      return result;
    }

    /**
     * Creates an object composed of keys returned from running each element of the
     * `collection` through the given `callback`. The corresponding value of each key
     * is the number of times the key was returned by the `callback`. The `callback`
     * is bound to `thisArg` and invoked with three arguments; (value, index|key, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Object} Returns the composed aggregate object.
     * @example
     *
     * _.countBy([4.3, 6.1, 6.4], function(num) { return Math.floor(num); });
     * // => { '4': 1, '6': 2 }
     *
     * _.countBy([4.3, 6.1, 6.4], function(num) { return this.floor(num); }, Math);
     * // => { '4': 1, '6': 2 }
     *
     * _.countBy(['one', 'two', 'three'], 'length');
     * // => { '3': 2, '5': 1 }
     */
    function countBy(collection, callback, thisArg) {
      var result = {};
      callback = lodash.createCallback(callback, thisArg);

      forEach(collection, function(value, key, collection) {
        key = String(callback(value, key, collection));
        (hasOwnProperty.call(result, key) ? result[key]++ : result[key] = 1);
      });
      return result;
    }

    /**
     * Checks if the `callback` returns a truthy value for **all** elements of a
     * `collection`. The `callback` is bound to `thisArg` and invoked with three
     * arguments; (value, index|key, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @alias all
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Boolean} Returns `true` if all elements pass the callback check,
     *  else `false`.
     * @example
     *
     * _.every([true, 1, null, 'yes'], Boolean);
     * // => false
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.every(stooges, 'age');
     * // => true
     *
     * // using "_.where" callback shorthand
     * _.every(stooges, { 'age': 50 });
     * // => false
     */
    function every(collection, callback, thisArg) {
      var result = true;
      callback = lodash.createCallback(callback, thisArg);

      var index = -1,
          length = collection ? collection.length : 0;

      if (typeof length == 'number') {
        while (++index < length) {
          if (!(result = !!callback(collection[index], index, collection))) {
            break;
          }
        }
      } else {
        forOwn(collection, function(value, index, collection) {
          return (result = !!callback(value, index, collection));
        });
      }
      return result;
    }

    /**
     * Examines each element in a `collection`, returning an array of all elements
     * the `callback` returns truthy for. The `callback` is bound to `thisArg` and
     * invoked with three arguments; (value, index|key, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @alias select
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a new array of elements that passed the callback check.
     * @example
     *
     * var evens = _.filter([1, 2, 3, 4, 5, 6], function(num) { return num % 2 == 0; });
     * // => [2, 4, 6]
     *
     * var food = [
     *   { 'name': 'apple',  'organic': false, 'type': 'fruit' },
     *   { 'name': 'carrot', 'organic': true,  'type': 'vegetable' }
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.filter(food, 'organic');
     * // => [{ 'name': 'carrot', 'organic': true, 'type': 'vegetable' }]
     *
     * // using "_.where" callback shorthand
     * _.filter(food, { 'type': 'fruit' });
     * // => [{ 'name': 'apple', 'organic': false, 'type': 'fruit' }]
     */
    function filter(collection, callback, thisArg) {
      var result = [];
      callback = lodash.createCallback(callback, thisArg);

      var index = -1,
          length = collection ? collection.length : 0;

      if (typeof length == 'number') {
        while (++index < length) {
          var value = collection[index];
          if (callback(value, index, collection)) {
            result.push(value);
          }
        }
      } else {
        forOwn(collection, function(value, index, collection) {
          if (callback(value, index, collection)) {
            result.push(value);
          }
        });
      }
      return result;
    }

    /**
     * Examines each element in a `collection`, returning the first that the `callback`
     * returns truthy for. The `callback` is bound to `thisArg` and invoked with three
     * arguments; (value, index|key, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @alias detect
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the found element, else `undefined`.
     * @example
     *
     * _.find([1, 2, 3, 4], function(num) {
     *   return num % 2 == 0;
     * });
     * // => 2
     *
     * var food = [
     *   { 'name': 'apple',  'organic': false, 'type': 'fruit' },
     *   { 'name': 'banana', 'organic': true,  'type': 'fruit' },
     *   { 'name': 'beet',   'organic': false, 'type': 'vegetable' }
     * ];
     *
     * // using "_.where" callback shorthand
     * _.find(food, { 'type': 'vegetable' });
     * // => { 'name': 'beet', 'organic': false, 'type': 'vegetable' }
     *
     * // using "_.pluck" callback shorthand
     * _.find(food, 'organic');
     * // => { 'name': 'banana', 'organic': true, 'type': 'fruit' }
     */
    function find(collection, callback, thisArg) {
      callback = lodash.createCallback(callback, thisArg);

      var index = -1,
          length = collection ? collection.length : 0;

      if (typeof length == 'number') {
        while (++index < length) {
          var value = collection[index];
          if (callback(value, index, collection)) {
            return value;
          }
        }
      } else {
        var result;
        forOwn(collection, function(value, index, collection) {
          if (callback(value, index, collection)) {
            result = value;
            return false;
          }
        });
        return result;
      }
    }

    /**
     * Iterates over a `collection`, executing the `callback` for each element in
     * the `collection`. The `callback` is bound to `thisArg` and invoked with three
     * arguments; (value, index|key, collection). Callbacks may exit iteration early
     * by explicitly returning `false`.
     *
     * @static
     * @memberOf _
     * @alias each
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function} [callback=identity] The function called per iteration.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array|Object|String} Returns `collection`.
     * @example
     *
     * _([1, 2, 3]).forEach(alert).join(',');
     * // => alerts each number and returns '1,2,3'
     *
     * _.forEach({ 'one': 1, 'two': 2, 'three': 3 }, alert);
     * // => alerts each number value (order is not guaranteed)
     */
    function forEach(collection, callback, thisArg) {
      var index = -1,
          length = collection ? collection.length : 0;

      callback = callback && typeof thisArg == 'undefined' ? callback : lodash.createCallback(callback, thisArg);
      if (typeof length == 'number') {
        while (++index < length) {
          if (callback(collection[index], index, collection) === false) {
            break;
          }
        }
      } else {
        forOwn(collection, callback);
      }
      return collection;
    }

    /**
     * Creates an object composed of keys returned from running each element of the
     * `collection` through the `callback`. The corresponding value of each key is
     * an array of elements passed to `callback` that returned the key. The `callback`
     * is bound to `thisArg` and invoked with three arguments; (value, index|key, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Object} Returns the composed aggregate object.
     * @example
     *
     * _.groupBy([4.2, 6.1, 6.4], function(num) { return Math.floor(num); });
     * // => { '4': [4.2], '6': [6.1, 6.4] }
     *
     * _.groupBy([4.2, 6.1, 6.4], function(num) { return this.floor(num); }, Math);
     * // => { '4': [4.2], '6': [6.1, 6.4] }
     *
     * // using "_.pluck" callback shorthand
     * _.groupBy(['one', 'two', 'three'], 'length');
     * // => { '3': ['one', 'two'], '5': ['three'] }
     */
    function groupBy(collection, callback, thisArg) {
      var result = {};
      callback = lodash.createCallback(callback, thisArg);

      forEach(collection, function(value, key, collection) {
        key = String(callback(value, key, collection));
        (hasOwnProperty.call(result, key) ? result[key] : result[key] = []).push(value);
      });
      return result;
    }

    /**
     * Invokes the method named by `methodName` on each element in the `collection`,
     * returning an array of the results of each invoked method. Additional arguments
     * will be passed to each invoked method. If `methodName` is a function, it will
     * be invoked for, and `this` bound to, each element in the `collection`.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|String} methodName The name of the method to invoke or
     *  the function invoked per iteration.
     * @param {Mixed} [arg1, arg2, ...] Arguments to invoke the method with.
     * @returns {Array} Returns a new array of the results of each invoked method.
     * @example
     *
     * _.invoke([[5, 1, 7], [3, 2, 1]], 'sort');
     * // => [[1, 5, 7], [1, 2, 3]]
     *
     * _.invoke([123, 456], String.prototype.split, '');
     * // => [['1', '2', '3'], ['4', '5', '6']]
     */
    function invoke(collection, methodName) {
      var args = nativeSlice.call(arguments, 2),
          index = -1,
          isFunc = typeof methodName == 'function',
          length = collection ? collection.length : 0,
          result = Array(typeof length == 'number' ? length : 0);

      forEach(collection, function(value) {
        result[++index] = (isFunc ? methodName : value[methodName]).apply(value, args);
      });
      return result;
    }

    /**
     * Creates an array of values by running each element in the `collection`
     * through the `callback`. The `callback` is bound to `thisArg` and invoked with
     * three arguments; (value, index|key, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @alias collect
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a new array of the results of each `callback` execution.
     * @example
     *
     * _.map([1, 2, 3], function(num) { return num * 3; });
     * // => [3, 6, 9]
     *
     * _.map({ 'one': 1, 'two': 2, 'three': 3 }, function(num) { return num * 3; });
     * // => [3, 6, 9] (order is not guaranteed)
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.map(stooges, 'name');
     * // => ['moe', 'larry']
     */
    function map(collection, callback, thisArg) {
      var index = -1,
          length = collection ? collection.length : 0;

      callback = lodash.createCallback(callback, thisArg);
      if (typeof length == 'number') {
        var result = Array(length);
        while (++index < length) {
          result[index] = callback(collection[index], index, collection);
        }
      } else {
        result = [];
        forOwn(collection, function(value, key, collection) {
          result[++index] = callback(value, key, collection);
        });
      }
      return result;
    }

    /**
     * Retrieves the maximum value of an `array`. If `callback` is passed,
     * it will be executed for each value in the `array` to generate the
     * criterion by which the value is ranked. The `callback` is bound to
     * `thisArg` and invoked with three arguments; (value, index, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the maximum value.
     * @example
     *
     * _.max([4, 2, 8, 6]);
     * // => 8
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * _.max(stooges, function(stooge) { return stooge.age; });
     * // => { 'name': 'larry', 'age': 50 };
     *
     * // using "_.pluck" callback shorthand
     * _.max(stooges, 'age');
     * // => { 'name': 'larry', 'age': 50 };
     */
    function max(collection, callback, thisArg) {
      var computed = -Infinity,
          result = computed;

      if (!callback && isArray(collection)) {
        var index = -1,
            length = collection.length;

        while (++index < length) {
          var value = collection[index];
          if (value > result) {
            result = value;
          }
        }
      } else {
        callback = (!callback && isString(collection))
          ? charAtCallback
          : lodash.createCallback(callback, thisArg);

        forEach(collection, function(value, index, collection) {
          var current = callback(value, index, collection);
          if (current > computed) {
            computed = current;
            result = value;
          }
        });
      }
      return result;
    }

    /**
     * Retrieves the minimum value of an `array`. If `callback` is passed,
     * it will be executed for each value in the `array` to generate the
     * criterion by which the value is ranked. The `callback` is bound to `thisArg`
     * and invoked with three arguments; (value, index, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the minimum value.
     * @example
     *
     * _.min([4, 2, 8, 6]);
     * // => 2
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * _.min(stooges, function(stooge) { return stooge.age; });
     * // => { 'name': 'moe', 'age': 40 };
     *
     * // using "_.pluck" callback shorthand
     * _.min(stooges, 'age');
     * // => { 'name': 'moe', 'age': 40 };
     */
    function min(collection, callback, thisArg) {
      var computed = Infinity,
          result = computed;

      if (!callback && isArray(collection)) {
        var index = -1,
            length = collection.length;

        while (++index < length) {
          var value = collection[index];
          if (value < result) {
            result = value;
          }
        }
      } else {
        callback = (!callback && isString(collection))
          ? charAtCallback
          : lodash.createCallback(callback, thisArg);

        forEach(collection, function(value, index, collection) {
          var current = callback(value, index, collection);
          if (current < computed) {
            computed = current;
            result = value;
          }
        });
      }
      return result;
    }

    /**
     * Retrieves the value of a specified property from all elements in the `collection`.
     *
     * @static
     * @memberOf _
     * @type Function
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {String} property The property to pluck.
     * @returns {Array} Returns a new array of property values.
     * @example
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * _.pluck(stooges, 'name');
     * // => ['moe', 'larry']
     */
    function pluck(collection, property) {
      var index = -1,
          length = collection ? collection.length : 0;

      if (typeof length == 'number') {
        var result = Array(length);
        while (++index < length) {
          result[index] = collection[index][property];
        }
      }
      return result || map(collection, property);
    }

    /**
     * Reduces a `collection` to a value which is the accumulated result of running
     * each element in the `collection` through the `callback`, where each successive
     * `callback` execution consumes the return value of the previous execution.
     * If `accumulator` is not passed, the first element of the `collection` will be
     * used as the initial `accumulator` value. The `callback` is bound to `thisArg`
     * and invoked with four arguments; (accumulator, value, index|key, collection).
     *
     * @static
     * @memberOf _
     * @alias foldl, inject
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function} [callback=identity] The function called per iteration.
     * @param {Mixed} [accumulator] Initial value of the accumulator.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the accumulated value.
     * @example
     *
     * var sum = _.reduce([1, 2, 3], function(sum, num) {
     *   return sum + num;
     * });
     * // => 6
     *
     * var mapped = _.reduce({ 'a': 1, 'b': 2, 'c': 3 }, function(result, num, key) {
     *   result[key] = num * 3;
     *   return result;
     * }, {});
     * // => { 'a': 3, 'b': 6, 'c': 9 }
     */
    function reduce(collection, callback, accumulator, thisArg) {
      if (!collection) return accumulator;
      var noaccum = arguments.length < 3;
      callback = lodash.createCallback(callback, thisArg, 4);

      var index = -1,
          length = collection.length;

      if (typeof length == 'number') {
        if (noaccum) {
          accumulator = collection[++index];
        }
        while (++index < length) {
          accumulator = callback(accumulator, collection[index], index, collection);
        }
      } else {
        forOwn(collection, function(value, index, collection) {
          accumulator = noaccum
            ? (noaccum = false, value)
            : callback(accumulator, value, index, collection)
        });
      }
      return accumulator;
    }

    /**
     * This method is similar to `_.reduce`, except that it iterates over a
     * `collection` from right to left.
     *
     * @static
     * @memberOf _
     * @alias foldr
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function} [callback=identity] The function called per iteration.
     * @param {Mixed} [accumulator] Initial value of the accumulator.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the accumulated value.
     * @example
     *
     * var list = [[0, 1], [2, 3], [4, 5]];
     * var flat = _.reduceRight(list, function(a, b) { return a.concat(b); }, []);
     * // => [4, 5, 2, 3, 0, 1]
     */
    function reduceRight(collection, callback, accumulator, thisArg) {
      var iterable = collection,
          length = collection ? collection.length : 0,
          noaccum = arguments.length < 3;

      if (typeof length != 'number') {
        var props = keys(collection);
        length = props.length;
      }
      callback = lodash.createCallback(callback, thisArg, 4);
      forEach(collection, function(value, index, collection) {
        index = props ? props[--length] : --length;
        accumulator = noaccum
          ? (noaccum = false, iterable[index])
          : callback(accumulator, iterable[index], index, collection);
      });
      return accumulator;
    }

    /**
     * The opposite of `_.filter`, this method returns the elements of a
     * `collection` that `callback` does **not** return truthy for.
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a new array of elements that did **not** pass the
     *  callback check.
     * @example
     *
     * var odds = _.reject([1, 2, 3, 4, 5, 6], function(num) { return num % 2 == 0; });
     * // => [1, 3, 5]
     *
     * var food = [
     *   { 'name': 'apple',  'organic': false, 'type': 'fruit' },
     *   { 'name': 'carrot', 'organic': true,  'type': 'vegetable' }
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.reject(food, 'organic');
     * // => [{ 'name': 'apple', 'organic': false, 'type': 'fruit' }]
     *
     * // using "_.where" callback shorthand
     * _.reject(food, { 'type': 'fruit' });
     * // => [{ 'name': 'carrot', 'organic': true, 'type': 'vegetable' }]
     */
    function reject(collection, callback, thisArg) {
      callback = lodash.createCallback(callback, thisArg);
      return filter(collection, function(value, index, collection) {
        return !callback(value, index, collection);
      });
    }

    /**
     * Creates an array of shuffled `array` values, using a version of the
     * Fisher-Yates shuffle. See http://en.wikipedia.org/wiki/Fisher-Yates_shuffle.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to shuffle.
     * @returns {Array} Returns a new shuffled collection.
     * @example
     *
     * _.shuffle([1, 2, 3, 4, 5, 6]);
     * // => [4, 1, 6, 3, 5, 2]
     */
    function shuffle(collection) {
      var index = -1,
          length = collection ? collection.length : 0,
          result = Array(typeof length == 'number' ? length : 0);

      forEach(collection, function(value) {
        var rand = floor(nativeRandom() * (++index + 1));
        result[index] = result[rand];
        result[rand] = value;
      });
      return result;
    }

    /**
     * Gets the size of the `collection` by returning `collection.length` for arrays
     * and array-like objects or the number of own enumerable properties for objects.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to inspect.
     * @returns {Number} Returns `collection.length` or number of own enumerable properties.
     * @example
     *
     * _.size([1, 2]);
     * // => 2
     *
     * _.size({ 'one': 1, 'two': 2, 'three': 3 });
     * // => 3
     *
     * _.size('curly');
     * // => 5
     */
    function size(collection) {
      var length = collection ? collection.length : 0;
      return typeof length == 'number' ? length : keys(collection).length;
    }

    /**
     * Checks if the `callback` returns a truthy value for **any** element of a
     * `collection`. The function returns as soon as it finds passing value, and
     * does not iterate over the entire `collection`. The `callback` is bound to
     * `thisArg` and invoked with three arguments; (value, index|key, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @alias any
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Boolean} Returns `true` if any element passes the callback check,
     *  else `false`.
     * @example
     *
     * _.some([null, 0, 'yes', false], Boolean);
     * // => true
     *
     * var food = [
     *   { 'name': 'apple',  'organic': false, 'type': 'fruit' },
     *   { 'name': 'carrot', 'organic': true,  'type': 'vegetable' }
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.some(food, 'organic');
     * // => true
     *
     * // using "_.where" callback shorthand
     * _.some(food, { 'type': 'meat' });
     * // => false
     */
    function some(collection, callback, thisArg) {
      var result;
      callback = lodash.createCallback(callback, thisArg);

      var index = -1,
          length = collection ? collection.length : 0;

      if (typeof length == 'number') {
        while (++index < length) {
          if ((result = callback(collection[index], index, collection))) {
            break;
          }
        }
      } else {
        forOwn(collection, function(value, index, collection) {
          return !(result = callback(value, index, collection));
        });
      }
      return !!result;
    }

    /**
     * Creates an array of elements, sorted in ascending order by the results of
     * running each element in the `collection` through the `callback`. This method
     * performs a stable sort, that is, it will preserve the original sort order of
     * equal elements. The `callback` is bound to `thisArg` and invoked with three
     * arguments; (value, index|key, collection).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a new array of sorted elements.
     * @example
     *
     * _.sortBy([1, 2, 3], function(num) { return Math.sin(num); });
     * // => [3, 1, 2]
     *
     * _.sortBy([1, 2, 3], function(num) { return this.sin(num); }, Math);
     * // => [3, 1, 2]
     *
     * // using "_.pluck" callback shorthand
     * _.sortBy(['banana', 'strawberry', 'apple'], 'length');
     * // => ['apple', 'banana', 'strawberry']
     */
    function sortBy(collection, callback, thisArg) {
      var index = -1,
          length = collection ? collection.length : 0,
          result = Array(typeof length == 'number' ? length : 0);

      callback = lodash.createCallback(callback, thisArg);
      forEach(collection, function(value, key, collection) {
        result[++index] = {
          'criteria': callback(value, key, collection),
          'index': index,
          'value': value
        };
      });

      length = result.length;
      result.sort(compareAscending);
      while (length--) {
        result[length] = result[length].value;
      }
      return result;
    }

    /**
     * Converts the `collection` to an array.
     *
     * @static
     * @memberOf _
     * @category Collections
     * @param {Array|Object|String} collection The collection to convert.
     * @returns {Array} Returns the new converted array.
     * @example
     *
     * (function() { return _.toArray(arguments).slice(1); })(1, 2, 3, 4);
     * // => [2, 3, 4]
     */
    function toArray(collection) {
      if (collection && typeof collection.length == 'number') {
        return slice(collection);
      }
      return values(collection);
    }

    /**
     * Examines each element in a `collection`, returning an array of all elements
     * that have the given `properties`. When checking `properties`, this method
     * performs a deep comparison between values to determine if they are equivalent
     * to each other.
     *
     * @static
     * @memberOf _
     * @type Function
     * @category Collections
     * @param {Array|Object|String} collection The collection to iterate over.
     * @param {Object} properties The object of property values to filter by.
     * @returns {Array} Returns a new array of elements that have the given `properties`.
     * @example
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * _.where(stooges, { 'age': 40 });
     * // => [{ 'name': 'moe', 'age': 40 }]
     */
    var where = filter;

    /*--------------------------------------------------------------------------*/

    /**
     * Creates an array with all falsey values of `array` removed. The values
     * `false`, `null`, `0`, `""`, `undefined` and `NaN` are all falsey.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to compact.
     * @returns {Array} Returns a new filtered array.
     * @example
     *
     * _.compact([0, 1, false, 2, '', 3]);
     * // => [1, 2, 3]
     */
    function compact(array) {
      var index = -1,
          length = array ? array.length : 0,
          result = [];

      while (++index < length) {
        var value = array[index];
        if (value) {
          result.push(value);
        }
      }
      return result;
    }

    /**
     * Creates an array of `array` elements not present in the other arrays
     * using strict equality for comparisons, i.e. `===`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to process.
     * @param {Array} [array1, array2, ...] Arrays to check.
     * @returns {Array} Returns a new array of `array` elements not present in the
     *  other arrays.
     * @example
     *
     * _.difference([1, 2, 3, 4, 5], [5, 2, 10]);
     * // => [1, 3, 4]
     */
    function difference(array) {
      var index = -1,
          length = array ? array.length : 0,
          flattened = concat.apply(arrayRef, nativeSlice.call(arguments, 1)),
          contains = cachedContains(flattened),
          result = [];

      while (++index < length) {
        var value = array[index];
        if (!contains(value)) {
          result.push(value);
        }
      }
      return result;
    }

    /**
     * This method is similar to `_.find`, except that it returns the index of
     * the element that passes the callback check, instead of the element itself.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to search.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the index of the found element, else `-1`.
     * @example
     *
     * _.findIndex(['apple', 'banana', 'beet'], function(food) {
     *   return /^b/.test(food);
     * });
     * // => 1
     */
    function findIndex(array, callback, thisArg) {
      var index = -1,
          length = array ? array.length : 0;

      callback = lodash.createCallback(callback, thisArg);
      while (++index < length) {
        if (callback(array[index], index, array)) {
          return index;
        }
      }
      return -1;
    }

    /**
     * Gets the first element of the `array`. If a number `n` is passed, the first
     * `n` elements of the `array` are returned. If a `callback` function is passed,
     * elements at the beginning of the array are returned as long as the `callback`
     * returns truthy. The `callback` is bound to `thisArg` and invoked with three
     * arguments; (value, index, array).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @alias head, take
     * @category Arrays
     * @param {Array} array The array to query.
     * @param {Function|Object|Number|String} [callback|n] The function called
     *  per element or the number of elements to return. If a property name or
     *  object is passed, it will be used to create a "_.pluck" or "_.where"
     *  style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the first element(s) of `array`.
     * @example
     *
     * _.first([1, 2, 3]);
     * // => 1
     *
     * _.first([1, 2, 3], 2);
     * // => [1, 2]
     *
     * _.first([1, 2, 3], function(num) {
     *   return num < 3;
     * });
     * // => [1, 2]
     *
     * var food = [
     *   { 'name': 'banana', 'organic': true },
     *   { 'name': 'beet',   'organic': false },
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.first(food, 'organic');
     * // => [{ 'name': 'banana', 'organic': true }]
     *
     * var food = [
     *   { 'name': 'apple',  'type': 'fruit' },
     *   { 'name': 'banana', 'type': 'fruit' },
     *   { 'name': 'beet',   'type': 'vegetable' }
     * ];
     *
     * // using "_.where" callback shorthand
     * _.first(food, { 'type': 'fruit' });
     * // => [{ 'name': 'apple', 'type': 'fruit' }, { 'name': 'banana', 'type': 'fruit' }]
     */
    function first(array, callback, thisArg) {
      if (array) {
        var n = 0,
            length = array.length;

        if (typeof callback != 'number' && callback != null) {
          var index = -1;
          callback = lodash.createCallback(callback, thisArg);
          while (++index < length && callback(array[index], index, array)) {
            n++;
          }
        } else {
          n = callback;
          if (n == null || thisArg) {
            return array[0];
          }
        }
        return slice(array, 0, nativeMin(nativeMax(0, n), length));
      }
    }

    /**
     * Flattens a nested array (the nesting can be to any depth). If `isShallow`
     * is truthy, `array` will only be flattened a single level. If `callback`
     * is passed, each element of `array` is passed through a `callback` before
     * flattening. The `callback` is bound to `thisArg` and invoked with three
     * arguments; (value, index, array).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to flatten.
     * @param {Boolean} [isShallow=false] A flag to indicate only flattening a single level.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a new flattened array.
     * @example
     *
     * _.flatten([1, [2], [3, [[4]]]]);
     * // => [1, 2, 3, 4];
     *
     * _.flatten([1, [2], [3, [[4]]]], true);
     * // => [1, 2, 3, [[4]]];
     *
     * var stooges = [
     *   { 'name': 'curly', 'quotes': ['Oh, a wise guy, eh?', 'Poifect!'] },
     *   { 'name': 'moe', 'quotes': ['Spread out!', 'You knucklehead!'] }
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.flatten(stooges, 'quotes');
     * // => ['Oh, a wise guy, eh?', 'Poifect!', 'Spread out!', 'You knucklehead!']
     */
    function flatten(array, isShallow, callback, thisArg) {
      var index = -1,
          length = array ? array.length : 0,
          result = [];

      // juggle arguments
      if (typeof isShallow != 'boolean' && isShallow != null) {
        thisArg = callback;
        callback = isShallow;
        isShallow = false;
      }
      if (callback != null) {
        callback = lodash.createCallback(callback, thisArg);
      }
      while (++index < length) {
        var value = array[index];
        if (callback) {
          value = callback(value, index, array);
        }
        // recursively flatten arrays (susceptible to call stack limits)
        if (isArray(value)) {
          push.apply(result, isShallow ? value : flatten(value));
        } else {
          result.push(value);
        }
      }
      return result;
    }

    /**
     * Gets the index at which the first occurrence of `value` is found using
     * strict equality for comparisons, i.e. `===`. If the `array` is already
     * sorted, passing `true` for `fromIndex` will run a faster binary search.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to search.
     * @param {Mixed} value The value to search for.
     * @param {Boolean|Number} [fromIndex=0] The index to search from or `true` to
     *  perform a binary search on a sorted `array`.
     * @returns {Number} Returns the index of the matched value or `-1`.
     * @example
     *
     * _.indexOf([1, 2, 3, 1, 2, 3], 2);
     * // => 1
     *
     * _.indexOf([1, 2, 3, 1, 2, 3], 2, 3);
     * // => 4
     *
     * _.indexOf([1, 1, 2, 2, 3, 3], 2, true);
     * // => 2
     */
    function indexOf(array, value, fromIndex) {
      var index = -1,
          length = array ? array.length : 0;

      if (typeof fromIndex == 'number') {
        index = (fromIndex < 0 ? nativeMax(0, length + fromIndex) : fromIndex || 0) - 1;
      } else if (fromIndex) {
        index = sortedIndex(array, value);
        return array[index] === value ? index : -1;
      }
      while (++index < length) {
        if (array[index] === value) {
          return index;
        }
      }
      return -1;
    }

    /**
     * Gets all but the last element of `array`. If a number `n` is passed, the
     * last `n` elements are excluded from the result. If a `callback` function
     * is passed, elements at the end of the array are excluded from the result
     * as long as the `callback` returns truthy. The `callback` is bound to
     * `thisArg` and invoked with three arguments; (value, index, array).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to query.
     * @param {Function|Object|Number|String} [callback|n=1] The function called
     *  per element or the number of elements to exclude. If a property name or
     *  object is passed, it will be used to create a "_.pluck" or "_.where"
     *  style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a slice of `array`.
     * @example
     *
     * _.initial([1, 2, 3]);
     * // => [1, 2]
     *
     * _.initial([1, 2, 3], 2);
     * // => [1]
     *
     * _.initial([1, 2, 3], function(num) {
     *   return num > 1;
     * });
     * // => [1]
     *
     * var food = [
     *   { 'name': 'beet',   'organic': false },
     *   { 'name': 'carrot', 'organic': true }
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.initial(food, 'organic');
     * // => [{ 'name': 'beet',   'organic': false }]
     *
     * var food = [
     *   { 'name': 'banana', 'type': 'fruit' },
     *   { 'name': 'beet',   'type': 'vegetable' },
     *   { 'name': 'carrot', 'type': 'vegetable' }
     * ];
     *
     * // using "_.where" callback shorthand
     * _.initial(food, { 'type': 'vegetable' });
     * // => [{ 'name': 'banana', 'type': 'fruit' }]
     */
    function initial(array, callback, thisArg) {
      if (!array) {
        return [];
      }
      var n = 0,
          length = array.length;

      if (typeof callback != 'number' && callback != null) {
        var index = length;
        callback = lodash.createCallback(callback, thisArg);
        while (index-- && callback(array[index], index, array)) {
          n++;
        }
      } else {
        n = (callback == null || thisArg) ? 1 : callback || n;
      }
      return slice(array, 0, nativeMin(nativeMax(0, length - n), length));
    }

    /**
     * Computes the intersection of all the passed-in arrays using strict equality
     * for comparisons, i.e. `===`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} [array1, array2, ...] Arrays to process.
     * @returns {Array} Returns a new array of unique elements that are present
     *  in **all** of the arrays.
     * @example
     *
     * _.intersection([1, 2, 3], [101, 2, 1, 10], [2, 1]);
     * // => [1, 2]
     */
    function intersection(array) {
      var args = arguments,
          argsLength = args.length,
          cache = { '0': {} },
          index = -1,
          length = array ? array.length : 0,
          isLarge = length >= largeArraySize,
          result = [],
          seen = result;

      outer:
      while (++index < length) {
        var value = array[index];
        if (isLarge) {
          var key = keyPrefix + value;
          var inited = cache[0][key]
            ? !(seen = cache[0][key])
            : (seen = cache[0][key] = []);
        }
        if (inited || indexOf(seen, value) < 0) {
          if (isLarge) {
            seen.push(value);
          }
          var argsIndex = argsLength;
          while (--argsIndex) {
            if (!(cache[argsIndex] || (cache[argsIndex] = cachedContains(args[argsIndex])))(value)) {
              continue outer;
            }
          }
          result.push(value);
        }
      }
      return result;
    }

    /**
     * Gets the last element of the `array`. If a number `n` is passed, the
     * last `n` elements of the `array` are returned. If a `callback` function
     * is passed, elements at the end of the array are returned as long as the
     * `callback` returns truthy. The `callback` is bound to `thisArg` and
     * invoked with three arguments;(value, index, array).
     *
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to query.
     * @param {Function|Object|Number|String} [callback|n] The function called
     *  per element or the number of elements to return. If a property name or
     *  object is passed, it will be used to create a "_.pluck" or "_.where"
     *  style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Mixed} Returns the last element(s) of `array`.
     * @example
     *
     * _.last([1, 2, 3]);
     * // => 3
     *
     * _.last([1, 2, 3], 2);
     * // => [2, 3]
     *
     * _.last([1, 2, 3], function(num) {
     *   return num > 1;
     * });
     * // => [2, 3]
     *
     * var food = [
     *   { 'name': 'beet',   'organic': false },
     *   { 'name': 'carrot', 'organic': true }
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.last(food, 'organic');
     * // => [{ 'name': 'carrot', 'organic': true }]
     *
     * var food = [
     *   { 'name': 'banana', 'type': 'fruit' },
     *   { 'name': 'beet',   'type': 'vegetable' },
     *   { 'name': 'carrot', 'type': 'vegetable' }
     * ];
     *
     * // using "_.where" callback shorthand
     * _.last(food, { 'type': 'vegetable' });
     * // => [{ 'name': 'beet', 'type': 'vegetable' }, { 'name': 'carrot', 'type': 'vegetable' }]
     */
    function last(array, callback, thisArg) {
      if (array) {
        var n = 0,
            length = array.length;

        if (typeof callback != 'number' && callback != null) {
          var index = length;
          callback = lodash.createCallback(callback, thisArg);
          while (index-- && callback(array[index], index, array)) {
            n++;
          }
        } else {
          n = callback;
          if (n == null || thisArg) {
            return array[length - 1];
          }
        }
        return slice(array, nativeMax(0, length - n));
      }
    }

    /**
     * Gets the index at which the last occurrence of `value` is found using strict
     * equality for comparisons, i.e. `===`. If `fromIndex` is negative, it is used
     * as the offset from the end of the collection.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to search.
     * @param {Mixed} value The value to search for.
     * @param {Number} [fromIndex=array.length-1] The index to search from.
     * @returns {Number} Returns the index of the matched value or `-1`.
     * @example
     *
     * _.lastIndexOf([1, 2, 3, 1, 2, 3], 2);
     * // => 4
     *
     * _.lastIndexOf([1, 2, 3, 1, 2, 3], 2, 3);
     * // => 1
     */
    function lastIndexOf(array, value, fromIndex) {
      var index = array ? array.length : 0;
      if (typeof fromIndex == 'number') {
        index = (fromIndex < 0 ? nativeMax(0, index + fromIndex) : nativeMin(fromIndex, index - 1)) + 1;
      }
      while (index--) {
        if (array[index] === value) {
          return index;
        }
      }
      return -1;
    }

    /**
     * Creates an array of numbers (positive and/or negative) progressing from
     * `start` up to but not including `end`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Number} [start=0] The start of the range.
     * @param {Number} end The end of the range.
     * @param {Number} [step=1] The value to increment or decrement by.
     * @returns {Array} Returns a new range array.
     * @example
     *
     * _.range(10);
     * // => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
     *
     * _.range(1, 11);
     * // => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
     *
     * _.range(0, 30, 5);
     * // => [0, 5, 10, 15, 20, 25]
     *
     * _.range(0, -10, -1);
     * // => [0, -1, -2, -3, -4, -5, -6, -7, -8, -9]
     *
     * _.range(0);
     * // => []
     */
    function range(start, end, step) {
      start = +start || 0;
      step = +step || 1;

      if (end == null) {
        end = start;
        start = 0;
      }
      // use `Array(length)` so V8 will avoid the slower "dictionary" mode
      // http://youtu.be/XAqIpGU8ZZk#t=17m25s
      var index = -1,
          length = nativeMax(0, ceil((end - start) / step)),
          result = Array(length);

      while (++index < length) {
        result[index] = start;
        start += step;
      }
      return result;
    }

    /**
     * The opposite of `_.initial`, this method gets all but the first value of
     * `array`. If a number `n` is passed, the first `n` values are excluded from
     * the result. If a `callback` function is passed, elements at the beginning
     * of the array are excluded from the result as long as the `callback` returns
     * truthy. The `callback` is bound to `thisArg` and invoked with three
     * arguments; (value, index, array).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @alias drop, tail
     * @category Arrays
     * @param {Array} array The array to query.
     * @param {Function|Object|Number|String} [callback|n=1] The function called
     *  per element or the number of elements to exclude. If a property name or
     *  object is passed, it will be used to create a "_.pluck" or "_.where"
     *  style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a slice of `array`.
     * @example
     *
     * _.rest([1, 2, 3]);
     * // => [2, 3]
     *
     * _.rest([1, 2, 3], 2);
     * // => [3]
     *
     * _.rest([1, 2, 3], function(num) {
     *   return num < 3;
     * });
     * // => [3]
     *
     * var food = [
     *   { 'name': 'banana', 'organic': true },
     *   { 'name': 'beet',   'organic': false },
     * ];
     *
     * // using "_.pluck" callback shorthand
     * _.rest(food, 'organic');
     * // => [{ 'name': 'beet', 'organic': false }]
     *
     * var food = [
     *   { 'name': 'apple',  'type': 'fruit' },
     *   { 'name': 'banana', 'type': 'fruit' },
     *   { 'name': 'beet',   'type': 'vegetable' }
     * ];
     *
     * // using "_.where" callback shorthand
     * _.rest(food, { 'type': 'fruit' });
     * // => [{ 'name': 'beet', 'type': 'vegetable' }]
     */
    function rest(array, callback, thisArg) {
      if (typeof callback != 'number' && callback != null) {
        var n = 0,
            index = -1,
            length = array ? array.length : 0;

        callback = lodash.createCallback(callback, thisArg);
        while (++index < length && callback(array[index], index, array)) {
          n++;
        }
      } else {
        n = (callback == null || thisArg) ? 1 : nativeMax(0, callback);
      }
      return slice(array, n);
    }

    /**
     * Uses a binary search to determine the smallest index at which the `value`
     * should be inserted into `array` in order to maintain the sort order of the
     * sorted `array`. If `callback` is passed, it will be executed for `value` and
     * each element in `array` to compute their sort ranking. The `callback` is
     * bound to `thisArg` and invoked with one argument; (value).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to inspect.
     * @param {Mixed} value The value to evaluate.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Number} Returns the index at which the value should be inserted
     *  into `array`.
     * @example
     *
     * _.sortedIndex([20, 30, 50], 40);
     * // => 2
     *
     * // using "_.pluck" callback shorthand
     * _.sortedIndex([{ 'x': 20 }, { 'x': 30 }, { 'x': 50 }], { 'x': 40 }, 'x');
     * // => 2
     *
     * var dict = {
     *   'wordToNumber': { 'twenty': 20, 'thirty': 30, 'fourty': 40, 'fifty': 50 }
     * };
     *
     * _.sortedIndex(['twenty', 'thirty', 'fifty'], 'fourty', function(word) {
     *   return dict.wordToNumber[word];
     * });
     * // => 2
     *
     * _.sortedIndex(['twenty', 'thirty', 'fifty'], 'fourty', function(word) {
     *   return this.wordToNumber[word];
     * }, dict);
     * // => 2
     */
    function sortedIndex(array, value, callback, thisArg) {
      var low = 0,
          high = array ? array.length : low;

      // explicitly reference `identity` for better inlining in Firefox
      callback = callback ? lodash.createCallback(callback, thisArg, 1) : identity;
      value = callback(value);

      while (low < high) {
        var mid = (low + high) >>> 1;
        (callback(array[mid]) < value)
          ? low = mid + 1
          : high = mid;
      }
      return low;
    }

    /**
     * Computes the union of the passed-in arrays using strict equality for
     * comparisons, i.e. `===`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} [array1, array2, ...] Arrays to process.
     * @returns {Array} Returns a new array of unique values, in order, that are
     *  present in one or more of the arrays.
     * @example
     *
     * _.union([1, 2, 3], [101, 2, 1, 10], [2, 1]);
     * // => [1, 2, 3, 101, 10]
     */
    function union(array) {
      if (!isArray(array)) {
        arguments[0] = array ? nativeSlice.call(array) : arrayRef;
      }
      return uniq(concat.apply(arrayRef, arguments));
    }

    /**
     * Creates a duplicate-value-free version of the `array` using strict equality
     * for comparisons, i.e. `===`. If the `array` is already sorted, passing `true`
     * for `isSorted` will run a faster algorithm. If `callback` is passed, each
     * element of `array` is passed through a `callback` before uniqueness is computed.
     * The `callback` is bound to `thisArg` and invoked with three arguments; (value, index, array).
     *
     * If a property name is passed for `callback`, the created "_.pluck" style
     * callback will return the property value of the given element.
     *
     * If an object is passed for `callback`, the created "_.where" style callback
     * will return `true` for elements that have the properties of the given object,
     * else `false`.
     *
     * @static
     * @memberOf _
     * @alias unique
     * @category Arrays
     * @param {Array} array The array to process.
     * @param {Boolean} [isSorted=false] A flag to indicate that the `array` is already sorted.
     * @param {Function|Object|String} [callback=identity] The function called per
     *  iteration. If a property name or object is passed, it will be used to create
     *  a "_.pluck" or "_.where" style callback, respectively.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a duplicate-value-free array.
     * @example
     *
     * _.uniq([1, 2, 1, 3, 1]);
     * // => [1, 2, 3]
     *
     * _.uniq([1, 1, 2, 2, 3], true);
     * // => [1, 2, 3]
     *
     * _.uniq([1, 2, 1.5, 3, 2.5], function(num) { return Math.floor(num); });
     * // => [1, 2, 3]
     *
     * _.uniq([1, 2, 1.5, 3, 2.5], function(num) { return this.floor(num); }, Math);
     * // => [1, 2, 3]
     *
     * // using "_.pluck" callback shorthand
     * _.uniq([{ 'x': 1 }, { 'x': 2 }, { 'x': 1 }], 'x');
     * // => [{ 'x': 1 }, { 'x': 2 }]
     */
    function uniq(array, isSorted, callback, thisArg) {
      var index = -1,
          length = array ? array.length : 0,
          result = [],
          seen = result;

      // juggle arguments
      if (typeof isSorted != 'boolean' && isSorted != null) {
        thisArg = callback;
        callback = isSorted;
        isSorted = false;
      }
      // init value cache for large arrays
      var isLarge = !isSorted && length >= largeArraySize;
      if (isLarge) {
        var cache = {};
      }
      if (callback != null) {
        seen = [];
        callback = lodash.createCallback(callback, thisArg);
      }
      while (++index < length) {
        var value = array[index],
            computed = callback ? callback(value, index, array) : value;

        if (isLarge) {
          var key = keyPrefix + computed;
          var inited = cache[key]
            ? !(seen = cache[key])
            : (seen = cache[key] = []);
        }
        if (isSorted
              ? !index || seen[seen.length - 1] !== computed
              : inited || indexOf(seen, computed) < 0
            ) {
          if (callback || isLarge) {
            seen.push(computed);
          }
          result.push(value);
        }
      }
      return result;
    }

    /**
     * The inverse of `_.zip`, this method splits groups of elements into arrays
     * composed of elements from each group at their corresponding indexes.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to process.
     * @returns {Array} Returns a new array of the composed arrays.
     * @example
     *
     * _.unzip([['moe', 30, true], ['larry', 40, false]]);
     * // => [['moe', 'larry'], [30, 40], [true, false]];
     */
    function unzip(array) {
      var index = -1,
          length = array ? array.length : 0,
          tupleLength = length ? max(pluck(array, 'length')) : 0,
          result = Array(tupleLength);

      while (++index < length) {
        var tupleIndex = -1,
            tuple = array[index];

        while (++tupleIndex < tupleLength) {
          (result[tupleIndex] || (result[tupleIndex] = Array(length)))[index] = tuple[tupleIndex];
        }
      }
      return result;
    }

    /**
     * Creates an array with all occurrences of the passed values removed using
     * strict equality for comparisons, i.e. `===`.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} array The array to filter.
     * @param {Mixed} [value1, value2, ...] Values to remove.
     * @returns {Array} Returns a new filtered array.
     * @example
     *
     * _.without([1, 2, 1, 0, 3, 1, 4], 0, 1);
     * // => [2, 3, 4]
     */
    function without(array) {
      return difference(array, nativeSlice.call(arguments, 1));
    }

    /**
     * Groups the elements of each array at their corresponding indexes. Useful for
     * separate data sources that are coordinated through matching array indexes.
     * For a matrix of nested arrays, `_.zip.apply(...)` can transpose the matrix
     * in a similar fashion.
     *
     * @static
     * @memberOf _
     * @category Arrays
     * @param {Array} [array1, array2, ...] Arrays to process.
     * @returns {Array} Returns a new array of grouped elements.
     * @example
     *
     * _.zip(['moe', 'larry'], [30, 40], [true, false]);
     * // => [['moe', 30, true], ['larry', 40, false]]
     */
    function zip(array) {
      var index = -1,
          length = array ? max(pluck(arguments, 'length')) : 0,
          result = Array(length);

      while (++index < length) {
        result[index] = pluck(arguments, index);
      }
      return result;
    }

    /**
     * Creates an object composed from arrays of `keys` and `values`. Pass either
     * a single two dimensional array, i.e. `[[key1, value1], [key2, value2]]`, or
     * two arrays, one of `keys` and one of corresponding `values`.
     *
     * @static
     * @memberOf _
     * @alias object
     * @category Arrays
     * @param {Array} keys The array of keys.
     * @param {Array} [values=[]] The array of values.
     * @returns {Object} Returns an object composed of the given keys and
     *  corresponding values.
     * @example
     *
     * _.zipObject(['moe', 'larry'], [30, 40]);
     * // => { 'moe': 30, 'larry': 40 }
     */
    function zipObject(keys, values) {
      var index = -1,
          length = keys ? keys.length : 0,
          result = {};

      while (++index < length) {
        var key = keys[index];
        if (values) {
          result[key] = values[index];
        } else {
          result[key[0]] = key[1];
        }
      }
      return result;
    }

    /*--------------------------------------------------------------------------*/

    /**
     * If `n` is greater than `0`, a function is created that is restricted to
     * executing `func`, with the `this` binding and arguments of the created
     * function, only after it is called `n` times. If `n` is less than `1`,
     * `func` is executed immediately, without a `this` binding or additional
     * arguments, and its result is returned.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Number} n The number of times the function must be called before
     * it is executed.
     * @param {Function} func The function to restrict.
     * @returns {Function} Returns the new restricted function.
     * @example
     *
     * var renderNotes = _.after(notes.length, render);
     * _.forEach(notes, function(note) {
     *   note.asyncSave({ 'success': renderNotes });
     * });
     * // `renderNotes` is run once, after all notes have saved
     */
    function after(n, func) {
      if (n < 1) {
        return func();
      }
      return function() {
        if (--n < 1) {
          return func.apply(this, arguments);
        }
      };
    }

    /**
     * Creates a function that, when called, invokes `func` with the `this`
     * binding of `thisArg` and prepends any additional `bind` arguments to those
     * passed to the bound function.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to bind.
     * @param {Mixed} [thisArg] The `this` binding of `func`.
     * @param {Mixed} [arg1, arg2, ...] Arguments to be partially applied.
     * @returns {Function} Returns the new bound function.
     * @example
     *
     * var func = function(greeting) {
     *   return greeting + ' ' + this.name;
     * };
     *
     * func = _.bind(func, { 'name': 'moe' }, 'hi');
     * func();
     * // => 'hi moe'
     */
    function bind(func, thisArg) {
      // use `Function#bind` if it exists and is fast
      // (in V8 `Function#bind` is slower except when partially applied)
      return support.fastBind || (nativeBind && arguments.length > 2)
        ? nativeBind.call.apply(nativeBind, arguments)
        : createBound(func, thisArg, nativeSlice.call(arguments, 2));
    }

    /**
     * Binds methods on `object` to `object`, overwriting the existing method.
     * Method names may be specified as individual arguments or as arrays of method
     * names. If no method names are provided, all the function properties of `object`
     * will be bound.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Object} object The object to bind and assign the bound methods to.
     * @param {String} [methodName1, methodName2, ...] Method names on the object to bind.
     * @returns {Object} Returns `object`.
     * @example
     *
     * var view = {
     *  'label': 'docs',
     *  'onClick': function() { alert('clicked ' + this.label); }
     * };
     *
     * _.bindAll(view);
     * jQuery('#docs').on('click', view.onClick);
     * // => alerts 'clicked docs', when the button is clicked
     */
    function bindAll(object) {
      var funcs = arguments.length > 1 ? concat.apply(arrayRef, nativeSlice.call(arguments, 1)) : functions(object),
          index = -1,
          length = funcs.length;

      while (++index < length) {
        var key = funcs[index];
        object[key] = bind(object[key], object);
      }
      return object;
    }

    /**
     * Creates a function that, when called, invokes the method at `object[key]`
     * and prepends any additional `bindKey` arguments to those passed to the bound
     * function. This method differs from `_.bind` by allowing bound functions to
     * reference methods that will be redefined or don't yet exist.
     * See http://michaux.ca/articles/lazy-function-definition-pattern.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Object} object The object the method belongs to.
     * @param {String} key The key of the method.
     * @param {Mixed} [arg1, arg2, ...] Arguments to be partially applied.
     * @returns {Function} Returns the new bound function.
     * @example
     *
     * var object = {
     *   'name': 'moe',
     *   'greet': function(greeting) {
     *     return greeting + ' ' + this.name;
     *   }
     * };
     *
     * var func = _.bindKey(object, 'greet', 'hi');
     * func();
     * // => 'hi moe'
     *
     * object.greet = function(greeting) {
     *   return greeting + ', ' + this.name + '!';
     * };
     *
     * func();
     * // => 'hi, moe!'
     */
    function bindKey(object, key) {
      return createBound(object, key, nativeSlice.call(arguments, 2), indicatorObject);
    }

    /**
     * Creates a function that is the composition of the passed functions,
     * where each function consumes the return value of the function that follows.
     * For example, composing the functions `f()`, `g()`, and `h()` produces `f(g(h()))`.
     * Each function is executed with the `this` binding of the composed function.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} [func1, func2, ...] Functions to compose.
     * @returns {Function} Returns the new composed function.
     * @example
     *
     * var greet = function(name) { return 'hi ' + name; };
     * var exclaim = function(statement) { return statement + '!'; };
     * var welcome = _.compose(exclaim, greet);
     * welcome('moe');
     * // => 'hi moe!'
     */
    function compose() {
      var funcs = arguments;
      return function() {
        var args = arguments,
            length = funcs.length;

        while (length--) {
          args = [funcs[length].apply(this, args)];
        }
        return args[0];
      };
    }

    /**
     * Produces a callback bound to an optional `thisArg`. If `func` is a property
     * name, the created callback will return the property value for a given element.
     * If `func` is an object, the created callback will return `true` for elements
     * that contain the equivalent object properties, otherwise it will return `false`.
     *
     * Note: All Lo-Dash methods, that accept a `callback` argument, use `_.createCallback`.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Mixed} [func=identity] The value to convert to a callback.
     * @param {Mixed} [thisArg] The `this` binding of the created callback.
     * @param {Number} [argCount=3] The number of arguments the callback accepts.
     * @returns {Function} Returns a callback function.
     * @example
     *
     * var stooges = [
     *   { 'name': 'moe', 'age': 40 },
     *   { 'name': 'larry', 'age': 50 }
     * ];
     *
     * // wrap to create custom callback shorthands
     * _.createCallback = _.wrap(_.createCallback, function(func, callback, thisArg) {
     *   var match = /^(.+?)__([gl]t)(.+)$/.exec(callback);
     *   return !match ? func(callback, thisArg) : function(object) {
     *     return match[2] == 'gt' ? object[match[1]] > match[3] : object[match[1]] < match[3];
     *   };
     * });
     *
     * _.filter(stooges, 'age__gt45');
     * // => [{ 'name': 'larry', 'age': 50 }]
     *
     * // create mixins with support for "_.pluck" and "_.where" callback shorthands
     * _.mixin({
     *   'toLookup': function(collection, callback, thisArg) {
     *     callback = _.createCallback(callback, thisArg);
     *     return _.reduce(collection, function(result, value, index, collection) {
     *       return (result[callback(value, index, collection)] = value, result);
     *     }, {});
     *   }
     * });
     *
     * _.toLookup(stooges, 'name');
     * // => { 'moe': { 'name': 'moe', 'age': 40 }, 'larry': { 'name': 'larry', 'age': 50 } }
     */
    function createCallback(func, thisArg, argCount) {
      if (func == null) {
        return identity;
      }
      var type = typeof func;
      if (type != 'function') {
        if (type != 'object') {
          return function(object) {
            return object[func];
          };
        }
        var props = keys(func);
        return function(object) {
          var length = props.length,
              result = false;
          while (length--) {
            if (!(result = isEqual(object[props[length]], func[props[length]], indicatorObject))) {
              break;
            }
          }
          return result;
        };
      }
      if (typeof thisArg != 'undefined') {
        if (argCount === 1) {
          return function(value) {
            return func.call(thisArg, value);
          };
        }
        if (argCount === 2) {
          return function(a, b) {
            return func.call(thisArg, a, b);
          };
        }
        if (argCount === 4) {
          return function(accumulator, value, index, collection) {
            return func.call(thisArg, accumulator, value, index, collection);
          };
        }
        return function(value, index, collection) {
          return func.call(thisArg, value, index, collection);
        };
      }
      return func;
    }

    /**
     * Creates a function that will delay the execution of `func` until after
     * `wait` milliseconds have elapsed since the last time it was invoked. Pass
     * an `options` object to indicate that `func` should be invoked on the leading
     * and/or trailing edge of the `wait` timeout. Subsequent calls to the debounced
     * function will return the result of the last `func` call.
     *
     * Note: If `leading` and `trailing` options are `true`, `func` will be called
     * on the trailing edge of the timeout only if the the debounced function is
     * invoked more than once during the `wait` timeout.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to debounce.
     * @param {Number} wait The number of milliseconds to delay.
     * @param {Object} options The options object.
     *  [leading=false] A boolean to specify execution on the leading edge of the timeout.
     *  [trailing=true] A boolean to specify execution on the trailing edge of the timeout.
     * @returns {Function} Returns the new debounced function.
     * @example
     *
     * var lazyLayout = _.debounce(calculateLayout, 300);
     * jQuery(window).on('resize', lazyLayout);
     *
     * jQuery('#postbox').on('click', _.debounce(sendMail, 200, {
     *   'leading': true,
     *   'trailing': false
     * });
     */
    function debounce(func, wait, options) {
      var args,
          inited,
          result,
          thisArg,
          timeoutId,
          trailing = true;

      function delayed() {
        inited = timeoutId = null;
        if (trailing) {
          result = func.apply(thisArg, args);
        }
      }
      if (options === true) {
        var leading = true;
        trailing = false;
      } else if (options && objectTypes[typeof options]) {
        leading = options.leading;
        trailing = 'trailing' in options ? options.trailing : trailing;
      }
      return function() {
        args = arguments;
        thisArg = this;
        clearTimeout(timeoutId);

        if (!inited && leading) {
          inited = true;
          result = func.apply(thisArg, args);
        } else {
          timeoutId = setTimeout(delayed, wait);
        }
        return result;
      };
    }

    /**
     * Defers executing the `func` function until the current call stack has cleared.
     * Additional arguments will be passed to `func` when it is invoked.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to defer.
     * @param {Mixed} [arg1, arg2, ...] Arguments to invoke the function with.
     * @returns {Number} Returns the timer id.
     * @example
     *
     * _.defer(function() { alert('deferred'); });
     * // returns from the function before `alert` is called
     */
    function defer(func) {
      var args = nativeSlice.call(arguments, 1);
      return setTimeout(function() { func.apply(undefined, args); }, 1);
    }
    // use `setImmediate` if it's available in Node.js
    if (isV8 && freeModule && typeof setImmediate == 'function') {
      defer = bind(setImmediate, context);
    }

    /**
     * Executes the `func` function after `wait` milliseconds. Additional arguments
     * will be passed to `func` when it is invoked.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to delay.
     * @param {Number} wait The number of milliseconds to delay execution.
     * @param {Mixed} [arg1, arg2, ...] Arguments to invoke the function with.
     * @returns {Number} Returns the timer id.
     * @example
     *
     * var log = _.bind(console.log, console);
     * _.delay(log, 1000, 'logged later');
     * // => 'logged later' (Appears after one second.)
     */
    function delay(func, wait) {
      var args = nativeSlice.call(arguments, 2);
      return setTimeout(function() { func.apply(undefined, args); }, wait);
    }

    /**
     * Creates a function that memoizes the result of `func`. If `resolver` is
     * passed, it will be used to determine the cache key for storing the result
     * based on the arguments passed to the memoized function. By default, the first
     * argument passed to the memoized function is used as the cache key. The `func`
     * is executed with the `this` binding of the memoized function.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to have its output memoized.
     * @param {Function} [resolver] A function used to resolve the cache key.
     * @returns {Function} Returns the new memoizing function.
     * @example
     *
     * var fibonacci = _.memoize(function(n) {
     *   return n < 2 ? n : fibonacci(n - 1) + fibonacci(n - 2);
     * });
     */
    function memoize(func, resolver) {
      var cache = {};
      return function() {
        var key = keyPrefix + (resolver ? resolver.apply(this, arguments) : arguments[0]);
        return hasOwnProperty.call(cache, key)
          ? cache[key]
          : (cache[key] = func.apply(this, arguments));
      };
    }

    /**
     * Creates a function that is restricted to execute `func` once. Repeat calls to
     * the function will return the value of the first call. The `func` is executed
     * with the `this` binding of the created function.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to restrict.
     * @returns {Function} Returns the new restricted function.
     * @example
     *
     * var initialize = _.once(createApplication);
     * initialize();
     * initialize();
     * // `initialize` executes `createApplication` once
     */
    function once(func) {
      var ran,
          result;

      return function() {
        if (ran) {
          return result;
        }
        ran = true;
        result = func.apply(this, arguments);

        // clear the `func` variable so the function may be garbage collected
        func = null;
        return result;
      };
    }

    /**
     * Creates a function that, when called, invokes `func` with any additional
     * `partial` arguments prepended to those passed to the new function. This
     * method is similar to `_.bind`, except it does **not** alter the `this` binding.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to partially apply arguments to.
     * @param {Mixed} [arg1, arg2, ...] Arguments to be partially applied.
     * @returns {Function} Returns the new partially applied function.
     * @example
     *
     * var greet = function(greeting, name) { return greeting + ' ' + name; };
     * var hi = _.partial(greet, 'hi');
     * hi('moe');
     * // => 'hi moe'
     */
    function partial(func) {
      return createBound(func, nativeSlice.call(arguments, 1));
    }

    /**
     * This method is similar to `_.partial`, except that `partial` arguments are
     * appended to those passed to the new function.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to partially apply arguments to.
     * @param {Mixed} [arg1, arg2, ...] Arguments to be partially applied.
     * @returns {Function} Returns the new partially applied function.
     * @example
     *
     * var defaultsDeep = _.partialRight(_.merge, _.defaults);
     *
     * var options = {
     *   'variable': 'data',
     *   'imports': { 'jq': $ }
     * };
     *
     * defaultsDeep(options, _.templateSettings);
     *
     * options.variable
     * // => 'data'
     *
     * options.imports
     * // => { '_': _, 'jq': $ }
     */
    function partialRight(func) {
      return createBound(func, nativeSlice.call(arguments, 1), null, indicatorObject);
    }

    /**
     * Creates a function that, when executed, will only call the `func` function
     * at most once per every `wait` milliseconds. Pass an `options` object to
     * indicate that `func` should be invoked on the leading and/or trailing edge
     * of the `wait` timeout. Subsequent calls to the throttled function will
     * return the result of the last `func` call.
     *
     * Note: If `leading` and `trailing` options are `true`, `func` will be called
     * on the trailing edge of the timeout only if the the throttled function is
     * invoked more than once during the `wait` timeout.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Function} func The function to throttle.
     * @param {Number} wait The number of milliseconds to throttle executions to.
     * @param {Object} options The options object.
     *  [leading=true] A boolean to specify execution on the leading edge of the timeout.
     *  [trailing=true] A boolean to specify execution on the trailing edge of the timeout.
     * @returns {Function} Returns the new throttled function.
     * @example
     *
     * var throttled = _.throttle(updatePosition, 100);
     * jQuery(window).on('scroll', throttled);
     *
     * jQuery('.interactive').on('click', _.throttle(renewToken, 300000, {
     *   'trailing': false
     * }));
     */
    function throttle(func, wait, options) {
      var args,
          result,
          thisArg,
          timeoutId,
          lastCalled = 0,
          leading = true,
          trailing = true;

      function trailingCall() {
        timeoutId = null;
        if (trailing) {
          lastCalled = new Date;
          result = func.apply(thisArg, args);
        }
      }
      if (options === false) {
        leading = false;
      } else if (options && objectTypes[typeof options]) {
        leading = 'leading' in options ? options.leading : leading;
        trailing = 'trailing' in options ? options.trailing : trailing;
      }
      return function() {
        var now = new Date;
        if (!timeoutId && !leading) {
          lastCalled = now;
        }
        var remaining = wait - (now - lastCalled);
        args = arguments;
        thisArg = this;

        if (remaining <= 0) {
          clearTimeout(timeoutId);
          timeoutId = null;
          lastCalled = now;
          result = func.apply(thisArg, args);
        }
        else if (!timeoutId) {
          timeoutId = setTimeout(trailingCall, remaining);
        }
        return result;
      };
    }

    /**
     * Creates a function that passes `value` to the `wrapper` function as its
     * first argument. Additional arguments passed to the function are appended
     * to those passed to the `wrapper` function. The `wrapper` is executed with
     * the `this` binding of the created function.
     *
     * @static
     * @memberOf _
     * @category Functions
     * @param {Mixed} value The value to wrap.
     * @param {Function} wrapper The wrapper function.
     * @returns {Function} Returns the new function.
     * @example
     *
     * var hello = function(name) { return 'hello ' + name; };
     * hello = _.wrap(hello, function(func) {
     *   return 'before, ' + func('moe') + ', after';
     * });
     * hello();
     * // => 'before, hello moe, after'
     */
    function wrap(value, wrapper) {
      return function() {
        var args = [value];
        push.apply(args, arguments);
        return wrapper.apply(this, args);
      };
    }

    /*--------------------------------------------------------------------------*/

    /**
     * Converts the characters `&`, `<`, `>`, `"`, and `'` in `string` to their
     * corresponding HTML entities.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {String} string The string to escape.
     * @returns {String} Returns the escaped string.
     * @example
     *
     * _.escape('Moe, Larry & Curly');
     * // => 'Moe, Larry &amp; Curly'
     */
    function escape(string) {
      return string == null ? '' : String(string).replace(reUnescapedHtml, escapeHtmlChar);
    }

    /**
     * This function returns the first argument passed to it.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {Mixed} value Any value.
     * @returns {Mixed} Returns `value`.
     * @example
     *
     * var moe = { 'name': 'moe' };
     * moe === _.identity(moe);
     * // => true
     */
    function identity(value) {
      return value;
    }

    /**
     * Adds functions properties of `object` to the `lodash` function and chainable
     * wrapper.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {Object} object The object of function properties to add to `lodash`.
     * @example
     *
     * _.mixin({
     *   'capitalize': function(string) {
     *     return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
     *   }
     * });
     *
     * _.capitalize('moe');
     * // => 'Moe'
     *
     * _('moe').capitalize();
     * // => 'Moe'
     */
    function mixin(object) {
      forEach(functions(object), function(methodName) {
        var func = lodash[methodName] = object[methodName];

        lodash.prototype[methodName] = function() {
          var value = this.__wrapped__,
              args = [value];

          push.apply(args, arguments);
          var result = func.apply(lodash, args);
          return (value && typeof value == 'object' && value == result)
            ? this
            : new lodashWrapper(result);
        };
      });
    }

    /**
     * Reverts the '_' variable to its previous value and returns a reference to
     * the `lodash` function.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @returns {Function} Returns the `lodash` function.
     * @example
     *
     * var lodash = _.noConflict();
     */
    function noConflict() {
      context._ = oldDash;
      return this;
    }

    /**
     * Converts the given `value` into an integer of the specified `radix`.
     * If `radix` is `undefined` or `0`, a `radix` of `10` is used unless the
     * `value` is a hexadecimal, in which case a `radix` of `16` is used.
     *
     * Note: This method avoids differences in native ES3 and ES5 `parseInt`
     * implementations. See http://es5.github.com/#E.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {String} value The value to parse.
     * @param {Number} [radix] The radix used to interpret the value to parse.
     * @returns {Number} Returns the new integer value.
     * @example
     *
     * _.parseInt('08');
     * // => 8
     */
    var parseInt = nativeParseInt(whitespace + '08') == 8 ? nativeParseInt : function(value, radix) {
      // Firefox and Opera still follow the ES3 specified implementation of `parseInt`
      return nativeParseInt(isString(value) ? value.replace(reLeadingSpacesAndZeros, '') : value, radix || 0);
    };

    /**
     * Produces a random number between `min` and `max` (inclusive). If only one
     * argument is passed, a number between `0` and the given number will be returned.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {Number} [min=0] The minimum possible value.
     * @param {Number} [max=1] The maximum possible value.
     * @returns {Number} Returns a random number.
     * @example
     *
     * _.random(0, 5);
     * // => a number between 0 and 5
     *
     * _.random(5);
     * // => also a number between 0 and 5
     */
    function random(min, max) {
      if (min == null && max == null) {
        max = 1;
      }
      min = +min || 0;
      if (max == null) {
        max = min;
        min = 0;
      }
      return min + floor(nativeRandom() * ((+max || 0) - min + 1));
    }

    /**
     * Resolves the value of `property` on `object`. If `property` is a function,
     * it will be invoked with the `this` binding of `object` and its result returned,
     * else the property value is returned. If `object` is falsey, then `undefined`
     * is returned.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {Object} object The object to inspect.
     * @param {String} property The property to get the value of.
     * @returns {Mixed} Returns the resolved value.
     * @example
     *
     * var object = {
     *   'cheese': 'crumpets',
     *   'stuff': function() {
     *     return 'nonsense';
     *   }
     * };
     *
     * _.result(object, 'cheese');
     * // => 'crumpets'
     *
     * _.result(object, 'stuff');
     * // => 'nonsense'
     */
    function result(object, property) {
      var value = object ? object[property] : undefined;
      return isFunction(value) ? object[property]() : value;
    }

    /**
     * A micro-templating method that handles arbitrary delimiters, preserves
     * whitespace, and correctly escapes quotes within interpolated code.
     *
     * Note: In the development build, `_.template` utilizes sourceURLs for easier
     * debugging. See http://www.html5rocks.com/en/tutorials/developertools/sourcemaps/#toc-sourceurl
     *
     * For more information on precompiling templates see:
     * http://lodash.com/#custom-builds
     *
     * For more information on Chrome extension sandboxes see:
     * http://developer.chrome.com/stable/extensions/sandboxingEval.html
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {String} text The template text.
     * @param {Object} data The data object used to populate the text.
     * @param {Object} options The options object.
     *  escape - The "escape" delimiter regexp.
     *  evaluate - The "evaluate" delimiter regexp.
     *  interpolate - The "interpolate" delimiter regexp.
     *  sourceURL - The sourceURL of the template's compiled source.
     *  variable - The data object variable name.
     * @returns {Function|String} Returns a compiled function when no `data` object
     *  is given, else it returns the interpolated text.
     * @example
     *
     * // using a compiled template
     * var compiled = _.template('hello <%= name %>');
     * compiled({ 'name': 'moe' });
     * // => 'hello moe'
     *
     * var list = '<% _.forEach(people, function(name) { %><li><%= name %></li><% }); %>';
     * _.template(list, { 'people': ['moe', 'larry'] });
     * // => '<li>moe</li><li>larry</li>'
     *
     * // using the "escape" delimiter to escape HTML in data property values
     * _.template('<b><%- value %></b>', { 'value': '<script>' });
     * // => '<b>&lt;script&gt;</b>'
     *
     * // using the ES6 delimiter as an alternative to the default "interpolate" delimiter
     * _.template('hello ${ name }', { 'name': 'curly' });
     * // => 'hello curly'
     *
     * // using the internal `print` function in "evaluate" delimiters
     * _.template('<% print("hello " + epithet); %>!', { 'epithet': 'stooge' });
     * // => 'hello stooge!'
     *
     * // using custom template delimiters
     * _.templateSettings = {
     *   'interpolate': /{{([\s\S]+?)}}/g
     * };
     *
     * _.template('hello {{ name }}!', { 'name': 'mustache' });
     * // => 'hello mustache!'
     *
     * // using the `sourceURL` option to specify a custom sourceURL for the template
     * var compiled = _.template('hello <%= name %>', null, { 'sourceURL': '/basic/greeting.jst' });
     * compiled(data);
     * // => find the source of "greeting.jst" under the Sources tab or Resources panel of the web inspector
     *
     * // using the `variable` option to ensure a with-statement isn't used in the compiled template
     * var compiled = _.template('hi <%= data.name %>!', null, { 'variable': 'data' });
     * compiled.source;
     * // => function(data) {
     *   var __t, __p = '', __e = _.escape;
     *   __p += 'hi ' + ((__t = ( data.name )) == null ? '' : __t) + '!';
     *   return __p;
     * }
     *
     * // using the `source` property to inline compiled templates for meaningful
     * // line numbers in error messages and a stack trace
     * fs.writeFileSync(path.join(cwd, 'jst.js'), '\
     *   var JST = {\
     *     "main": ' + _.template(mainText).source + '\
     *   };\
     * ');
     */
    function template(text, data, options) {
      // based on John Resig's `tmpl` implementation
      // http://ejohn.org/blog/javascript-micro-templating/
      // and Laura Doktorova's doT.js
      // https://github.com/olado/doT
      var settings = lodash.templateSettings;
      text || (text = '');

      // avoid missing dependencies when `iteratorTemplate` is not defined
      options = defaults({}, options, settings);

      var imports = defaults({}, options.imports, settings.imports),
          importsKeys = keys(imports),
          importsValues = values(imports);

      var isEvaluating,
          index = 0,
          interpolate = options.interpolate || reNoMatch,
          source = "__p += '";

      // compile the regexp to match each delimiter
      var reDelimiters = RegExp(
        (options.escape || reNoMatch).source + '|' +
        interpolate.source + '|' +
        (interpolate === reInterpolate ? reEsTemplate : reNoMatch).source + '|' +
        (options.evaluate || reNoMatch).source + '|$'
      , 'g');

      text.replace(reDelimiters, function(match, escapeValue, interpolateValue, esTemplateValue, evaluateValue, offset) {
        interpolateValue || (interpolateValue = esTemplateValue);

        // escape characters that cannot be included in string literals
        source += text.slice(index, offset).replace(reUnescapedString, escapeStringChar);

        // replace delimiters with snippets
        if (escapeValue) {
          source += "' +\n__e(" + escapeValue + ") +\n'";
        }
        if (evaluateValue) {
          isEvaluating = true;
          source += "';\n" + evaluateValue + ";\n__p += '";
        }
        if (interpolateValue) {
          source += "' +\n((__t = (" + interpolateValue + ")) == null ? '' : __t) +\n'";
        }
        index = offset + match.length;

        // the JS engine embedded in Adobe products requires returning the `match`
        // string in order to produce the correct `offset` value
        return match;
      });

      source += "';\n";

      // if `variable` is not specified, wrap a with-statement around the generated
      // code to add the data object to the top of the scope chain
      var variable = options.variable,
          hasVariable = variable;

      if (!hasVariable) {
        variable = 'obj';
        source = 'with (' + variable + ') {\n' + source + '\n}\n';
      }
      // cleanup code by stripping empty strings
      source = (isEvaluating ? source.replace(reEmptyStringLeading, '') : source)
        .replace(reEmptyStringMiddle, '$1')
        .replace(reEmptyStringTrailing, '$1;');

      // frame code as the function body
      source = 'function(' + variable + ') {\n' +
        (hasVariable ? '' : variable + ' || (' + variable + ' = {});\n') +
        "var __t, __p = '', __e = _.escape" +
        (isEvaluating
          ? ', __j = Array.prototype.join;\n' +
            "function print() { __p += __j.call(arguments, '') }\n"
          : ';\n'
        ) +
        source +
        'return __p\n}';

      // Use a sourceURL for easier debugging and wrap in a multi-line comment to
      // avoid issues with Narwhal, IE conditional compilation, and the JS engine
      // embedded in Adobe products.
      // http://www.html5rocks.com/en/tutorials/developertools/sourcemaps/#toc-sourceurl
      var sourceURL = '\n/*\n//@ sourceURL=' + (options.sourceURL || '/lodash/template/source[' + (templateCounter++) + ']') + '\n*/';

      try {
        var result = Function(importsKeys, 'return ' + source + sourceURL).apply(undefined, importsValues);
      } catch(e) {
        e.source = source;
        throw e;
      }
      if (data) {
        return result(data);
      }
      // provide the compiled function's source via its `toString` method, in
      // supported environments, or the `source` property as a convenience for
      // inlining compiled templates during the build process
      result.source = source;
      return result;
    }

    /**
     * Executes the `callback` function `n` times, returning an array of the results
     * of each `callback` execution. The `callback` is bound to `thisArg` and invoked
     * with one argument; (index).
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {Number} n The number of times to execute the callback.
     * @param {Function} callback The function called per iteration.
     * @param {Mixed} [thisArg] The `this` binding of `callback`.
     * @returns {Array} Returns a new array of the results of each `callback` execution.
     * @example
     *
     * var diceRolls = _.times(3, _.partial(_.random, 1, 6));
     * // => [3, 6, 4]
     *
     * _.times(3, function(n) { mage.castSpell(n); });
     * // => calls `mage.castSpell(n)` three times, passing `n` of `0`, `1`, and `2` respectively
     *
     * _.times(3, function(n) { this.cast(n); }, mage);
     * // => also calls `mage.castSpell(n)` three times
     */
    function times(n, callback, thisArg) {
      n = (n = +n) > -1 ? n : 0;
      var index = -1,
          result = Array(n);

      callback = lodash.createCallback(callback, thisArg, 1);
      while (++index < n) {
        result[index] = callback(index);
      }
      return result;
    }

    /**
     * The inverse of `_.escape`, this method converts the HTML entities
     * `&amp;`, `&lt;`, `&gt;`, `&quot;`, and `&#39;` in `string` to their
     * corresponding characters.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {String} string The string to unescape.
     * @returns {String} Returns the unescaped string.
     * @example
     *
     * _.unescape('Moe, Larry &amp; Curly');
     * // => 'Moe, Larry & Curly'
     */
    function unescape(string) {
      return string == null ? '' : String(string).replace(reEscapedHtml, unescapeHtmlChar);
    }

    /**
     * Generates a unique ID. If `prefix` is passed, the ID will be appended to it.
     *
     * @static
     * @memberOf _
     * @category Utilities
     * @param {String} [prefix] The value to prefix the ID with.
     * @returns {String} Returns the unique ID.
     * @example
     *
     * _.uniqueId('contact_');
     * // => 'contact_104'
     *
     * _.uniqueId();
     * // => '105'
     */
    function uniqueId(prefix) {
      var id = ++idCounter;
      return String(prefix == null ? '' : prefix) + id;
    }

    /*--------------------------------------------------------------------------*/

    /**
     * Invokes `interceptor` with the `value` as the first argument, and then
     * returns `value`. The purpose of this method is to "tap into" a method chain,
     * in order to perform operations on intermediate results within the chain.
     *
     * @static
     * @memberOf _
     * @category Chaining
     * @param {Mixed} value The value to pass to `interceptor`.
     * @param {Function} interceptor The function to invoke.
     * @returns {Mixed} Returns `value`.
     * @example
     *
     * _([1, 2, 3, 4])
     *  .filter(function(num) { return num % 2 == 0; })
     *  .tap(alert)
     *  .map(function(num) { return num * num; })
     *  .value();
     * // => // [2, 4] (alerted)
     * // => [4, 16]
     */
    function tap(value, interceptor) {
      interceptor(value);
      return value;
    }

    /**
     * Produces the `toString` result of the wrapped value.
     *
     * @name toString
     * @memberOf _
     * @category Chaining
     * @returns {String} Returns the string result.
     * @example
     *
     * _([1, 2, 3]).toString();
     * // => '1,2,3'
     */
    function wrapperToString() {
      return String(this.__wrapped__);
    }

    /**
     * Extracts the wrapped value.
     *
     * @name valueOf
     * @memberOf _
     * @alias value
     * @category Chaining
     * @returns {Mixed} Returns the wrapped value.
     * @example
     *
     * _([1, 2, 3]).valueOf();
     * // => [1, 2, 3]
     */
    function wrapperValueOf() {
      return this.__wrapped__;
    }

    /*--------------------------------------------------------------------------*/

    // add functions that return wrapped values when chaining
    lodash.after = after;
    lodash.assign = assign;
    lodash.at = at;
    lodash.bind = bind;
    lodash.bindAll = bindAll;
    lodash.bindKey = bindKey;
    lodash.compact = compact;
    lodash.compose = compose;
    lodash.countBy = countBy;
    lodash.createCallback = createCallback;
    lodash.debounce = debounce;
    lodash.defaults = defaults;
    lodash.defer = defer;
    lodash.delay = delay;
    lodash.difference = difference;
    lodash.filter = filter;
    lodash.flatten = flatten;
    lodash.forEach = forEach;
    lodash.forIn = forIn;
    lodash.forOwn = forOwn;
    lodash.functions = functions;
    lodash.groupBy = groupBy;
    lodash.initial = initial;
    lodash.intersection = intersection;
    lodash.invert = invert;
    lodash.invoke = invoke;
    lodash.keys = keys;
    lodash.map = map;
    lodash.max = max;
    lodash.memoize = memoize;
    lodash.merge = merge;
    lodash.min = min;
    lodash.omit = omit;
    lodash.once = once;
    lodash.pairs = pairs;
    lodash.partial = partial;
    lodash.partialRight = partialRight;
    lodash.pick = pick;
    lodash.pluck = pluck;
    lodash.range = range;
    lodash.reject = reject;
    lodash.rest = rest;
    lodash.shuffle = shuffle;
    lodash.sortBy = sortBy;
    lodash.tap = tap;
    lodash.throttle = throttle;
    lodash.times = times;
    lodash.toArray = toArray;
    lodash.union = union;
    lodash.uniq = uniq;
    lodash.unzip = unzip;
    lodash.values = values;
    lodash.where = where;
    lodash.without = without;
    lodash.wrap = wrap;
    lodash.zip = zip;
    lodash.zipObject = zipObject;

    // add aliases
    lodash.collect = map;
    lodash.drop = rest;
    lodash.each = forEach;
    lodash.extend = assign;
    lodash.methods = functions;
    lodash.object = zipObject;
    lodash.select = filter;
    lodash.tail = rest;
    lodash.unique = uniq;

    // add functions to `lodash.prototype`
    mixin(lodash);

    /*--------------------------------------------------------------------------*/

    // add functions that return unwrapped values when chaining
    lodash.clone = clone;
    lodash.cloneDeep = cloneDeep;
    lodash.contains = contains;
    lodash.escape = escape;
    lodash.every = every;
    lodash.find = find;
    lodash.findIndex = findIndex;
    lodash.findKey = findKey;
    lodash.has = has;
    lodash.identity = identity;
    lodash.indexOf = indexOf;
    lodash.isArguments = isArguments;
    lodash.isArray = isArray;
    lodash.isBoolean = isBoolean;
    lodash.isDate = isDate;
    lodash.isElement = isElement;
    lodash.isEmpty = isEmpty;
    lodash.isEqual = isEqual;
    lodash.isFinite = isFinite;
    lodash.isFunction = isFunction;
    lodash.isNaN = isNaN;
    lodash.isNull = isNull;
    lodash.isNumber = isNumber;
    lodash.isObject = isObject;
    lodash.isPlainObject = isPlainObject;
    lodash.isRegExp = isRegExp;
    lodash.isString = isString;
    lodash.isUndefined = isUndefined;
    lodash.lastIndexOf = lastIndexOf;
    lodash.mixin = mixin;
    lodash.noConflict = noConflict;
    lodash.parseInt = parseInt;
    lodash.random = random;
    lodash.reduce = reduce;
    lodash.reduceRight = reduceRight;
    lodash.result = result;
    lodash.runInContext = runInContext;
    lodash.size = size;
    lodash.some = some;
    lodash.sortedIndex = sortedIndex;
    lodash.template = template;
    lodash.unescape = unescape;
    lodash.uniqueId = uniqueId;

    // add aliases
    lodash.all = every;
    lodash.any = some;
    lodash.detect = find;
    lodash.foldl = reduce;
    lodash.foldr = reduceRight;
    lodash.include = contains;
    lodash.inject = reduce;

    forOwn(lodash, function(func, methodName) {
      if (!lodash.prototype[methodName]) {
        lodash.prototype[methodName] = function() {
          var args = [this.__wrapped__];
          push.apply(args, arguments);
          return func.apply(lodash, args);
        };
      }
    });

    /*--------------------------------------------------------------------------*/

    // add functions capable of returning wrapped and unwrapped values when chaining
    lodash.first = first;
    lodash.last = last;

    // add aliases
    lodash.take = first;
    lodash.head = first;

    forOwn(lodash, function(func, methodName) {
      if (!lodash.prototype[methodName]) {
        lodash.prototype[methodName]= function(callback, thisArg) {
          var result = func(this.__wrapped__, callback, thisArg);
          return callback == null || (thisArg && typeof callback != 'function')
            ? result
            : new lodashWrapper(result);
        };
      }
    });

    /*--------------------------------------------------------------------------*/

    /**
     * The semantic version number.
     *
     * @static
     * @memberOf _
     * @type String
     */
    lodash.VERSION = '1.2.1';

    // add "Chaining" functions to the wrapper
    lodash.prototype.toString = wrapperToString;
    lodash.prototype.value = wrapperValueOf;
    lodash.prototype.valueOf = wrapperValueOf;

    // add `Array` functions that return unwrapped values
    forEach(['join', 'pop', 'shift'], function(methodName) {
      var func = arrayRef[methodName];
      lodash.prototype[methodName] = function() {
        return func.apply(this.__wrapped__, arguments);
      };
    });

    // add `Array` functions that return the wrapped value
    forEach(['push', 'reverse', 'sort', 'unshift'], function(methodName) {
      var func = arrayRef[methodName];
      lodash.prototype[methodName] = function() {
        func.apply(this.__wrapped__, arguments);
        return this;
      };
    });

    // add `Array` functions that return new wrapped values
    forEach(['concat', 'slice', 'splice'], function(methodName) {
      var func = arrayRef[methodName];
      lodash.prototype[methodName] = function() {
        return new lodashWrapper(func.apply(this.__wrapped__, arguments));
      };
    });

    return lodash;
  }

  /*--------------------------------------------------------------------------*/

  // expose Lo-Dash
  var _ = runInContext();

  define('lodash',[],function() {
    return _;
  });

  // some AMD build optimizers, like r.js, check for specific condition patterns like the following:
  // if (typeof define == 'function' && typeof define.amd == 'object' && define.amd) {
  //   // Expose Lo-Dash to the global object even when an AMD loader is present in
  //   // case Lo-Dash was injected by a third-party script and not intended to be
  //   // loaded as a module. The global assignment can be reverted in the Lo-Dash
  //   // module via its `noConflict()` method.
  //   window._ = _;

  //   // define as an anonymous module so, through path mapping, it can be
  //   // referenced as the "underscore" module
  //   define(function() {
  //     return _;
  //   });
  // }
  // // check for `exports` after `define` in case a build optimizer adds an `exports` object
  // else if (freeExports && !freeExports.nodeType) {
  //   // in Node.js or RingoJS v0.8.0+
  //   if (freeModule) {
  //     (freeModule.exports = _)._ = _;
  //   }
  //   // in Narwhal or RingoJS v0.7.0-
  //   else {
  //     freeExports._ = _;
  //   }
  // }
  // else {
  //   // in a browser or Rhino
  //   window._ = _;
  // }
}(this));

define('cssParser',[],function() {
	var session = {tokens: null};
	
	// walks around the source
	var walker = {
		init: function (source) {
			// this.source = source.replace(/\r\n?/g, '\n');
			this.source = source;
			this.ch = '';
			this.chnum = -1;
		
			// advance
			this.nextChar();
		},
		nextChar: function () {
			return this.ch = this.source.charAt(++this.chnum);
		},
		peek: function() {
			return this.source.charAt(this.chnum + 1);
		}
	};

	// utility helpers
	function isNameChar(c, cc) {
		cc = cc || c.charCodeAt(0);
		return (
			(cc >= 97 && cc <= 122 /* a-z */) || 
			(cc >= 65 && cc <= 90 /* A-Z */) || 
			/* 
			Experimental: include cyrillic ranges 
			since some letters, similar to latin ones, can 
			accidentally appear in CSS tokens
			*/
			(cc >= 1024 && cc <= 1279) || 
			c === '&' /* for LESS syntax */ || 
			c === '_' || 
			c === '-'
		);
	}

	function isDigit(c, cc) {
		cc = cc || c.charCodeAt(0);
		return (cc >= 48 && cc <= 57);
	}

	var isOp = (function () {
		var opsa = "{}[]()+*=.,;:>~|\\%$#@^!".split(''),
			opsmatcha = "*^|$~".split(''),
			ops = {},
			opsmatch = {},
			i = 0;
		for (; i < opsa.length; i += 1) {
			ops[opsa[i]] = true;
		}
		for (i = 0; i < opsmatcha.length; i += 1) {
			opsmatch[opsmatcha[i]] = true;
		}
		return function (ch, matchattr) {
			if (matchattr) {
				return ch in opsmatch;
			}
			return ch in ops;
		};
	}());
	
	// creates token objects and pushes them to a list
	function tokener(value, type) {
		session.tokens.push({
			value: value,
			type:  type || value,
			start: null,
			end:   null
		});
	}
	
	// oops
	function error(m) { 
		var w = walker;
		var tokens = session.tokens;
		session.tokens = null;
		return {
			name: "ParseError",
			message: m + " at char " + (w.chnum + 1),
			walker: w,
			tokens: tokens
		};
	}


	// token handlers follow for:
	// white space, comment, string, identifier, number, operator
	function white() {
		var c = walker.ch,
			token = '';
	
		while (c === " " || c === "\t") {
			token += c;
			c = walker.nextChar();
		}
	
		tokener(token, 'white');
	
	}

	function comment() {
	
		var w = walker,
			c = w.ch,
			token = c,
			cnext;
	 
		cnext = w.nextChar();

		if (cnext === '/') {
			// inline comment in SCSS and such
			token += cnext;
			var pk = w.peek();
			while (pk && pk !== '\n') {
				token += cnext;
				cnext = w.nextChar();
				pk = w.peek();
			}
		} else if (cnext === '*') {
			// multiline CSS commment
			while (!(c === "*" && cnext === "/")) {
				token += cnext;
				c = cnext;
				cnext = w.nextChar();        
			}            
		} else {
			// oops, not a comment, just a /
			return tokener(token, token);
		}
		
		token += cnext;
		w.nextChar();
		tokener(token, 'comment');
	}

	function str() {
		var w = walker,
			c = w.ch,
			q = c,
			token = c,
			cnext;
	
		c = w.nextChar();
	
		while (c !== q) {
			
			if (c === '\n') {
				cnext = w.nextChar();
				if (cnext === "\\") {
					token += c + cnext;
				} else {
					// end of line with no \ escape = bad
					throw error("Unterminated string");
				}
			} else {
				if (c === "\\") {
					token += c + w.nextChar();
				} else {
					token += c;
				}
			}
		
			c = w.nextChar();
		
		}
		token += c;
		w.nextChar();
		tokener(token, 'string');
	}
	
	function brace() {
		var w = walker,
			c = w.ch,
			depth = 0,
			token = c;
	
		c = w.nextChar();
	
		while (c !== ')' && !depth) {
			if (c === '(') {
				depth++;
			} else if (c === ')') {
				depth--;
			} else if (c === '') {
				throw error("Unterminated brace");
			}
			
			token += c;
			c = w.nextChar();
		}
		
		token += c;
		w.nextChar();
		tokener(token, 'brace');
	}

	function identifier(pre) {
		var c = walker.ch;
		var token = pre ? pre + c : c;
			
		c = walker.nextChar();
		var cc = c.charCodeAt(0);
		while (isNameChar(c, cc) || isDigit(c, cc)) {
			token += c;
			c = walker.nextChar();
			cc = c.charCodeAt(0);
		}
	
		tokener(token, 'identifier');    
	}

	function num() {
		var w = walker,
			c = w.ch,
			token = c,
			point = token === '.',
			nondigit;
		
		c = w.nextChar();
		nondigit = !isDigit(c);
	
		// .2px or .classname?
		if (point && nondigit) {
			// meh, NaN, could be a class name, so it's an operator for now
			return tokener(token, '.');    
		}
		
		// -2px or -moz-something
		if (token === '-' && nondigit) {
			return identifier('-');
		}
	
		while (c !== '' && (isDigit(c) || (!point && c === '.'))) { // not end of source && digit or first instance of .
			if (c === '.') {
				point = true;
			}
			token += c;
			c = w.nextChar();
		}

		tokener(token, 'number');    
	
	}

	function op() {
		var w = walker,
			c = w.ch,
			token = c,
			next = w.nextChar();
			
		if (next === "=" && isOp(token, true)) {
			token += next;
			tokener(token, 'match');
			w.nextChar();
			return;
		} 
		
		tokener(token, token);
	}


	// call the appropriate handler based on the first character in a token suspect
	function tokenize() {
		var ch = walker.ch;
	
		if (ch === " " || ch === "\t") {
			return white();
		}

		if (ch === '/') {
			return comment();
		} 

		if (ch === '"' || ch === "'") {
			return str();
		}
		
		if (ch === '(') {
			return brace();
		}
	
		if (ch === '-' || ch === '.' || isDigit(ch)) { // tricky - char: minus (-1px) or dash (-moz-stuff)
			return num();
		}
	
		if (isNameChar(ch)) {
			return identifier();
		}

		if (isOp(ch)) {
			return op();
		}

		if (ch === '\r') {
			if (walker.peek() === '\n') {
				ch += walker.nextChar();
			}

			tokener(ch, 'line');
			walker.nextChar();
			return;
		}
		
		if (ch === '\n') {
			tokener(ch, 'line');
			walker.nextChar();
			return;
		}
		
		throw error("Unrecognized character '" + ch + "'");
	}

	return {
		/**
		 * Sprits given source into tokens
		 * @param {String} source
		 * @returns {Array}
		 */
		lex: function (source) {
			walker.init(source);
			session.tokens = [];

			// for empty source, return single space token
			if (!source) {
				session.tokens.push(this.white());
			} else {
				while (walker.ch !== '') {
					tokenize();
				}
			}

			var tokens = session.tokens;
			session.tokens = null;
			return tokens;
		},
		
		/**
		 * Tokenizes CSS source. It's like `lex()` method,
		 * but also stores proper token indexes in source, 
		 * so it's a bit slower
		 * @param {String} source
		 * @returns {Array}
		 */
		parse: function(source) {
			// transform tokens
			var tokens = this.lex(source), pos = 0, token;
			for (var i = 0, il = tokens.length; i < il; i++) {
				token = tokens[i];
				token.start = pos;
				token.end = (pos += token.value.length);
			}
			return tokens;
		},

		white: function() {
			return {
				value: '',
				type:  'white',
				start: 0,
				end:   0
			};
		},
		
		toSource: function(toks) {
			var i = 0, max = toks.length, src = '';
			for (; i < max; i++) {
				src += toks[i].value;
			}
			return src;
		}
	};
});
/**
 * Helper module to work with ranges
 * @constructor
 * @memberOf __rangeDefine
 * @param {Function} require
 * @param {Underscore} _
 */
define('range',['lodash'], function(_) {
	function cmp(a, b, op) {
		switch (op) {
			case 'eq':
			case '==':
				return a === b;
			case 'lt':
			case '<':
				return a < b;
			case 'lte':
			case '<=':
				return a <= b;
			case 'gt':
			case '>':
				return a > b;
			case 'gte':
			case '>=':
				return a >= b;
		}
	}
	
	
	/**
	 * @type Range
	 * @constructor
	 * @param {Object} start
	 * @param {Number} len
	 */
	function Range(start, len) {
		if (typeof start == 'object' && 'start' in start) {
			// create range from object stub
			this.start = Math.min(start.start, start.end);
			this.end = Math.max(start.start, start.end);
		} else if (_.isArray(start)) {
			this.start = start[0];
			this.end = start[1];
		} else {
			len = (typeof start == 'string') ? len.length : +len;
			this.start = start;
			this.end = start + len;
		}
	}
	
	Range.prototype = {
		length: function() {
			return this.end - this.start;
		},
		
		/**
		 * Returns <code>true</code> if passed range is equals to current one
		 * @param {Range} range
		 * @returns {Boolean}
		 */
		equal: function(range) {
			return this.cmp(range, 'eq', 'eq');
		},
		
		/**
		 * Shifts indexes position with passed <code>delat</code>
		 * @param {Number} delta
		 * @returns {Range} range itself
		 */
		shift: function(delta) {
			this.start += delta;
			this.end += delta;
			return this;
		},
		
		/**
		 * Check if two ranges are overlapped
		 * @param {Range} range
		 * @returns {Boolean}
		 */
		overlap: function(range) {
			return range.start <= this.end && range.end >= this.start;
		},
		
		/**
		 * Finds intersection of two ranges
		 * @param {Range} range
		 * @returns {Range} <code>null</code> if ranges does not overlap
		 */
		intersection: function(range) {
			if (this.overlap(range)) {
				var start = Math.max(range.start, this.start);
				var end = Math.min(range.end, this.end);
				return new Range(start, end - start);
			}
			
			return null;
		},
		
		/**
		 * Returns the union of the thow ranges.
		 * @param {Range} range
		 * @returns {Range} <code>null</code> if ranges are not overlapped
		 */
		union: function(range) {
			if (this.overlap(range)) {
				var start = Math.min(range.start, this.start);
				var end = Math.max(range.end, this.end);
				return new Range(start, end - start);
			}
			
			return null;
		},
		
		/**
		 * Returns a Boolean value that indicates whether a specified position 
		 * is in a given range.
		 * @param {Number} loc
		 */
		inside: function(loc) {
			return this.cmp(loc, 'lte', 'gt');
		},
		
		/**
		 * Returns a Boolean value that indicates whether a specified position 
		 * is in a given range, but not equals bounds.
		 * @param {Number} loc
		 */
		contains: function(loc) {
			return this.cmp(loc, 'lt', 'gt');
		},
		
		/**
		 * Check if current range completely includes specified one
		 * @param {Range} r
		 * @returns {Boolean} 
		 */
		include: function(r) {
			return this.cmp(r, 'lte', 'gte');
		},
		
		/**
		 * Low-level comparision method
		 * @param {Number} loc
		 * @param {String} left Left comparison operator
		 * @param {String} right Right comaprison operator
		 */
		cmp: function(loc, left, right) {
			var a, b;
			if (loc instanceof Range) {
				a = loc.start;
				b = loc.end;
			} else {
				a = b = loc;
			}
			
			return cmp(this.start, a, left || '<=') && cmp(this.end, b, right || '>');
		},
		
		/**
		 * Returns substring of specified <code>str</code> for current range
		 * @param {String} str
		 * @returns {String}
		 */
		substring: function(str) {
			return this.length() > 0 
				? str.substring(this.start, this.end) 
				: '';
		},
		
		/**
		 * Creates copy of current range
		 * @returns {Range}
		 */
		clone: function() {
			return new Range(this.start, this.length());
		},
		
		/**
		 * @returns {Array}
		 */
		toArray: function() {
			return [this.start, this.end];
		},
		
		toString: function() {
			return this.valueOf();
		},

		valueOf: function() {
			return '{' + this.start + ', ' + this.length() + '}';
		}
	};
	
	return {
		/**
		 * Creates new range object instance
		 * @param {Object} start Range start or array with 'start' and 'end'
		 * as two first indexes or object with 'start' and 'end' properties
		 * @param {Number} len Range length or string to produce range from
		 * @returns {Range}
		 * @memberOf emmet.range
		 */
		create: function(start, len) {
			if (typeof start == 'undefined' || start === null)
				return null;
			
			if (start instanceof Range)
				return start;
			
			if (typeof start == 'object' && 'start' in start && 'end' in start) {
				len = start.end - start.start;
				start = start.start;
			}
				
			return new Range(start, len);
		},
		
		/**
		 * <code>Range</code> object factory, the same as <code>this.create()</code>
		 * but last argument represents end of range, not length
		 * @returns {Range}
		 */
		create2: function(start, end) {
			if (_.isNumber(start) && _.isNumber(end)) {
				end -= start;
			}
			
			return this.create(start, end);
		}
	};
});
define('tree',['lodash', 'cssParser', 'range'], function(_, cssParser, range) {
	var reS = /\s+/g;
	var reSpaces = /[ \t]+/g;
	var fTokens = {'white': true, 'line': true, 'comment': true};
	var sTokens = {'white': true, 'line': true};
	var lookupS1 = {';': true, '{': true};
	var lookupS2 = {';': true, '}': true};
	var tokenStub = {start: 0, end: 0};

	function CSSNode(nameRange, valueRange, hints) {
		hints = hints || {};
		
		this.nameRange = nameRange;
		this.valueRange = valueRange;
		this.children = [];
		this.parent = null;
		this.type = hints.type || 'section';

		this._name = null;
		this._nameLower = null;
		this._value = null;
		this._hints = hints;
	}

	/**
	 * @param {CSSNode} node
	 * @returns {CSSNode}
	 */
	CSSNode.prototype = {
		addChild: function(node) {
			node.parent = this;
			this.children.push(node);
			return node;
		},

		/**
		 * Returns raw node name (e.g. without additional preprocessing)
		 * @returns {String}
		 */
		rawName: function() {
			return this.nameRange ? this.nameRange.substring(this.source()) : '';
		},

		/**
		 * Returns preprocessed and normalized node name which
		 * can be used for comparison
		 * @param {Boolean} isLower Return name in lower-case
		 */
		name: function(isLower) {
			// check if we have cached name
			if (this._name === null) {
				this._name = parseSelectors(this._nameTokens() || this.rawName()).join(', ').trim();
				if (this.type === 'property') {
					// check edge case: consumed incomplete CSS property,
					// for example: m10\nposition 
					// (e.g. user start writing new property or Emmet abbreviation)
					this._name = _.last(this._name.split(/\s+/));
				}
			}

			if (isLower) {
				if (this._nameLower === null) {
					this._nameLower = this._name.toLowerCase();
				}

				return this._nameLower;
			}

			return this._name;
		},

		/**
		 * Returns raw node value
		 * @returns {String}
		 */
		rawValue: function() {
			return this.valueRange ? this.valueRange.substring(this.source()) : '';
		},

		/**
		 * Returns normalized node name
		 * @returns {String}
		 */
		value: function() {
			if (!this._value) {
				this._value = this.rawValue().trim();
			}
			return this._value;
		},

		valueOf: function(padding) {
			padding = padding || '';
			var output = '';
			this.children.forEach(function(item) {
				output += padding + '(n)' + item.name();
				if (item.children.length) {
					output += '\n' + item.valueOf(padding + '\t');
				} else {
					output += ': (v)' + item.value() + '\n';
				}
			});

			return output;
		},

		/**
		 * Returns root node
		 * @return {CSSNode}
		 */
		root: function() {
			if (!this.parent) {
				return this;
			}

			var ctx = this.parent;
			while (ctx.parent) {
				ctx = ctx.parent;
			}

			return ctx;
		},

		/**
		 * Returns list of CSS properties in this section, if available
		 * @return {Array} 
		 */
		properties: function() {
			var props = [], ix = -1;

			_.each(this.children, function(item) {
				if (item.type == 'property') {
					props.push({
						name: item.name().trim(),
						value: item.value().trim(),
						index: ++ix
					});
				}
			});

			return props;
		},

		_nameTokens: function() {
			var n = this._hints.name;
			if (n) {
				return this.root().tokens.slice(n[0], n[1]);
			}
		},

		/**
		 * Returns range of currect node
		 * @return {Range}
		 */
		range: function() {
			if (!this.parent) {
				return range.create2(0, this.source);
			}

			var start = this.nameRange.start;
			var end = this.valueRange ? this.valueRange.end : this.nameRange.end;
			return range.create2(start, end);
		},

		/**
		 * Returns full range (including punctuation) of current node
		 * @return {Range}
		 */
		fullRange: function() {
			var h = this._hints;
			var tokens = this.root().tokens;
			if (tokens && 'startToken' in h && 'endToken' in h) {
				var startToken = tokens[h.startToken];
				var endToken = tokens[h.endToken];
				return range.create2(startToken.start, endToken.end);
			}
		},

		toSource: function() {
			return this.range().substring(this.source()).trim();
		},

		toFullSource: function() {
			return this.fullRange().substring(this.source());
		},

		/**
		 * Returns original CSS source
		 * @return {String}
		 */
		source: function() {
			var root = this.root();
			if (root._dirty) {
				root._source = cssParser.toSource(root.tokens);
				root._dirty = false;
			}
			return root._source;
		},

		/**
		 * Expoprts current node as restorable JSON object, used for caching
		 * and comparing. E.g. this is not the complete tree and it can't be
		 * used for source manipulation, just for diff'ing
		 * @return {Object}
		 */
		toJSONCache: function() {
			if (!this.parent) {
				return this.children.map(function(c) {
					return c.toJSONCache();
				});
			}

			var out = {
				name: this.name(),
				value: this.value(),
				type: this.type
			};

			if (this.type == 'property') {
				out.value = this.value();
			} else {
				out.children = this.children.map(function(c) {
					return c.toJSONCache();
				});
			}

			return out;
		},

		/**
		 * Returns plain list of all child nodes of current node
		 * @return {Array}
		 */
		all: function() {
			var out = [];
			var add = function(item) {
				for (var i = 0, il = item.children.length; i < il; i++) {
					out.push(item.children[i]);
					add(item.children[i]);
				}
			};

			add(this);
			return out;
		},

		// these are tree modification methods that affects bound
		// source and tokens
		
		/**
		 * Returns list of all following siblings and direct parents of current list.
		 * Used to get list of nodes to be updated when current node is modified
		 * @return {Array}
		 */
		_allSiblings: function() {
			var out = [], ctx = this, children;

			var add = function(item) {
				out.push(item);
				for (var i = 0, il = item.children.length; i < il; i++) {
					add(item.children[i]);
				}
			};

			while (ctx.parent) {
				children = ctx.parent.children;
				for (var i = _.indexOf(children, ctx) + 1, il = children.length; i < il; i++) {
					add(children[i]);
				}

				ctx = ctx.parent;
				if (ctx) {
					out.push(ctx);
				}
			}

			// console.log('All: %d (%d)', out.length, _.uniq(out).length);
			return out;
		},

		/**
		 * Returns index of current node in parent's child list
		 * @return {[type]} [description]
		 */
		index: function() {
			return this.parent ? this.parent.children.indexOf(this) : 0;
		},

		/**
		 * Removes current node from tree
		 */
		remove: function() {
			if (!this.parent) {
				return;
			}
			
			var tokenStart = this._hints.startToken;
			var tokenEnd = this._hints.endToken;
			var tokenOffset = tokenEnd - tokenStart + 1;

			var tokens = this.root().tokens;
			var charStart = tokens[tokenStart].start;
			var endChar = tokens[tokenEnd].end;
			var charOffset = endChar - charStart;

			var siblings = this._allSiblings();
			var pos = this.index();
			this.parent.children.splice(pos, 1);

			shiftPositions(siblings, {
				tokenStart: tokenStart,
				tokenOffset: -tokenOffset,
				charStart: charStart,
				charOffset: -charOffset
			});

			// update actual tokens
			var removed = tokens.splice(tokenStart, tokenOffset);
			for (var i = tokenStart, il = tokens.length, t; i < il; i++) {
				t = tokens[i];
				t.start -= charOffset;
				t.end -= charOffset;
			}

			this.root()._dirty = true;
		},

		/**
		 * Inserts given subtree into specified child position
		 * of current node.
		 * The given node must be attached to another tree with
		 * proper tokens and ranges
		 * @param {CSSNode} node
		 * @param {Number} pos Position index where node should be inserted.
		 * If not specified, node will be inserted at the end
		 */
		insert: function(subtree, pos) {
			if (_.isUndefined(pos)) {
				pos = this.children.length;
			}

			// identify original token where subtree tokens
			// should be inserted
			var tokens = this.root().tokens, siblings;
			var targetToken = null;
			if (!this.parent && pos === 0)  {
				targetToken = this.children.length ? 0 : tokens.length;
			} else if (this.children[pos]) {
				siblings = this.children[pos]._allSiblings();
				siblings.unshift(this.children[pos]);
				targetToken = this.children[pos]._hints.startToken;
			} else {
				// TODO find better location for subsection insertion
				if (!this.parent) {
					// for root section, subtree must be inserted at the end
					// of tokens list
					targetToken = this._hints.endToken + 1;
				} else {
					targetToken = this._hints.endToken;
					while (targetToken >= 0 && tokens[targetToken].type !== '}') {
						targetToken--;
					}

					if (targetToken <= this._hints.startToken) {
						throw "Invalid CSS section";
					}
				}

				siblings = this._allSiblings();
			}

			if (targetToken === null || _.isUndefined(targetToken)) {
				throw 'Unable to insert subtree: target token is unavailable';
			}

			// modify subtree tokens to match original tree tokens positions
			var subtreeSourceLen = 0, startPos;
			if (targetToken >= tokens.length) {
				startPos = (_.last(tokens) || tokenStub).end;
			} else {
				startPos = tokens[targetToken].start
			}

			var subtreeTokens = _.map(subtree.tokens, function(t) {
				t = _.clone(t);
				t.start += startPos;
				t.end += startPos;
				subtreeSourceLen += t.value.length;
				return t;
			});

			// update original tokens positions
			for (var i = targetToken, il = tokens.length; i < il; i++) {
				tokens[i].start += subtreeSourceLen;
				tokens[i].end += subtreeSourceLen;
			}

			// update subtree ranges
			shiftPositions(subtree.all(), {
				tokenStart: 0,
				tokenOffset: targetToken,
				charStart: 0,
				charOffset: targetToken && tokens[targetToken - 1] ? tokens[targetToken - 1].end : 0
			});

			// update sibling's ranges
			shiftPositions(siblings, {
				tokenStart: targetToken,
				tokenOffset: subtreeTokens.length,
				charStart: startPos,
				charOffset: subtreeSourceLen
			});
			
			// inject new tokens
			subtreeTokens.unshift(targetToken, 0);
			tokens.splice.apply(tokens, subtreeTokens);

			// inject subtree
			this.children.splice.apply(this.children, [pos, 0].concat(subtree.children));
			var parent = this;
			subtree.children.forEach(function(item) {
				item.parent = parent;
			});

			var root = this.root();
			root._hints.endToken = tokens.length - 1;
			root._dirty = true;
		},

		/**
		 * Replaces current node with given subtree
		 * @param  {CSSNode} subtree
		 */
		replace: function(subtree) {
			var ix = this.index();
			var parent = this.parent;
			this.remove();
			return parent.insert(subtree, ix);
		}
	};

	function TokenIterator(tokens, source) {
		this.tokens = tokens;
		this.len = tokens.length;
		this.source = source;
		this.start = this.pos = 0;
		this.root = new CSSNode(null, null, {
			type: 'root',
			startToken: 0,
			endToken: this.len - 1
		});
		this.root._source = source;
		this.root.tokens = tokens;
		this.ctx = this.root;
	}

	TokenIterator.prototype = {
		hasNext: function () {
			return this.pos < this.len;
		},
		next: function() {
			return this.tokens[this.pos++];
		},
		peek: function() {
			return this.tokens[this.pos];
		},
		curRange: function(tillStart) {
			var startTok = this.tokens[this.start];
			return range.create2(startTok.start, this.peek()[tillStart ? 'start' : 'end']);
		},
		backUp: function(n) {
			this.pos -= n;
		},
		skipTo: function(lookup) {
			while (++this.pos < this.len && !(this.tokens[this.pos].type in lookup)) {}
		}
	};

	function dumpTokens(tokens) {
		return tokens.map(function(item) {
			return '[' + item.value.replace(/\n/g, '<LF>').replace(/\t/g, '<TAB>') + ']';
		}).join(' ');
	}

	/**
	 * Updates positions of given nodes list. Used to
	 * update node's tokens and ranges if its tree is modified
	 * @param  {Array} items   List of nodes to update
	 * @param  {Object} options
	 */
	function shiftPositions(items, options) {
		var shiftToken = function(obj, prop) {
			if (obj[prop] >= options.tokenStart) {
				obj[prop] += options.tokenOffset;
				if (obj[prop] < 0) {
					obj[prop] = 0;
				}
			}
		}
		_.each(items, function(item) {
			// update tokens
			var h = item._hints;
			shiftToken(h, 'startToken');
			shiftToken(h, 'endToken');

			if (h.name) {
				shiftToken(h.name, 0);
				shiftToken(h.name, 1);
			}

			// update ranges
			var r = item.nameRange;
			if (item.nameRange) {
				if (r.start >= options.charStart) {
					r.start += options.charOffset;
				}
				if (r.end >= options.charStart) {
					r.end += options.charOffset;
				}
			}

			if (item.valueRange) {
				r = item.valueRange;
				if (r.start >= options.charStart) {
					r.start += options.charOffset;
				}
				if (r.end >= options.charStart) {
					r.end += options.charOffset;
				}
			}
		});
	}

	/**
	 * Normalizes selector
	 * @param  {String} sel
	 * @return {String}
	 */
	function normalizeSelector(sel) {
		return sel.trim().replace(reSpaces, ' ');
	}

	/**
	 * Parses CSS selector and returns normalized parts
	 * @param {String} source CSS selector source
	 * @returns {Array[String]}
	 */
	function parseSelectors(source) {
		// parse name with CSS parser to remove redundant tokens
		var tokens = _.isArray(source) ? source : cssParser.lex(source);
		tokens = _.filter(tokens, function(item) {
			return item.type !== 'comment';
		});

		var cur = '', selectors = [], t;
		for (var i = 0, il = tokens.length; i < il; i++) {
			t = tokens[i];
			if (t.type === ',') {
				selectors.push(normalizeSelector(cur));
				cur = '';
			} else if (t.type === 'line') {
				cur += ' ';
			} else {
				cur += t.value;
			}
		}

		selectors.push(normalizeSelector(cur));
		return _.compact(selectors);
	}

	/**
	 * Skips formatting tokens from current position
	 * @param {TokenIterator} tokens
	 * @param {Object} info
	 */
	function skipFormatting(iter) {
		return skipTokens(iter, fTokens);
	}

	/**
	 * Skips shitespace tokens from current position
	 * @param {TokenIterator} tokens
	 * @param {Object} info
	 */
	function skipWhitespace(iter) {
		return skipTokens(iter, sTokens);
	}

	function skipTokens(iter, tokenTypes) {
		var t, shifted = false;
		while ((t = iter.peek()) && t.type in tokenTypes) {
			shifted = true;
			iter.next();
		}

		return shifted;
	}

	/**
	 * Consumes CSS section
	 * @param {TokenIterator} iter
	 */
	function consumeSection(iter) {
		skipFormatting(iter);

		var curTokens = function() {
			return [iter.start, iter.pos];
			// return iter.tokens.slice(iter.start, iter.pos);
		};

		iter.start = iter.pos;
		var token, nameRange, valueRange, nameTokens;
		while (token = iter.peek()) {
			if (token.type === '@') {
				// consume at-rule
				iter.start = iter.pos;
				iter.skipTo(lookupS1);
				if (iter.peek().type === ';') {
					// at-rule end
					// in this case, rule's value is located right after
					// @name token
					var fullRange = iter.curRange(true);
					var tok = fullRange.substring(iter.source);
					var ruleName = tok.match(/^@?\w+/)[0];
					var s = fullRange.start;
					fullRange.start += ruleName.length;
					var hints = {
						startToken: iter.start,
						endToken: iter.pos
					};

					iter.ctx.addChild(new CSSNode(range.create2(s, fullRange.start), fullRange, hints));
					iter.next();
					skipFormatting(iter);
					iter.start = iter.pos;
					continue;
				}
			} else if (token.type === '{' || token.type === ':') {
				nameRange = iter.curRange(true);
				nameTokens = curTokens();
				iter.next();
				if (token.type === '{') {
					// entering new section
					var valueStart = token.start;
					var child = iter.ctx.addChild(new CSSNode(nameRange, null, {name: nameTokens, startToken: nameTokens[0]}));
					iter.ctx = child;
					consumeSection(iter);
					iter.ctx = iter.ctx.parent;

					var endPos, endToken;
					if (iter.peek()) {
						endPos = iter.peek().end;
						endToken = iter.pos;
					} else {
						endToken = iter.tokens.length - 1;
						endPos = iter.tokens[endToken].end;
					}

					child.valueRange = range.create2(token.start, endPos);
					child._hints.endToken = endToken;
					iter.next();
					skipFormatting(iter);
					iter.start = iter.pos;
				} else {
					// the `:` token might be either a name-value separator
					// or pseudo-class modifier, like :hover.
					// We need to correctly identify this token first
					var oldPos = iter.pos, t, shouldSkip = false;
					while (t = iter.next()) {
						if (t.type === '{') {
							// looks like a pseudo-class
							iter.backUp(1);
							shouldSkip = true;
							break;
						} else if (t.type === ';' || t.type === '}') {
							// name-value separator
							iter.pos = oldPos;
							break;
						}
					}

					if (shouldSkip) {
						continue;
					}

					// consume CSS value
					iter.start = iter.pos;
					iter.skipTo(lookupS2);
					valueRange = iter.curRange(true);

					var endToken = iter.pos;
					if (iter.peek().type === '}') {
						endToken--;
					}

					iter.ctx.addChild(new CSSNode(nameRange, valueRange, {
						type: 'property', 
						name: nameTokens,
						startToken: nameTokens[0],
						endToken: endToken
					}));
					
					if (iter.peek().type === ';') {
						iter.next();	
					}
					
					skipFormatting(iter);
					iter.start = iter.pos;
				}
			} else if (token.type === '}') {
				iter.next();
				skipWhitespace(iter);
				iter.backUp(1);
				return;
			} else {
				iter.next();
			}
		}
	}

	/**
	 * Validate tokens of parsed CSS. 
	 * Before parsing CSS into tree, we have to make sure that
	 * tokens are consistent enough to build valid tree. 
	 * Otherwise, incorrectly constructed tree may produce
	 * a lot of noise when patching
	 * @param  {Array} tokens CSS tokens
	 */
	function validateTokens(tokens) {
		var braces = 0;
		_.each(tokens, function(tok) {
			if (tok.type === '{') {
				braces++;
			} else if (tok.type === '}') {
				braces--;
			}
		});

		if (braces) {
			throw 'Invalid CSS structure';
		}
	}

	return {
		/**
		 * Builds tree from given CSS tokens
		 * @param {String} source Parsed CSS tokens
		 * @returns {CSSNode}
		 */
		build: function(source) {
			var tokens;
			if (_.isString(source)) {
				tokens = cssParser.parse(source);
			} else {
				tokens = source;
				source = cssParser.toSource(tokens);
			}

			validateTokens(tokens);
			var iter = new TokenIterator(tokens, source);
			while (iter.hasNext()) {
				consumeSection(iter);	
			}
			return iter.root;
		},

		/**
		 * Restores tree from JSON cache
		 * @param  {Object} obj  Tree JSON
		 * @param  {CSSNode} node Parent node of generated tree
		 * @return {CSSNode}
		 */
		fromJSONCache: function(obj, node) {
			if (_.isString(obj)) {
				obj = JSON.parse(obj);
			}

			node = node || new CSSNode(null, null, {type: 'root'});
			_.each(obj, function(item) {
				var child = new CSSNode();
				child._name = item.name;
				child._value = item.value;
				child.type = item.type;
				node.addChild(child);

				if (item.children) {
					this.fromJSONCache(item.children, child);
				}
			}, this);
			return node;
		},

		parseSelectors: parseSelectors,
		CSSNode: CSSNode,
		TokenIterator: TokenIterator
	};
});
define('locator',['lodash', 'tree'], function(_, tree) {
	if (typeof emmet == 'undefined') {
		try {
			emmet = require('vendor/emmet');
		} catch(e) {}
	}

	/**
	 * @param {CSSNode} node
	 * @returns {Array}
	 */
	function pathForNode(node) {
		if (!node.parent) {
			return null;
		}

		if (!node.__sectionPath) {
			var name = node.name(), nameLower = name.toLowerCase();
			var siblings = node.parent.children;
			var pos = 1;

			for (var i = 0, il = siblings.length; siblings[i] !== node && i < il; i++) {
				if (siblings[i].name(true) === nameLower) {
					pos++;
				}
			}

			node.__sectionPath = [name, pos];
		}

		return node.__sectionPath;
	}

	function itemSelector(node, options) {
		options = _.extend({syntax: 'css'}, options || {});

		if (options.syntax == 'scss') {
			var sel = [], ctx = node, n;
			while (ctx.parent) {
				n = node.name();
				if (/^@media/i.test(n)) {
					if (!sel.length) {
						return n;
					}
					break;
				}
				sel.push(node.name());
				ctx = ctx.parent;
			}

			return sel.join(' ');
		}

		return node.name();
	}

	function mergeSCSSSelectors(parts) {
		var p, out = [];
		while (p = parts.pop()) {
			if (p.charAt(0) == '&') {
				out.push(parts.pop() + p.substr(1))
			} else {
				out.push(p);
			}
		}

		return out.reverse().join(' ');
	}

	return {
		/**
		 * Creates string representation of CSS path
		 * @param  {Array} path
		 * @return {String}
		 */
		stringifyPath: function(path, skipPos) {
			if (_.isString(path)) {
				return path;
			}

			return path.map(function(p) {
				return p[0] + (!skipPos && p[1] > 1 ? '|' + p[1] : '');
			}).join('/');
		},

		/**
		 * Creates JSON path to locate given node
		 * @param {CSSNode} node
		 * @returns {String}
		 */
		createPath: function(node, options) {
			if (!_.isObject(options)) {
				options = {asString: !!options};
			}

			if (!node.__path) {
				// cache path for faster lookups
				var parts = [];
				while(node.parent) {
					parts.push(pathForNode(node));
					node = node.parent;
				}

				parts = parts.reverse();

				if (options.syntax == 'scss') {
					// for SCSS dialect, merge nested selectors
					var s, mergedParts = [], tmpParts = [];
					var reDontMerge = /^@media/i;
					while (s = parts.shift()) {
						if (reDontMerge.test(s[0])) {
							if (tmpParts.length) {
								mergedParts.push([mergeSCSSSelectors(tmpParts), 1]);
								tmpParts = [];
							}
							mergedParts.push(s);
						} else {
							tmpParts.push(s[0]);
						}
					}

					if (tmpParts.length) {
						mergedParts.push([mergeSCSSSelectors(tmpParts), 1]);
					}

					parts = mergedParts;
				}

				node.__path = parts;
			}
			
			return !options.asString ? node.__path : this.stringifyPath(node.__path);
		},

		/**
		 * Parses string CSS path into internal structure
		 * @param  {String} path CSS path
		 * @return {Array}
		 */
		parsePath: function(path) {
			if (!_.isString(path)) {
				return path;
			}

			if (path.charAt(0) == '[' || path.charAt(0) == '{') {
				return JSON.parse(path);
			}

			var parts = [], part, ch, ch2;
			var reIndex = /\|(\d+)$/;
			var stream = emmet.require('stringStream').create(path);

			while (ch = stream.next()) {
				switch(ch) {
					case '/':
						part = stream.current().trim();
						parts.push(part.substring(0, part.length - 1).trim());
						stream.start = stream.pos;
						break;
					case '"':
					case '\'':
						while (ch2 = stream.next()) {
							if (ch2 == '\\') {
								stream.next();
							} else if (ch2 == ch) {
								break;
							}
						}
						break;
				}
			}

			parts.push(stream.current().trim());
			return  _.compact(parts).map(function(item) {
				var ix = 1;
				item = item.replace(reIndex, function(str, p1) {
					ix = +p1;
					return '';
				});
				return [item, ix];
			});
		},

		/**
		 * Normalizes given CSS path for matching it agains tree
		 * @param  {Array} path
		 * @return {Array}
		 */
		normalizePath: function(path) {
			return this.parsePath(path).map(function(item) {
				return [tree.parseSelectors(item[0]).join(', '), item[1]];
			});
		},

		/**
		 * Locates node in given tree by specified path
		 * @param  {CSSNode} cssTree
		 * @param  {String} path
		 * @return {CSSNode}
		 */
		locate: function(cssTree, path, options) {
			options = options || {};

			if (options.syntax == 'scss') {
				return this.locateSCSS(cssTree, path)
			}

			path = this.normalizePath(path);
			var ctx = cssTree, items, part, partLower;
			while (part = path.shift()) {
				partLower = part[0].toLowerCase();
				items = _.filter(ctx.children, function(item) {
					var n = itemSelector(item, options);
					return n == part[0] || n.toLowerCase() == partLower;
				});

				ctx = items[part[1] - 1];
				if (!ctx) {
					break;
				}
			}

			return ctx;
		},

		locateSCSS: function(cssTree, path) {
			path = this.normalizePath(path);
			var that = this;
			var opt = {syntax: 'scss'};
			var allPaths = cssTree.all().map(function(node) {
				return {
					path: that.createPath(node, opt),
					node: node
				};
			});

			var items, part, partLower, pathPos = 0;
			while (part = path.shift()) {
				partLower = part[0].toLowerCase();
				allPaths = allPaths.filter(function(item) {
					if (item.path[pathPos]) {
						return item.path[pathPos][0].toLowerCase() == partLower;
					}
				});

				if (allPaths[part[1] - 1]) {
					allPaths = [allPaths[part[1] - 1]];
					pathPos++;
				} else {
					allPaths = null;
					break;
				}
			}

			return allPaths && allPaths[0] ? allPaths[0].node : null;
		},

		/**
		 * Guesses node location in given tree by specified path.
		 * This method might return partial match (e.g. match only 
		 * part of path)
		 * @param  {CSSNode} cssTree
		 * @param  {String} path
		 */
		guessLocation: function(cssTree, path) {
			path = this.normalizePath(path);
			
			var find = function(collection, path) {
				if (_.isArray(path)) path = path[0];
				return collection.filter(function(item) {
					return item.name() == path;
				});
			};

			var ctx = cssTree, part, items;
			while (part = path.shift()) {
				var node = this.locate(ctx, [part]);
				if (!node) {
					items = find(ctx.children, part);
					if (items.length) {
						// TODO add better heuristics on detecting best match
						if (path[0]) {
							// try to find last node containing
							// next child
							node = _.last(items.filter(function(item) {
								return find(item.children, path[0]).length;
							}));
						}

						if (!node) {
							node = _.last(items);
						}
					}
				}

				if (!node) { // nothing found, stop here
					path.unshift(part);
					break;
				} else {
					ctx = node;
				}
			}

			return {
				found: ctx !== cssTree,
				node: ctx,
				rest: path.length ? path : null
			};
		},

		/**
		 * Locates node in given tree by specified character position
		 * @param  {CSSNode} cssTree
		 * @param  {Number} pos
		 * @return {CSSNode}
		 */
		locateByPos: function(cssTree, pos) {
			for (var i = 0, il = cssTree.children.length, item; i < il; i++) {
				item = cssTree.children[i];
				if (item.range().include(pos)) {
					return this.locateByPos(item, pos) || item;
				}
			}
		}
	};
});
/**
 * Calculates structural difference between two CSS sources.
 * Useful for calculating diff when editing file in text editor
 */
define('diff',['lodash', 'tree', 'locator'], function(_, tree, locator) {

	var valueCompare = {
		'@import': true,
		'@charset': true
	};

	/**
	 * Parses CSS source into tree
	 * @param  {String} source
	 * @return {CSSNode}
	 */
	function parseSource(source) {
		if (source instanceof tree.CSSNode) {
			return source;
		}

		return tree.build(source);
	}

	/**
	 * Returns plain list of all sections in given CSS tree
	 * @param  {CSSNode} node
	 * @param {Array} out
	 * @return {Array}
	 */
	function sectionList(node, out) {
		out = out || [];
		if (node && node.children) {
			// for better performance, don't use _.each or [].forEach iterators
			for (var i = 0, il = node.children.length, c; i < il; i++) {
				c = node.children[i];
				if (c.type != 'property') {
					out.push(c);
					sectionList(c, out);
				}
			}
		}

		return out;
	}

	/**
	 * Transforms given sections list into array with
	 * absolute paths
	 * @param  {Array} sections CSS sections list
	 * @return {Array}
	 */
	function sectionPaths(sections, options) {
		if (!(sections instanceof Array)) {
			sections = sectionList(sections);
		}

		return _.map(sections, function(section) {
			var path = locator.createPath(section, options);
			return {
				path: path,
				pathString: locator.stringifyPath(path, true),
				section: section
			};
		});
	}

	/**
	 * Check if CSS node with given name/selector should be compared
	 * by value, not by children contents
	 * @param  {CSSNode} node CSS node or node name/selector (string)
	 * @return {Boolean}
	 */
	function shouldCompareValues(node) {
		if (!_.isString(node)) {
			node = node.name().toLowerCase();
		} else {
			node = node.toLowerCase();
		}

		return node in valueCompare;
	}

	/**
	 * Compares properties inside CSS sections (selectors).
	 * Does not take into account subsections, compares 
	 * just properties
	 * @param  {CSSNode} s1
	 * @param  {CSSNode} s2
	 * @return {Object} Returns null if sections are equal
	 */
	function diffSections(s1, s2) {
		var props1 = s1.properties();
		var props2 = s2.properties();

		var added = [], updated = [], removed = [];
		var lookupIx = 0;

		_.each(props2, function(p, i) {
			var op = props1[lookupIx];
			if (!op) {
				// property was added at the end
				return added.push(p);
			}

			if (p.name === op.name) {
				++lookupIx;
				if (p.value !== op.value) {
					// same property, different value:
					// the property was updated
					// TODO check for edge cases with vendor-prefixed values
					updated.push(p);
				}

				return;
			}

			// look further for property with the same name
			for (var nextIx = lookupIx + 1, il = props1.length; nextIx < il; nextIx++) {
				if (props1[nextIx].name === p.name && props1[nextIx].value === p.value) {
					removed = removed.concat(props1.slice(lookupIx, nextIx));
					lookupIx = nextIx + 1;
					return;
				}
			}

			// if we reached this point then the current property
			// was added to section2
			added.push(p);
		});

		removed = removed.concat(props1.slice(lookupIx, props1.length));

		if (added.length + updated.length + removed.length === 0) {
			return null;
		}

		return {
			added: added,
			updated: updated,
			removed: removed
		};
	}

	/**
	 * Check if section contents are equal
	 * @param  {CSSNode} s1 
	 * @param  {CSSNode} s2
	 * @return {Boolean}
	 */
	function sectionsEqual(s1, s2) {
		if (shouldCompareValues(s1)) {
			return s1.value() == s2.value();
		}

		// don't use diffSections() here since it pretty slow for
		// such checks
		var s1p = s1.properties(), s2p = s2.properties();
		if (s1p.length !== s2p.length) {
			return false;
		}

		for (var i = 0, il = s1p.length; i < il; i++) {
			if (s1p[i].name !== s2p[i].name || s1p[i].value !== s2p[i].value) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Removes identical CSS sections from both lists.
	 * Lists are modiefied in-place
	 * @param  {Array} sections1
	 * @param  {Array} sections2
	 */
	function removeEqual(sections1, sections2) {
		var diff2 = [];

		var item1, item2;
		// optimize innner loops for performance
		for (var i = 0, il = sections2.length; i < il; i++) {
			item2 = sections2[i];

			for (var j = 0, jl = sections1.length, item1; j < jl; j++) {
				item1 = sections1[j];
				if (item1.pathString == item2.pathString && sectionsEqual(item1.section, item2.section)) {
					// nodes are equal, get rid of them
					sections1.splice(j, 1);
					sections2.splice(i, 1);
					il--;
					i--;
					break;
				}
			}
		};
	}

	return {
		/**
		 * Generates patches that describe structural difference
		 * between two CSS sources
		 * @param  {String} source1
		 * @param  {String} source2
		 * @return {Array}
		 */
		diff: function(source1, source2, options) {
			options = _.extend({syntax: 'css'}, options || {});
			var t1 = parseSource(source1, options);
			var t2 = parseSource(source2, options);

			var l1 = sectionPaths(t1, options);
			var l2 = sectionPaths(t2, options);
			var out = [];

			// first, remove all identical sections from both lists
			// and leave only different ones
			removeEqual(l1, l2);

			// find and remove from list sections with the same name:
			// they should be modified
			_.each(l2, function(item2, i) {
				var item1 = _.find(l1, function(item1) {
					return item1.pathString == item2.pathString;
				});

				var p = {
					path: item2.path,
					action: item1 ? 'update' : 'add'
				};

				if (shouldCompareValues(item2.section)) {
					p.value = item2.section.value();
				}

				if (p.action == 'update') {
					// section was updated
					if (!('value' in p)) {
						var sd = diffSections(item1.section, item2.section);
						p.properties = sd.added.concat(sd.updated);
						p.removed = sd.removed;
					}
					
					l1 = _.without(l1, item1);
				} else {
					// section was added
					if (!('value' in p)) {
						p.properties = item2.section.properties();
					}
				}

				out.push(p);
			});

			// remove the rest sections from first list
			_.each(l1, function(item) {
				out.push({
					path: item.path,
					action: 'remove'
				});
			});

			return out;
		},

		/**
		 * Compares properties inside CSS sections (selectors).
		 * Does not take into account subsections, compares 
		 * just properties
		 * @param  {CSSNode} s1
		 * @param  {CSSNode} s2
		 * @return {Object} Returns null if sections are equal
		 */
		diffSections: diffSections,

		/**
		 * Check if CSS node with given name/selector should be compared
		 * by value, not by children contents
		 * @param  {CSSNode} node CSS node or node name/selector (string)
		 * @return {Boolean}
		 */
		shouldCompareValues: shouldCompareValues
	};
});
/**
 * Applies patch to CSS source
 */
define('patch',['lodash', 'tree', 'locator', 'diff', 'cssParser'], function(_, tree, locator, diff, cssParser) {
	if (typeof emmet == 'undefined') {
		try {
			emmet = require('vendor/emmet');
		} catch(e) {}
	}

	var defaultStyle = {
		// TODO read default style from preferences
		selSep: ' ',
		sectionSep: '\n',
		indent: '\n\t',
		sep: ': ',
		end: '\n'
	};

	var reStartSpace = /^\s+/;
	var reEndSpace = /\s+$/;

	/**
	 * Creates new CSS section (rule) with given name (selector)
	 * and content
	 * @param  {String} name    Section name
	 * @param  {String} value   Section content
	 * @param  {Object} style   Formatting options
	 * @return {String}
	 */
	function createSection(name, value, style) {
		// TODO: learn the following:
		// * Formatting for media queries
		return name + style.selSep + '{' + style.indent + value + style.end + '}';
	}

	/**
	 * Tries to guess indentation for new sections/properties
	 * in given CSS node
	 * @param  {CSSNode} node
	 * @return {Object}
	 */
	function learnStyle(node) {
		var cssDOM;
		var style = _.clone(defaultStyle);

		if (node.type == 'property') {
			node = node.parent;
		}

		// we need a node with children to get proper formatting
		var hasProperties = function(item) {
			for (var i = 0, il = item.children.length; i < il; i++) {
				if (item.children[i].type == 'property') {
					return true;
				}
			}

			return false;
		};

		var donor = node, _n;
		while (donor = donor.parent) {
			_n = _.find(donor.children, hasProperties);
			if (_n) {
				donor = _n;
				break;
			}
		}

		if (!donor) {
			// node not found, pick the first one with properties
			donor = _.find(node.all(), hasProperties);
		}

		if (donor && donor.parent) {
			style.selSep = donor.rawName().match(/([\s\n\r]+)$/) ? RegExp.$1 : '';
			try {
				cssDOM = emmet.require('cssEditTree').parse(donor.toSource());
			} catch (e) {}
		}

		if (cssDOM) {
			var lastElem = _.last(cssDOM.list());
			if (lastElem) {
				style.indent = lastElem.styleBefore;
				style.sep = lastElem.styleSeparator;
				style.end = cssDOM.source.substring(lastElem.fullRange().end, cssDOM.source.length - 1);
			}
		}

		return style;
	}

	/**
	 * Finds best insertion position for given item name in
	 * specified parent section. Some items like `@charset` or
	 * `@import` should be inserted at the top of the document
	 * @param  {CSSNode} parent Parent section where child should be inserted
	 * @param  {String} name    Child item name to be inserted
	 * @return {Number}
	 */
	function findBestInsertionPos(parent, name) {
		name = name.toLowerCase();
		if (name == '@charset') {
			return 0;
		}

		if (name == '@import') {
			// insert this import after all other imports
			for (var i = 0, il = parent.children.length, n; i < il; i++) {
				n = parent.children[i].name().toLowerCase();
				if (n != '@charset' && n != '@import') {
					return i;
				}
			}

			return 0;
		}

		return parent.children.length;
	}

	/**
	 * Tries to find best partial match of given path on CSS tree and returns
	 * target section
	 * @param  {CSSNode} cssTree CSS tree
	 * @param  {Array} cssPath Parsed CSS path
	 * @return {CSSNode}
	 */
	function bestPartialMatch(cssTree, cssPath, patch) {
		var loc = locator.guessLocation(cssTree, cssPath);
		if (loc.node.parent) {
			var ctxName = loc.node.name().toLowerCase();
			if (ctxName == '@import' && patch.action == 'add') {
				// in case of added @import rule, make sure it was added,
				// not replaced existing rule
				if (!loc.rest) {
					loc.rest = [];
				}

				loc.rest.unshift([ctxName]);
				loc.node = loc.node.parent;
			}
		}

		if (loc.rest) {
			var _value = '';
			var style = learnStyle(loc.node);
			var utils = emmet.require('utils');

			// incomplete match, create new sections and inject it into tree
			var parentName = loc.rest[0][0];
			var lastSection = loc.rest.pop();
			if (diff.shouldCompareValues(lastSection[0]) && 'value' in patch) {
				_value = lastSection[0] + ' ' + patch.value + ';';
			} else {
				_value = createSection(lastSection[0], '', _.defaults({indent: ''}, style));
				_value = patchSection(tree.build(_value).children[0], patch, style);
			}

			var padding = style.indent.match(/([ \t]+)$/) ? RegExp.$1 : '';

			for (var i = loc.rest.length - 1; i >= 0; i--) {
				_value = createSection(loc.rest[i][0], utils.padString(_value, padding), style);
			}

			var insPos = findBestInsertionPos(loc.node, parentName);
			var totalChildren = loc.node.children.length;
			if (totalChildren && insPos !== totalChildren) {
				_value += style.sectionSep;
			} else if (totalChildren) {
				_value = style.sectionSep + _value;
			}

			// console.log('Partial "%s"', _value);

			loc.node.insert(tree.build(_value), insPos);
		} else {
			var rule = patchSection(loc.node, patch);
			loc.node.replace(tree.build(rule));
		}
	}

	/**
	 * Patches section by its value, not properties
	 * @param  {CSSNode} section Section to patch
	 * @param  {Object} patch   Patch to apply
	 * @return {String}         Updated section as string
	 */
	function patchSectionByValue(section, patch) {
		var fullSource = section.toFullSource();
		var value = section.rawValue();
		var offset = section.fullRange().start;
		var vStart = section.valueRange.start - offset;
		var vEnd = section.valueRange.end - offset;

		// get indentation
		var m;
		if (m = value.match(reStartSpace)) {
			vStart += m[0].length;
		}

		if (m = value.match(reEndSpace)) {
			vEnd -= m[0].length;
		}

		var sep = value ? '' : ' ';
		var out = fullSource.substring(0, vStart)
			+ sep + patch.value
			+ fullSource.substring(vEnd);

		// console.log('In:  "%s"', fullSource);
		// console.log('Out: "%s"', out);
		return out;
	}

	function patchSection(section, patch, style) {
		if ('value' in patch) {
			// updating full value of section, like `@import`
			return patchSectionByValue(section, patch);
		}

		style = style || learnStyle(section);
		var rule = emmet.require('cssEditTree').parse(section.toFullSource(), {
			styleBefore: style.indent,
			styleSeparator: style.sep
		});

		// update properties
		_.each(patch.properties, function(prop) {
			var ruleProp;
			if ('index' in prop) {
				ruleProp = rule.get(prop.index);
				if (!ruleProp || ruleProp.name() != prop.name) {
					ruleProp = _.last(rule.getAll(prop.name));
				}
			}

			if (ruleProp) {
				ruleProp.value(prop.value);
			} else {
				rule.value(prop.name, prop.value);
			}
		});

		// remove properties
		_.each(patch.removed, function(prop) {
			rule.remove(prop.name);
		});

		return rule.source;
	}


	return {
		/**
		 * Condenses list of patches: merges multiple patches for the same 
		 * selector into a single one and tries to reduce operations.
		 * The order of patches is very important since it affects the list
		 * of updates applied to source code
		 * @param {Array} patches
		 * @return {Array}
		 */
		condense: function(patches) {
			var byPath = {};
			var find = function(collection, propName) {
				for (var i = 0, il = collection.length; i < il; i++) {
					if (collection[i].name === propName) {
						return collection[i];
					}
				};
			};

			// group patches by their path for faster lookups
			_.each(patches, function(patch) {
				var path = locator.stringifyPath(patch.path);
				if (!(path in byPath)) {
					byPath[path] = [];
				}

				byPath[path].push(patch);
			});


			return _.map(byPath, function(patchList, path) {
				var topPatch = _.cloneDeep(patchList[0]);
				_.each(_.rest(patchList), function(patch) {
					if (patch.action == 'remove' || topPatch.action == 'remove') {
						// supress all previous updates
						return topPatch = patch;
					}

					topPatch.action = 'update';

					topPatch.removed = _.filter(topPatch.removed, function(item) {
						return !find(patch.properties, item.name);
					});

					topPatch.properties = topPatch.properties.concat(_.filter(patch.properties, function(item) {
						var origItem = find(topPatch.properties, item.name);
						if (origItem) {
							origItem.value = item.value;
							return false;
						}

						return true;
					}));

					topPatch.removed = topPatch.removed.concat(_.filter(patch.removed, function(item) {
						return !find(topPatch.removed, item.name);
					}));

				});

				return topPatch;
			});
		},

		/**
		 * Applies given patches to CSS source
		 * @param  {String} source  CSS source
		 * @param  {Array} patches  List of patches to apply
		 * @return {String}         Patched CSS source
		 */
		patch: function(source, patches, options) {
			patches = this.condense(_.isArray(patches) ? patches : [patches]);
			var cssTree = _.isString(source) ? tree.build(source) : source;

			_.each(patches, function(patch) {
				var cssPath = locator.parsePath(patch.path);
				var section = locator.locate(cssTree, cssPath, options);

				if (patch.action === 'remove') {
					if (section) {
						section.remove();
					}

					return;
				}

				if (!section) {
					bestPartialMatch(cssTree, cssPath, patch);
				} else {
					var rule = patchSection(section, patch);
					// update matched section with new source
					section.replace(tree.build(rule));
				}
			});

			return cssTree.source();
		},

		learnStyle: learnStyle
	};
});
/**
 * A simple event dispatcher mixin, borrowed from Backbone.Event.
 * Users should extend their objects/modules with this mixin.
 * @example
 * define(['lodash', 'eventMixin'], function(_, eventMixin) {
 * 	return _.extend({
 * 		...
 * 	}, eventMixin);
 * })
 */
define('eventMixin',[],function() {
	// Regular expression used to split event strings
	var eventSplitter = /\s+/;
	
	  // Create a local reference to slice/splice.
	  var slice = Array.prototype.slice;
	
	return {
		/**
		 * Bind one or more space separated events, `events`, to a `callback`
		 * function. Passing `"all"` will bind the callback to all events fired.
		 * @param {String} events
		 * @param {Function} callback
		 * @param {Object} context
		 * @memberOf eventDispatcher
		 */
		on: function(events, callback, context) {
			var calls, event, node, tail, list;
			if (!callback)
				return this;
			
			events = events.split(eventSplitter);
			calls = this._callbacks || (this._callbacks = {});

			// Create an immutable callback list, allowing traversal during
			// modification.  The tail is an empty object that will always be used
			// as the next node.
			while (event = events.shift()) {
				list = calls[event];
				node = list ? list.tail : {};
				node.next = tail = {};
				node.context = context;
				node.callback = callback;
				calls[event] = {
					tail : tail,
					next : list ? list.next : node
				};
			}

			return this;
		},

		/**
		 * Remove one or many callbacks. If `context` is null, removes all
		 * callbacks with that function. If `callback` is null, removes all
		 * callbacks for the event. If `events` is null, removes all bound
		 * callbacks for all events.
		 * @param {String} events
		 * @param {Function} callback
		 * @param {Object} context
		 */
		off: function(events, callback, context) {
			var event, calls, node, tail, cb, ctx;

			// No events, or removing *all* events.
			if (!(calls = this._callbacks))
				return;
			if (!(events || callback || context)) {
				delete this._callbacks;
				return this;
			}

			// Loop through the listed events and contexts, splicing them out of the
			// linked list of callbacks if appropriate.
			events = events ? events.split(eventSplitter) : _.keys(calls);
			while (event = events.shift()) {
				node = calls[event];
				delete calls[event];
				if (!node || !(callback || context))
					continue;
				// Create a new list, omitting the indicated callbacks.
				tail = node.tail;
				while ((node = node.next) !== tail) {
					cb = node.callback;
					ctx = node.context;
					if ((callback && cb !== callback) || (context && ctx !== context)) {
						this.on(event, cb, ctx);
					}
				}
			}

			return this;
		},
		
		/**
		 * Trigger one or many events, firing all bound callbacks. Callbacks are
		 * passed the same arguments as `trigger` is, apart from the event name
		 * (unless you're listening on `"all"`, which will cause your callback
		 * to receive the true name of the event as the first argument).
		 * @param {String} events
		 */
		trigger: function(events) {
			var event, node, calls, tail, args, all, rest;
			if (!(calls = this._callbacks))
				return this;
			all = calls.all;
			events = events.split(eventSplitter);
			rest = slice.call(arguments, 1);

			// For each event, walk through the linked list of callbacks twice,
			// first to trigger the event, then to trigger any `"all"` callbacks.
			while (event = events.shift()) {
				if (node = calls[event]) {
					tail = node.tail;
					while ((node = node.next) !== tail) {
						node.callback.apply(node.context || this, rest);
					}
				}
				if (node = all) {
					tail = node.tail;
					args = [ event ].concat(rest);
					while ((node = node.next) !== tail) {
						node.callback.apply(node.context || this, args);
					}
				}
			}

			return this;
		}
	};
});
define('socket',['lodash', 'eventMixin'], function(_, eventMixin) {
	var url = 'ws://localhost:54000/browser';
	var sock = null;
	var retryTimeout = 1 * 1000;
	var autoRetry = true;
	var _timer;

	function createSocket(callback) {
		var opened = false;
		var s = new WebSocket(url);
		if (_timer) {
			clearTimeout(_timer);
			_timer = null;
		}

		s.onclose = function() {
			sock = null;
			module.trigger('close');

			if (!opened && callback) {
				// cannot establish initial connection
				callback(false);
			}

			if (autoRetry) {
				_timer = setTimeout(createSocket, retryTimeout, callback);
			}
		};

		s.onopen = function() {
			sock = s;
			opened = true;
			callback && callback(true, sock);
			module.trigger('open');
		};

		s.onmessage = function(evt) {
			module.trigger('message', JSON.parse(evt.data));
		};

		s.onerror = function(e) {
			module.trigger('error', e);
		};
	}

	
	var module = {
		/**
		 * Establishes socket connection
		 * @param  {Function} callback
		 */
		connect: function(callback) {
			if (!this.active()) {
				autoRetry = true;
				createSocket(callback);
			} else if (callback) {
				callback(true, sock);
			}
		},

		/**
		 * Disconnects from socket
		 */
		disconnect: function() {
			if (this.active()) {
				autoRetry = false;
				sock.close();
			}
		},

		/**
		 * Check is socket is active and ready to use
		 * @return {Boolean}
		 */
		active: function() {
			return !!sock;
		},

		/**
		 * Check socket activity status. If it‘s not active, tries to re-connect
		 */
		check: function() {
			if (!this.active()) {
				createSocket();
			}
		},

		/**
		 * Sends given message to socket
		 * @param  {String} message
		 */
		send: function(message) {
			if (!_.isString(message)) {
				message = JSON.stringify(message);
			}

			if (this.active()) {
				sock.send(message);
			}
		}
	};

	return _.extend(module, eventMixin);
});
/**
 * Global Event dispatcher
 */
define('dispatcher',['lodash', 'eventMixin'], function(_, evt) {
	return _.extend({}, evt);
});
/*!
 * Simple file path manipulation utility, borrowed from Node.JS
 * Copyright Joyent, Inc. and other Node contributors.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
 * NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
 * USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
define('path',[],function() {
	/**
	 * Resolves . and .. elements in a path array with directory names there
	 * must be no slashes, empty elements, or device names (c:\) in the array
	 * (so also no leading and trailing slashes - it does not distinguish
	 * relative and absolute paths)
	 * @param  {Array} parts
	 * @param  {Boolean} allowAboveRoot
	 */
	function normalizeArray(parts, allowAboveRoot) {
		// if the path tries to go above the root, `up` ends up > 0
		var up = 0;
		for (var i = parts.length - 1; i >= 0; i--) {
			var last = parts[i];
			if (last === '.') {
				parts.splice(i, 1);
			} else if (last === '..') {
				parts.splice(i, 1);
				up++;
			} else if (up) {
				parts.splice(i, 1);
				up--;
			}
		}

		// if the path is allowed to go above the root, restore leading ..s
		if (allowAboveRoot) {
			for (; up--; up) {
				parts.unshift('..');
			}
		}

		return parts;
	}

	// Split a filename into [root, dir, basename, ext], unix version
	// 'root' is just a slash, or nothing.
	var splitPathRe = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
	var splitPath = function(filename) {
		return splitPathRe.exec(filename).slice(1);
	};

	return {
		sep: '/',
		delimiter: ':',

		resolve: function() {
			var resolvedPath = '', resolvedAbsolute = false;

			for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
				var path = (i >= 0) ? arguments[i] : '';

				// Skip empty and invalid entries
				if (typeof path !== 'string') {
					throw new TypeError('Arguments to path.resolve must be strings');
				} else if (!path) {
					continue;
				}

				resolvedPath = path + '/' + resolvedPath;
				resolvedAbsolute = path.charAt(0) === '/';
			}

			// At this point the path should be resolved to a full absolute path, but
			// handle relative paths to be safe (might happen when process.cwd() fails)

			// Normalize the path
			resolvedPath = normalizeArray(resolvedPath.split('/').filter(function(p) {
				return !!p;
			}), !resolvedAbsolute).join('/');

			return ((resolvedAbsolute ? '/' : '') + resolvedPath) || '.';
		},

		normalize:  function(path) {
			var isAbsolute = this.isAbsolute(path);
			var trailingSlash = path.substr(-1) === '/';

			// Normalize the path
			path = normalizeArray(path.split('/').filter(function(p) {
				return !!p;
			}), !isAbsolute).join('/');

			if (!path && !isAbsolute) {
				path = '.';
			}

			if (path && trailingSlash) {
				path += '/';
			}

			return (isAbsolute ? '/' : '') + path;
		},

		isAbsolute: function(path) {
			return path.charAt(0) === '/';
		},

		join: function() {
			var paths = Array.prototype.slice.call(arguments, 0);
			return this.normalize(paths.filter(function(p, index) {
				if (typeof p !== 'string') {
					throw new TypeError('Arguments to path.join must be strings');
				}
				return p;
			}).join('/'));
		},

		relative: function(from, to) {
			from = this.resolve(from).substr(1);
			to = this.resolve(to).substr(1);

			function trim(arr) {
				var start = 0;
				for (; start < arr.length; start++) {
					if (arr[start] !== '') break;
				}

				var end = arr.length - 1;
				for (; end >= 0; end--) {
					if (arr[end] !== '') break;
				}

				if (start > end) return [];
				return arr.slice(start, end - start + 1);
			}

			var fromParts = trim(from.split('/'));
			var toParts = trim(to.split('/'));

			var length = Math.min(fromParts.length, toParts.length);
			var samePartsLength = length;
			for (var i = 0; i < length; i++) {
				if (fromParts[i] !== toParts[i]) {
					samePartsLength = i;
					break;
				}
			}

			var outputParts = [];
			for (var i = samePartsLength; i < fromParts.length; i++) {
				outputParts.push('..');
			}

			outputParts = outputParts.concat(toParts.slice(samePartsLength));

			return outputParts.join('/');
		},

		dirname: function(path) {
			var result = splitPath(path);
			var root = result[0];
			var dir = result[1];

			if (!root && !dir) {
				// No dirname whatsoever
				return '.';
			}

			if (dir) {
				// It has a dirname, strip trailing slash
				dir = dir.substr(0, dir.length - 1);
			}

			return root + dir;
		},

		basename: function(path, ext) {
			var f = splitPath(path)[2];
			if (ext && f.substr(-1 * ext.length) === ext) {
				f = f.substr(0, f.length - ext.length);
			}
			return f;
		},

		extname: function(path) {
			return splitPath(path)[3];
		},

		/**
		 * Returns given paths with prettified and shortened names
		 * @param  {Array} list List of paths
		 * @return {Array} List of objects with <code>name</code> and
		 * <code>path</code> properties
		 */
		prettifyPaths: function(list) {
			var lookup = {};
			var storeItem = function(item) {
				if (!(item in lookup)) {
					lookup[item] = 0;
				}

				lookup[item]++;
				return item;
			};

			var isValid = function() {
				return !Object.keys(lookup).some(function(k) {
					return lookup[k] > 1;
				});
			};

			var that = this;
			var out = list.map(function(item) {
				return {
					name: storeItem(that.basename(item)),
					dir: that.dirname(item),
					path: item
				};
			});

			var shouldBreak = false;
			while (!isValid() && !shouldBreak) {
				lookup = {};
				out = out.map(function(item) {
					var name = that.join(that.basename(item.dir), item.name);
					if (name === item.name) {
						shouldBreak = true;
					}

					return {
						name: storeItem(name),
						dir: that.dirname(item.dir),
						path: item.path
					};
				});
			}

			return out;
		}
	};
});
/**
 * Panel view for extensions. Holds current connection status
 * and file associations
 */
define('extension/panelView',['lodash', 'path', 'eventMixin'], function(_, path, eventMixin) {
	var view = document.createElement('div');
	view.innerHTML = '<div class="socket">'
		+ '<span class="socket__status active">Editor name</span>'
		+ '<span class="socket__status inactive">No active editor <i class="reload"></i></span>'
		+ '</div>'
		+ '<div class="livestyle-toggler">'
		+ '<input type="checkbox" name="enabled" class="livestyle-enabled" id="livestyle-enabled" /> '
		+ '<label for="livestyle-enabled">Enable LiveStyle for current page</label>'
		+ '</div>'
	
		+ '<div class="mappings">'
		+ '<h2>File mapping</h2>'
		+ '<p>Associate web page files (on the left) with editor files (on the right). Open more CSS files in editor to make them appear in drop-down menus.</p>'
		+ '<ul class="sources"></ul>'
		+ '</div>';

	view.className = 'livestyle livestyle_disabled';

	var pluginActive = false;
	var editorId = null;
	var editorFiles = null;
	var browserFiles = null;
	var assocs = null;

	var silenceChangeEvt = false;

	// current module back-reference
	var module = null;

	var rePathParts = /[\/\\]/g;

	/**
	 * Returns single element with given class name
	 * @param  {String}  className 
	 * @param  {Element} context
	 * @return {Element}
	 */
	function getByClass(className, context) {
		return (context || view).getElementsByClassName(className)[0];
	}

	/**
	 * Saves file associations
	 */
	function saveAssociations() {
		var oldAssocs = JSON.stringify(assocs);
		assocs = {};

		_.each(view.querySelectorAll('.mappings .sources__item'), function(item) {
			var browserFile = getByClass('sources__browser', item).getAttribute('title');
			var editorFile  = getByClass('sources__editor', item).value;
			assocs[browserFile] = editorFile || null;
		});

		if (oldAssocs !== JSON.stringify(assocs)) {
			module.trigger('saveAssociations', assocs);
		}
		
		return assocs;
	}

	/**
	 * Creates clonable widget with given file list
	 * @param  {Array} files
	 * @return {Element}
	 */
	function buildEditorFilesWidget(files) {
		files = path.prettifyPaths(files);
		return '<select name="editor-file" class="sources__editor">'
			+ '<option value="">...</option>'
			+ files.map(function(item) {
				return '<option value="' + item.path + '">' + _.escape(item.name || item.path) + '</option>';
			})
			+ '</select>';
	}

	/**
	 * Updates list of file associations
	 * @param  {Array} browserFiles List of browser files
	 * @param  {Array} editorFiles  List of editor files
	 */
	function updateResources(browserFiles, editorFiles) {
		if (!browserFiles || !editorFiles) {
			return;
		}

		var w = buildEditorFilesWidget(editorFiles);
		var elem = getByClass('sources');
		var reInternal = /^livestyle:/i;
		var blobCount = 0;

		elem.innerHTML = path.prettifyPaths(browserFiles).map(function(item) {
			var isUserFile = reInternal.test(item.path);
			var fileName = isUserFile ? 'user CSS ' + (++blobCount) : item.name;
			var parts = fileName.split('?');

			return '<li class="sources__item' + (isUserFile ? ' sources__item_user' : '') + '">'
				+ '<i class="remove"></i>'
				+ '<span class="sources__browser" title="' + item.path + '">' + (parts.shift() || item.path) 
				+ (parts.length ? '<span class="sources__qs">?' + parts.join('?') + '</span>' : '')
				+ '</span> '
				+ '<i class="dirs"></i> '
				+ w
				+ '</li>';
		}).join('');

		guessAssociations(assocs);
	}

	/**
	 * Scores how matches each other.
	 * 0 – no match
	 * >0 — has match. Higher value means better matching
	 * @param  {String} path1
	 * @param  {String} path2 
	 * @return {Number}
	 */
	function scorePathMatch(path1, path2) {
		var p1 = path1.split(rePathParts).reverse();
		var p2 = path2.split(rePathParts).reverse();

		var smaller = p1.length > p2.length ? p2 : p1;
		var larger =  p1.length > p2.length ? p1 : p2;

		var score = 0;
		_.find(smaller, function(part, i) {
			if (part === larger[i]) {
				score += 1;
				return false;
			}

			if (part.toLowerCase() == larger[i].toLowerCase()) {
				score += 0.2;
				return false;
			}

			return true;
		});

		return score;
	}

	/**
	 * Searches for best path match in given list.
	 * @param  {String} path       Path to score
	 * @param  {Array}  pathsList  List of paths to match against
	 * @return {String} Returns null if all paths were scored with 0 value
	 */
	function findBestScoredMatch(path, pathsList) {
		var foundIx = -1, maxScore = 0;
		pathsList.forEach(function(p, i) {
			var score = scorePathMatch(path, p);
			if (score > maxScore) {
				maxScore = score;
				foundIx = i;
			}
		});

		return foundIx == -1 ? null : pathsList[foundIx];
	}

	function pickOption(options, value) {
		_.find(options, function(opt) {
			if (opt.value == value) {
				return opt.selected = true;
			}
		});
	}

	/**
	 * Updates mapping UI: picks associated editor file
	 * or finds bes match, if possible
	 */
	function updateMappingUI(hints) {
		hints = hints || {};
		var updates = {};

		_.each(view.getElementsByClassName('sources__item'), function(item) {
			var bw = getByClass('sources__browser', item);
			var browserFile = bw.getAttribute('title');
			var browserOptName = bw.textContent.trim().split('?')[0];
			var editorFilesOpt = item.querySelectorAll('.sources__editor option');
			var editorFiles = _.pluck(editorFilesOpt, 'value');

			if (browserFile in hints) {
				// we already have associated file, pick it if possible
				pickOption(editorFilesOpt, hints[browserFile]);
			} else {
				// no real association found, try to find best match
				var bestMatch = findBestScoredMatch(browserFile, editorFiles);
				if (bestMatch !== null) {
					pickOption(editorFilesOpt, bestMatch);
					updates[browserFile] = bestMatch;
				} else {
					// no match available, make sure empty value is selected
					pickOption(editorFilesOpt, '');
				}
			}
		});

		return Object.keys(updates).length ? updates : null;
	}

	/**
	 * Tries to automatically find best editor resource match for
	 * browser resource
	 */
	function guessAssociations(hints) {
		silenceChangeEvt = true;
		var updated = updateMappingUI(hints);
		if (updated) {
			assocs = _.extend(assocs || {}, updated);
			saveAssociations();
		}

		silenceChangeEvt = false;
	}

	function closest(elem, className) {
		while (elem) {
			if (elem.classList.contains(className)) {
				return elem;
			}

			elem = elem.parentNode;
		}
	}

	module = _.extend({
		/**
		 * Identifies currently connected editor
		 * @param  {Object} editor Editor info
		 */
		identifyEditor: function(editor) {
			if (!editor) {
				return;
			}

			var text = editor.title;
			if (editor.icon) {
				text = '<img src="' + editor.icon + '" alt="' + editor.title + '" class="socket__editor-icon" /> ' + text;
			}

			editorId = editor.id;
			view.querySelector('.socket__status.active').innerHTML = text;

			this.editorFiles = editor.files;
			this.socketActive = true;
		},

		/**
		 * Utility function to rename editor file 
		 * and preserve associations
		 * @param  {String} oldName Old file name
		 * @param  {String} newName New file name
		 */
		renameEditorFile: function(oldName, newName) {
			if (assocs) {
				_.each(assocs, function(v, k) {
					if (v === oldName) {
						assocs[k] = newName;
					}
				});

				if (editorFiles) {
					this.editorFiles = editorFiles.map(function(name) {
						return name === oldName ? newName : name;
					});
				}

				module.trigger('saveAssociations', assocs);
			}
		},

		get view() {
			return view;
		},

		get pluginActive() {
			return pluginActive;
		},

		set pluginActive(state) {
			if (pluginActive !== state) {
				pluginActive = state;
				this.trigger(state ? 'enable' : 'disable');
			}
		},

		get socketActive() {
			return getByClass('socket').classList.contains('active');
		},

		set socketActive(state) {
			getByClass('socket').classList[state ? 'add' : 'remove']('active');
			this.trigger('socket:active', state);
		},

		get editorFiles() {
			return editorFiles;
		},

		set editorFiles(files) {
			editorFiles = files;
			updateResources(browserFiles, editorFiles);
		},

		get browserFiles() {
			return browserFiles;
		},

		set browserFiles(files) {
			browserFiles = files;
			updateResources(browserFiles, editorFiles);
		},

		get assocs() {
			return _.clone(assocs);
		},

		set assocs(value) {
			assocs = _.clone(value);
			if (browserFiles) {
				guessAssociations(assocs);
			}
		},

		/**
		 * Returns associated browser file for given 
		 * editor one
		 * @param  {String} file
		 * @return {String}
		 */
		associatedFile: function(file) {
			var out = null;
			_.each(assocs, function(v, k) {
				if (v == file) {
					out = k;
				}
			});

			return out;
		}
	}, eventMixin);

	module.on('enable', function() {
		view.classList.remove('livestyle_disabled');
		getByClass('livestyle-enabled').checked = true;
	});

	module.on('disable', function() {
		view.classList.add('livestyle_disabled');
		getByClass('livestyle-enabled').checked = false;
	});

	getByClass('livestyle-enabled').addEventListener('click', function(evt) {
		module.pluginActive = this.checked;
	}, false);

	var mappings = getByClass('mappings');
	mappings.addEventListener('change', function(evt) {
		if (!silenceChangeEvt) {
			saveAssociations();
		}
	}, false);

	mappings.addEventListener('click', function(evt) {
		if (evt.target.classList.contains('remove')) {
			var parent = closest(evt.target, 'sources__item');
			if (parent) {
				var bw = getByClass('sources__browser', parent);
				module.trigger('removeFile', bw.title);
			}
		}
		if (!silenceChangeEvt) {
			saveAssociations();
		}
	}, false);

	view.querySelector('.socket__status .reload').addEventListener('click', function(evt) {
		module.trigger('socket:reload');
	}, false);

	return module;
});
(function (root, factory) {
	if (typeof define === 'function' && define.amd) {
		define('emSelect',factory);
	} else {
		root.emSelect = factory();
	}
}(this, function() {
	var sliceFn = Array.prototype.slice;
	var widgets = {};
	var widgetId = 0;
	

	/**
	 * Simple config options wrapper
	 * @param {Object} data Actual options
	 */
	function Options(data) {
		this.data = data || {};
	}

	/**
	 * Returns given option name. If it's not defined, 
	 * returns optional `defaultValue`
	 * @param  {String} name         Option name
	 * @param  {any} defaultValue Default value, if option doesn't exists
	 * @return {Object}
	 */
	Options.prototype.get = function(name, defaultValue) {
		return name in this.data 
			? this.data[name] 
			: defaultValue;
	};

	/**
	 * Invokes given method, if exists, with passed
	 * arguments
	 * @param  {String} methodName
	 */
	Options.prototype.invoke = function(methodName) {
		if (typeof this.data[methodName] == 'function') {
			return this.data[methodName].apply(this.data, sliceFn.call(arguments, 1));
		}
	};

	/**
	 * Creates element with given tag name
	 * @param  {String} name      Tag name
	 * @param  {String} className Element's classes
	 * @return {Element}
	 */
	function el(name, className) {
		var elem = document.createElement(name);
		if (className) {
			elem.className = className;
		}
		return elem;
	}

	/**
	 * Gets closest parent of given element with
	 * specified class name
	 * @param  {Element} elem
	 * @param  {String} className
	 * @return {Element}
	 */
	function closest(elem, className) {
		while (elem.parentNode) {
			if (elem.classList.contains(className)) {
				return elem;
			}
			elem = elem.parentNode;
		}
	}

	/**
	 * Sets attributes to given element.
	 * @param {Element} elem Designated element
	 * @param {Object} attrs Attributes hash. You can also pass
	 * string as attribute name and third argument as attribute 
	 * value
	 * @returns {Element}
	 */
	function setAttr(elem, attrs) {
		if (typeof attrs == 'string' && arguments.length > 2) {
			elem.setAttribute(attrs, arguments[2]);
		} else if (typeof attrs == 'object') {
			Object.keys(attrs).forEach(function(name) {
				elem.setAttribute(name, attrs[name]);
			});
		}

		return elem;
	}

	/**
	 * Returns widget ID for given object
	 * @param  {Object} obj Any element of widget ID
	 * @return {String}
	 */
	function getWid(obj) {
		return (typeof obj == 'string') ? obj : obj.getAttribute('data-widget-id');
	}

	/**
	 * Utility function to remove element from DOM tree
	 * @param {Element} elem
	 */
	function remove(elem) {
		if (elem && elem.parentNode) {
			elem.parentNode.removeChild(elem);
		}
	}

	/**
	 * Builds HTML options list for given &lt;select&gt; element
	 * @param  {Element} sel
	 * @return {Element}
	 */
	function buildOptions(elem) {
		var wid = getWid(elem);
		var sel = widgets[wid].select;
		var options = widgets[wid].options;
		var optList = el('ul', 'em-select__opt');
		widgets[wid].popup = optList;

		for (var i = 0, il = sel.options.length, item, label, opt; i < il; i++) {
			opt = sel.options[i];
			item = el('li', 'em-select__opt-item');
			setAttr(item, {
				'data-ix': i,
				'data-value': opt.value,
				'data-label': opt.label
			});

			if (sel.selectedIndex == i) {
				item.className += ' em-select__opt-item_selected';
			}

			label = el('span', 'em-select__opt-item-label');
			label.innerHTML = opt.label;

			item.appendChild(label);
			options.invoke('onItemCreate', item);
			optList.appendChild(item);
		}

		options.invoke('onItemListPopulate', optList);
		return optList;
	}

	/**
	 * Shows emSelect popup for given &lt;select&gt; element
	 * @param  {Element} sel
	 */
	function showOptions(elem) {
		var wid = getWid(elem);
		var wData = widgets[wid];

		if (wData.widget.classList.contains('em-select_active')) {
			return;
		}

		wData.widget.classList.add('em-select_active');
		wData.widget.appendChild(buildOptions(wid));
		wData.options.invoke('onPopupShow', wid);
	}

	/**
	 * Hides emSelect popup for given source element
	 * @param {Element} elem
	 */
	function hideOptions(elem) {
		var wid = getWid(elem);
		var wData = widgets[wid];

		if (wData && wData.widget.classList.contains('em-select_active')) {
			wData.widget.classList.remove('em-select_active');
			if (wData.popup) {
				wData.options.invoke('onPopupHide', wid);
				remove(wData.popup);
				wData.popup = null;
			}
		}
	}

	/**
	 * Hides all active popups
	 */
	function hideAllOptions() {
		Object.keys(widgets).forEach(hideOptions);
	}

	document.addEventListener('click', function(evt) {
		var optItem = closest(evt.target, 'em-select__opt-item');
		if (optItem) {
			var container = closest(optItem, 'em-select');
			var wid = getWid(container);
			var handle = widgets[wid].options.invoke('onItemClick', optItem, wid, evt);
			if (handle !== false) {
				widgets[wid].select.value = optItem.getAttribute('data-value');

				// manually trigger `onchange` event
				var changeEvent = document.createEvent('HTMLEvents');
				changeEvent.initEvent('change', false, true);
				widgets[wid].select.dispatchEvent(changeEvent);

				hideOptions(wid);
			}
			return;
		}

		var optContainer = closest(evt.target, 'em-select');
		if (optContainer) {
			var wid = getWid(optContainer);
			if (widgets[wid].widget.classList.contains('em-select_active')) {
				hideOptions(wid);
			} else {
				showOptions(wid);
			}

			return;
		}

		hideAllOptions();
	}, false);

	/**
	 * Select widget constructor
	 * @param  {Element} elem    Original &lt;select&gt; element
	 * @param  {Object} options Constructor object
	 */
	var factory = function(elem, options) {
		var wid = 'em' + (++widgetId);
		options = new Options(options);
		
		var widget = el('span', 'em-select');
		var label = el('span', 'em-select__label');
		var labelText = options.get('label', '...');

		if (typeof elem.selectedIndex !== 'undefined') {
			labelText = elem.options[elem.selectedIndex].label;
		}

		label.innerHTML = labelText;
		widget.appendChild(label);

		setAttr(elem, 'data-widget-id', wid);
		setAttr(widget, 'data-widget-id', wid);

		elem.style.cssText += ';visibility:hidden;position:absolute;left:-2000px;';
		elem.addEventListener('change', function(evt) {
			label.innerHTML = elem.options[elem.selectedIndex].label;
		}, false);
		elem.parentNode.insertBefore(widget, elem);

		widgets[wid] = {
			select: elem, 
			widget: widget,
			options: options,
			popup: null
		};
	};

	factory.hide = hideOptions;
	factory.hideAll = hideAllOptions;
	factory.destory = function(elem) {
		var wid = getWid(elem);
		if (wid && wid in widgets) {
			remove(widgets[wid].widget);
			remove(widgets[wid].popup);
			delete widgets[wid];
		}

		if (elem.nodeType) {
			elem.removeAttribute('data-widget-id');
		}
	};
	factory.widgetData = function(elem) {
		var wid = getWid(elem);
		return widgets[wid];
	};

	return factory;
}));
define('extension/patchHistory',['lodash', 'eventMixin', 'emSelect'], function(_, eventMixin, emSelect) {
	var module = null;
	var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	var words = {
		today: 'Today',
		yesterday: 'Yesterday'
	};

	var blobs = {};

	var emSelectDelegate = {
		onItemListPopulate: function(elem) {
			// remove first option since it's a label
			var opt = elem.getElementsByClassName('em-select__opt-item')[0];
			opt.parentNode.removeChild(opt);
		},
		onItemCreate: function(item) {
			var key = item.getAttribute('data-value');
			if (!key) {
				return;
			}

			var dwBtn = el('a', {
				'class': 'patch-download',
				'href': blobs[key].url,
				'download': blobs[key].filename,
				'title': 'Download patch'
			});
			dwBtn.innerHTML = '&#11015;';
			item.appendChild(dwBtn);
		},
		onItemClick: function(item, wid, evt) {
			if (!evt.target.classList.contains('patch-download')) {
				var key = item.getAttribute('data-value');
				module.trigger('patchSelected', createPatchPayload(blobs[key]));
			}
			emSelect.hide(wid);
			return false;
		}
	};

	/**
	 * Utility function to create element with given name 
	 * class name
	 * @param  {String} name  Element name
	 * @param  {String} att   Element's class (string) or attributes hash (object)
	 * @return {Element}
	 */
	function el(name, attrs) {
		var elem = document.createElement(name);
		if (typeof attrs == 'string') {
			elem.className = attrs;
		} else if (typeof attrs == 'object') {
			Object.keys(attrs).forEach(function(k) {
				elem.setAttribute(k, attrs[k]);
			});
		}

		return elem;
	}

	function isSameDay(dt1, dt2) {
		return dt1.getDate() == dt2.getDate() && dt1.getMonth() == dt2.getMonth() && dt1.getFullYear() == dt2.getFullYear();
	}

	function pad(num) {
		return (num < 10 ? '0' : '') + num;
	}

	/**
	 * @param  {Number} dt 
	 * @return {String}
	 */
	function formatDate(dt) {
		dt = new Date(dt);
		var today = new Date();
		var yesterday = new Date();

		var prefix = '';
		if (isSameDay(dt, today)) {
			prefix = words.today;
		} else if (isSameDay(dt, yesterday)) {
			prefix = words.yesterday;
		} else {
			prefix = months[dt.getMonth()] + ' ' + dt.getDate();
			if (dt.getFullYear() != today.getFullYear()) {
				prefix += ', ' + dt.getFullYear();
			}
		}

		return prefix + ', ' + pad(dt.getHours()) + ':' + pad(dt.getMinutes());
	}

	function formatDateForFile(dt) {
		dt = new Date(dt);
		return [dt.getFullYear(), pad(dt.getMonth() + 1), pad(dt.getDate()), pad(dt.getHours()), pad(dt.getMinutes())].join('-');
	}

	/**
	 * Transforms page settings into array of option values
	 * with `label` and `value` properties
	 * @param  {Object} settings Page settings
	 * @return {Array}
	 */
	function settingsToOpt(settings) {
		if (settings.meta.patchHistory) {
			return settings.meta.patchHistory
				.filter(function(item) {
					return !!Object.keys(item.styles).length;
				})
				.sort(function(a, b) {
					return b.date - a.date;
				})
				.map(function(item, i) {
					return {
						label: formatDate(item.date),
						value: i
					};
				});
		}

		return [];
	}

	/**
	 * Correcly resets patch blob container
	 */
	function emptyBlobs() {
		Object.keys(blobs).forEach(function(blob) {
			window.URL.revokeObjectURL(blob.url);
		});

		blobs = {};
	}

	/**
	 * Saves patches as internal blobs
	 * @param  {Object} settings Page settings
	 */
	function saveBlobs(settings) {
		emptyBlobs();

		if (settings.meta.patchHistory) {
			settings.meta.patchHistory
				.filter(function(item) {
					return !!Object.keys(item.styles).length;
				})
				.forEach(function(item, i) {
					var fileContent = {
						id: 'livestyle',
						files: item.styles
					};
					var json = JSON.stringify(fileContent, null, '\t');
					var b = new Blob([json], {type: 'application/octet-stream'});
					blobs[i + ''] = {
						styles: item.styles,
						url: window.URL.createObjectURL(b),
						filename: 'lspatch-' + formatDateForFile(item.date) + '.json'
					};
				});
		}
	}

	/**
	 * Creates patch payload for given patch history item
	 * @param  {Object} hItem Patch history item
	 * @return {Array}
	 */
	function createPatchPayload(hItem) {
		return Object.keys(hItem.styles).map(function(url) {
			return {
				browserFile: url,
				patch: hItem.styles[url]
			};
		});
	}

	/**
	 * Populates options for &lt;select&gt; list
	 * @param  {Element} sel
	 * @param {Array}   list List of options. Each option is object
	 * with `label` and `value` keys
	 */
	function populateSelect(sel, list) {
		if (!sel) {
			return;
		}
		
		sel.options.length = 0;

		// first option is label for emSelect widget
		sel.appendChild(el('option', {
			label: 'Patch history',
			value: ''
		}));

		list.forEach(function(item) {
			sel.appendChild(el('option', item));
		});
	}

	function updatePatchList(sel, settings) {
		saveBlobs(settings);
		var opt = settingsToOpt(settings);
		populateSelect(sel, opt);
		if (opt.length) {
			sel.parentNode.classList.remove('em-select_hidden');
		} else {
			sel.parentNode.classList.add('em-select_hidden');
		}
	}

	return module = _.extend({
		/**
		 * Init patch history module
		 * @param  {Object} settings Page settings
		 */
		init: function(settings, ctx) {
			ctx = ctx || document;
			var oldSel = ctx.querySelector('select[name="patch-history"]');
			if (oldSel) {
				oldSel.parentNode.removeChild(oldSel);
				emSelect.destory(oldSel);
			}

			var sel = el('select', {name: 'patch-history'});
			var wrap = el('span', 'patch-history__wrap');
			wrap.appendChild(sel);

			updatePatchList(sel, settings);
			ctx.querySelector('.mappings h2').appendChild(wrap);
			emSelect(sel, emSelectDelegate);
		},
		update: function(settings, ctx) {
			ctx = ctx || document;
			updatePatchList(ctx.querySelector('select[name="patch-history"]'), settings);
		}
	}, eventMixin);
});
define('webkit/utils',[],function() {
	return {
		mainFrame: function() {
			return WebInspector.frameResourceManager.mainFrame;
		},
		inspectedPageUrl: function() {
			return this.mainFrame().url;
		}
	}
});
/**
 * Page settings storage, must be used in background page
 */
define('webkit/pageSettings',['lodash', 'patch', 'dispatcher', 'webkit/utils'], function(_, patch, dispatcher, utils) {
	var module;
	// How many uri's settings can be saved in storage
	var MAX_PAGE_SETTINGS = 30;
	var MAX_PATCH_SESSIONS = 10;

	var _setting = new WebInspector.Setting('livestyle.pageSettings', []);

	var defaultSettings = {
		enabled: false,
		assocs: null,
		meta: {},
		userfiles: []
	};

	/**
	 * Internal function to retreive page settings for given URL
	 * @param  {String}   url
	 * @param  {Function} callback
	 */
	function getPageSettingsByUrl(url, callback) {
		var data = _setting.value || [];
		var ix = findPageSettingsForUrl(data, url);
		if (ix === -1) {
			data.push([url, _.cloneDeep(defaultSettings)]);
			ix = data.length - 1;
		}

		return callback(data[ix][1], url, {
			index: ix,
			full: data
		});
	}

	/**
	 * Locates page settings for given URL in common storage
	 * and returns its index
	 * @param  {Array} settings Common settings storage
	 * @param  {String} url      Page URL
	 * @return {Number} Index in `settings` array. Returns -1 if nothing found
	 */
	function findPageSettingsForUrl(settings, url) {
		for (var i = 0; i < settings.length; i++) {
			if (settings[i][0] === url) {
				return i;
			}
		}

		return -1;
	}

	/**
	 * Saves patch for given URL in patch history of page settings
	 * @param  {String} url   Inspected page URL
	 * @param  {Object} patch CSS patch
	 */
	function savePatchInHistory(url, styleUrl, patches) {
		getPageSettingsByUrl(url, function(settings) {
			if (!settings.meta.patchHistory) {
				return;
			}

			var h = _.last(settings.meta.patchHistory);
			if (h && h.styles) {
				if (!h.styles[styleUrl]) {
					h.styles[styleUrl] = [];
				}

				h.styles[styleUrl] = patch.condense(h.styles[styleUrl].concat(patches));
				module.save({
					url: url,
					value: settings
				});
			}
		});
	}

	/**
	 * Starts new patch session for inspected document
	 */
	function startPatchSession(url) {
		getPageSettingsByUrl(url, function(settings) {
			if (!settings.meta.patchHistory) {
				settings.meta.patchHistory = [];
			}

			// remove empty sessions
			var patchHistory = settings.meta.patchHistory.filter(function(item) {
				return !!Object.keys(item.styles).length;
			});

			patchHistory.push({
				date: Date.now(),
				styles: {}
			});

			while (patchHistory.length >= MAX_PATCH_SESSIONS) {
				patchHistory.shift();
			}

			settings.meta.patchHistory = patchHistory;
			module.save({
				url: url,
				value: settings
			});
		});
	}

	/**
	 * Returns url of updated resource that can be used for storing
	 * data in history.
	 * Particularly, this function returns proper url for
	 * user blobs
	 * @param  {Object} data Patch payload
	 * @return {String}
	 */
	function getUrlForHistory(data) {
		if (/^blob:/i.test(data.url)) {
			var m = data.source.match(/\/\*\s+(livestyle:[\w\-]+)/);
			return m ? m[1] : null;
		}

		return data.url;
	}

	// debug only: clear storage
	// storage.clear();
	dispatcher.on('start', function() {
		WebInspector.Frame.addEventListener(WebInspector.Frame.Event.MainResourceDidChange, function(evt) {
			if (!evt.target.isMainFrame()) {
				return;
			}
			startPatchSession(utils.inspectedPageUrl());
		});
		startPatchSession(utils.inspectedPageUrl());
	});
	

	dispatcher.on('sourcePatched', function(data) {
		savePatchInHistory(utils.inspectedPageUrl(), getUrlForHistory(data), data.patches);
	});

	return module = {
		/**
		 * Retreive page settings for given data (url or tab ID)
		 * @param  {Object}   data
		 * @param  {Function} callback
		 */
		get: function(data, callback) {
			if (!data || !data.url) {
				console.error('No data for page settings');
				return callback(null);
			}

			getPageSettingsByUrl(data.url, callback);
		},

		/**
		 * Saves page settings
		 * @param  {Object} data Settings payload
		 */
		save: function(data) {
			this.get(data, function(value, url, info) {
				var fullData = info ? info.full : [];
				value = _.extend(value, data.value);
				if (info) {
					fullData[info.index][1] = value;
				} else {
					while (fullData.length >= MAX_PAGE_SETTINGS) {
						fullData.shift();
					}

					fullData.push([url, value]);
				}

				_setting.value = fullData;
				dispatcher.trigger('pageSettingsChanged', value);
			});
		}
	};
});
/**
 * Module to work with stylesheets
 */
define('webkit/styles',['lodash', 'webkit/utils'], function(_, utils) {
	var blobUrlLookup = {};
	var stylesCache = null;

	function resetStylesCache() {
		stylesCache = null;
	}

	function requestContent(styleSheetId, callback) {
		var styleSheet = WebInspector.cssStyleManager.styleSheetForIdentifier(styleSheetId);
		styleSheet.requestContent(function(res) {
			callback(res.content);
		});
	}

	function getStyles(callback) {
		if (stylesCache) {
			return callback(stylesCache);
		}

		var styleList = utils.mainFrame().resourcesWithType(WebInspector.Resource.Type.Stylesheet).map(function(item) {
			return item.url;
		});

		CSSAgent.getAllStyleSheets(function(err, styleSheets) {
			if (err) {
				return callback(null);
			}

			var out = [];
			var next = function() {
				if (styleSheets.length) {
					var s = styleSheets.shift();
					if (_.include(styleList, s.sourceURL)) {
						requestContent(s.styleSheetId, function(content) {
							out.push({
								id: s.styleSheetId,
								url: s.sourceURL,
								realUrl: s.sourceURL,
								content: content
							});
							next();
						});
					} else {
						next();
					}
				} else {
					callback(stylesCache = out);
				}
			};

			next();
		});
	}

	WebInspector.Resource.addEventListener(WebInspector.SourceCode.Event.ContentDidChange, resetStylesCache);
	// handle resource add/update
	WebInspector.Resource.addEventListener(WebInspector.Resource.Event.URLDidChange, resetStylesCache);

	return {
		/**
		 * Returns list of all CSS styles (URLs and contents) for current window
		 * @param {Function} callback
		 */
		all: getStyles,

		/**
		 * Adds new user CSS to inspected page
		 * @param {String} url Internal URL (or array of URLs)
		 * @param {Function} callback
		 */
		add: function(url, callback) {
			console.error('Not implemented yet');
			callback(null);
		},

		/**
		 * Removes given urls from inspected page
		 * @param {String} url URL to remove. Can be either
		 * internal or blob URL.
		 * @param  {Function} callback
		 */
		remove: function(url, callback) {
			console.error('Not implemented yet');
			callback(null);
		},

		/**
		 * Check if given URL is user defined
		 * @param  {String}  url
		 * @return {Boolean}
		 */
		isUserFile: function(url) {
			// TODO implement
			return false;
		},

		isBlobFile: function(url) {
			// TODO implement
			return false;
		},

		/**
		 * Generates internal file name for user style
		 * @return {String}
		 */
		generateUserFileName: function(suffix) {
			// TODO implement
			return 'livestyle:user';
		},

		/**
		 * Locates internal URL for given blob one
		 * @param  {String} blobUrl
		 * @return {String}
		 */
		lookupInternalUrl: function(blobUrl) {
			return blobUrlLookup[blobUrl];
		},

		/**
		 * Locates blob URL for given internal one
		 * @param  {String} internalUrl
		 * @return {String}
		 */
		lookupBlobUrl: function(internalUrl) {
			var keys = Object.keys(blobUrlLookup);
			for (var i = keys.length - 1; i >= 0; i--) {
				if (blobUrlLookup[keys[i]] === internalUrl) {
					return keys[i];
				}
			}
		},

		/**
		 * Replaces content of resource with given
		 * @param  {String} url     Resource URL
		 * @param  {String} content New content
		 */
		replaceContent: function(url, content) {
			getStyles(function(res) {
				if (!res || !res.length) {
					return;
				}

				var r = _.find(res, function(item) {
					return item.realUrl == url;
				});

				if (r) {
					var styleSheet = WebInspector.cssStyleManager.styleSheetForIdentifier(r.id);
					WebInspector.branchManager.currentBranch.revisionForRepresentedObject(styleSheet).content = content;
				}
			});
		},

		requestResourceContent: function(url, callback) {
			CSSAgent.getAllStyleSheets(function(err, styleSheets) {
				if (err) {
					return callback(null);
				}

				var s = _.find(styleSheets, function(item) {
					return item.sourceURL == url || item.styleSheetId == url;
				});

				if (s) {
					requestContent(s.styleSheetId, callback);
				} else {
					callback(null);
				}
			});
		}
	}
});
define('webkit/panel',['lodash', 'dispatcher', 'socket', 'extension/panelView', 'extension/patchHistory', 'webkit/pageSettings', 'webkit/styles', 'webkit/utils'], function(_, dispatcher, socket, panelView, patchHistory, pageSettings, styles, utils) {
	var buttonAdded = false;
	var domain = typeof LIVESTYLE_URL != 'undefined' ? LIVESTYLE_URL : '';
	var btnImageUrl = domain + 'NavigationItemEmmet.pdf';

	var lsBtn = new WebInspector.ActivateButtonToolbarItem('livestyle', 'Show Emmet LiveStyle', 'Emmet LiveStyle', 'Emmet LiveStyle', btnImageUrl);
	lsBtn.addEventListener(WebInspector.ButtonNavigationItem.Event.Clicked, toggleLSView);
	lsBtn.enabled = true;

	var view = document.createElement('div');
	view.className = 'livestyle-webkit-view';
	view.appendChild(panelView.view);

	function toggleLSView() {
		if (!lsBtn.activated) {
			var bounds = lsBtn._element.getBoundingClientRect();
			view.style.left = (bounds.left - 15) + 'px';
			view.style.top = (bounds.bottom + 15) + 'px';
			document.body.appendChild(view);
			lsBtn.activated = true;
		} else {
			if (view.parentNode) {
				view.parentNode.removeChild(view);
			}

			lsBtn.activated = false;
		}
	}

	function saveBrowserFiles() {
		styles.all(function(res) {
			panelView.browserFiles = _.pluck(res, 'url');
		});
	}

	/**
	 * Updates view state with new settings
	 * @param  {Object} settings
	 */
	function updatePageSettings(settings) {
		if (!settings) {
			return;
		}
		panelView.pluginActive = settings.enabled;
		panelView.assocs = settings.assocs;
	}

	function startPanel() {
		if (!buttonAdded) {
			WebInspector.toolbar.addToolbarItem(lsBtn, WebInspector.Toolbar.Section.Left);
			buttonAdded = true;
		}

		pageSettings.get({url: utils.inspectedPageUrl()}, function(data) {
			updatePageSettings(data);
			saveBrowserFiles();
			// patchHistory.init(data, panelView.view);
		});
	}

	function savePageSettings(newData) {
		pageSettings.save({
			url: utils.inspectedPageUrl(),
			value: newData || {}
		});
	}

	WebInspector.Resource.addEventListener(WebInspector.Resource.Event.URLDidChange, saveBrowserFiles);

	socket
		.on('open', function() {
			panelView.socketActive = true;
		})
		.on('close', function() {
			panelView.socketActive = false;
		})
		.on('message', function(message) {
			switch (message.action) {
				case 'id':
					panelView.identifyEditor(message.data);
					break;
				case 'updateFiles':
					panelView.editorFiles = message.data;
					break;
				case 'renameFile':
					panelView.renameEditorFile(message.data.oldname, message.data.newname);
					break;
			}
		});

	dispatcher
		.on('pageSettingsChanged', function(settings) {
			updatePageSettings(settings);
			// patchHistory.update(settings, panelView.view);
		})
		.on('start', startPanel);

	panelView
		.on('saveAssociations', function(assocs) {
			savePageSettings({assocs: assocs});
		})
		.on('removeFile', function(file) {
			// utils.sendPortMessage('devtools', 'removeUserFile', file);
		})
		.on('socket:reload', function() {
			socket.check();
		})
		.on('enable', function() {
			savePageSettings({enabled: true});
		})
		.on('disable', function() {
			savePageSettings({enabled: false});
		});

	patchHistory.on('patchSelected', function(patch) {
		dispatcher.trigger('applyPatch', patch);
	});
});
define('extension/webkit/livestyle',
['lodash', 'patch', 'diff', 'socket', 'dispatcher', 'webkit/panel', 'extension/panelView', 'webkit/styles', 'webkit/pageSettings', 'webkit/utils'], 
function(_, patch, diff, socket, dispatcher, panel, panelView, styles, pageSettings, utils) {
	var styleCache = {};
	var suppressed = {};
	var domain = typeof LIVESTYLE_URL != 'undefined' ? LIVESTYLE_URL : '';

	var patchQueue = [];
	patchQueue.running = false;
	var diffQueue = [];
	diffQueue.running = false;

	var worker = new Worker(domain + 'worker.js');
	worker.onmessage = function(evt) {
		var data = evt.data;
		switch (data.action) {
			case 'patch':
				patchQueue.running = false;
				if (data.success) {
					var realUrl = styles.isUserFile(data.file) ? styles.lookupBlobUrl(data.file) : data.file;

					styleCache[data.file] = data.result.source;
					suppressUpdate(realUrl);
					sourcePatched(data);
					styles.replaceContent(realUrl, data.result.source);
				} else {
					console.error(data.result);
				}

				_runPatching();
				break;
			case 'diff':
				diffQueue.running = false;
				
				if (data.success) {
					var result = data.result;
					styleCache[data.file] = result.source;

					if (result.patches && result.patches.length) {
						onDiffComplete({
							url: data.file,
							patches: result.patches
						});
						sourcePatched(data);
					}
				} else {
					console.error(data.result);
				}

				_runDiff();
				break;
		}
	};

	/**
	 * Tell all listeners that CSS file was updated (patched)
	 * @param {Object} data Worker response
	 */
	function sourcePatched(data) {
		dispatcher.trigger('sourcePatched', {
			url: data.file,
			patches: data.result.patches,
			source: data.result.source
		});
	}

	/**
	 * Marks given URL to suppress incoming update
	 * @param  {String} url
	 */
	function suppressUpdate(url) {
		suppressed[url] = true;
	}

	function onDiffComplete(data) {
		pageSettings.get({url: utils.inspectedPageUrl()}, function(settings) {
			var payload = {
				action: 'update',
				data: {
					browserFile: data.url,
					editorFile: settings ? settings.assocs[data.url] : null,
					patch: data.patches
				}
			};
			socket.send(payload);
		});
	}

	/**
	 * Requests patching operation on given CSS source
	 * @param  {String} file  File name of patched CSS source
	 * @param  {Array} patch  Patches to apply
	 */
	function requestPatching(url, patches) {
		// check if the same file is queued for patching
		var queuedItem = _.find(patchQueue, function(item) {
			return item.url === url;
		});

		if (!queuedItem) {
			queuedItem = {
				url: url,
				patches: []
			};
			patchQueue.push(queuedItem);
		}

		if (!_.isArray(patches)) {
			patches = [patches];
		}

		queuedItem.patches = patch.condense(queuedItem.patches.concat(patches));
		_runPatching();
	}

	function _runPatching() {
		if (!patchQueue.running && patchQueue.length) {
			patchQueue.running = true;
			var p = patchQueue.shift();
			worker.postMessage({
				action: 'patch',
				file: p.url,
				source: styleCache[p.url],
				patches: p.patches
			});
		}
	}

	/**
	 * Requests diff operation on given CSS source
	 * @param  {String} url URL of CSS source
	 */
	function requestDiff(url) {
		if (!_.include(diffQueue, url)) {
			diffQueue.push(url);
		}
		_runDiff();
	}

	function _runDiff() {
		if (!diffQueue.running && diffQueue.length) {
			diffQueue.running = true;
			var url = diffQueue.shift();

			styles.requestResourceContent(url, function(content) {
				if (content !== null) {
					if (styles.isBlobFile(url)) {
						url = styles.lookupInternalUrl(url);
					}

					worker.postMessage({
						action: 'diff',
						file: url,
						source1: styleCache[url],
						source2: content
					});
				} else {
					diffQueue.running = false;
					_runDiff();
				}
			});
		}
	}

	function saveStyles() {
		styleCache = {};
		styles.all(function(res) {
			res.forEach(function(r) {
				styleCache[r.url] = r.content;
			});
		});
		
	}

	/**
	 * Applies incoming editor updates to CSS source
	 * @param  {Object} data Updates payload
	 */
	function applyUpdate(data, settings) {
		var browserFile = data.browserFile;
		if (!browserFile || !(browserFile in styleCache)) {
			_.each(settings.assocs, function(v, k) {
				if (v == data.editorFile) {
					browserFile = k;
				}
			});
		}

		if (!browserFile || !(browserFile in styleCache)) {
			return console.error('No associated file found');
		}

		requestPatching(browserFile, data.patch);
	}

	function runSourcePatching(data) {
		pageSettings.get({url: utils.inspectedPageUrl()}, function(settings) {
			if (!settings.enabled) {
				return;
			}

			var payload = _.isArray(data) ? data : [data];
			payload.forEach(function(item) {
				applyUpdate(item, settings);
			});
		});
	}

	function startExtension() {
		saveStyles();
		socket.connect();
	}

	////////////////////////////////////////////////////////////

	// handle resource change
	WebInspector.Resource.addEventListener(WebInspector.SourceCode.Event.ContentDidChange, function(evt) {
		var res = evt.target;
		if (res.url in suppressed) {
			delete suppressed[res.url];
			return;
		}

		if (!(res.url in styleCache) || !res.content) {
			console.log('No "%s" resource in styles cache', res.url);
			return;
		}

		pageSettings.get({url: utils.inspectedPageUrl()}, function(settings) {
			if (settings.enabled) {
				requestDiff(res.url);
			} else {
				styleCache[res.url] = content;
			}
		});
	});

	dispatcher
		.on('saveAssociations', function(data) {
			assocs = data;
		})
		.on('applyPatch', runSourcePatching)
		.on('start', function() {
			// add CSS style
			var link = document.createElement('link');
			link.setAttribute('rel', 'stylesheet');
			link.href = domain + 'panel.css';
			document.head.appendChild(link);
		});


	socket.on('message', function(msg) {
		switch (msg.action) {
			case 'update':
				runSourcePatching(msg.data);
				break;
		}
	});

	var _isStarted = false;
	WebInspector.Frame.addEventListener(WebInspector.Frame.Event.MainResourceDidChange, function(evt) {
		if (!_isStarted) {
			_isStarted = true;
			setTimeout(function() {
				startExtension();
				dispatcher.trigger('start');
			}, 1);
		} else if (evt.target.isMainFrame()) {
			startExtension();
		}
	});
});return require('extension/webkit/livestyle');}));